// Default questions bank - used only for first-time installation and for reset.
const defaultQuestions = [
  {
    "id": 1,
    "question": "Which of these numbers is a prime number?",
    "subject": "Mathematics",
    "generalFeedback": "A prime number is a whole number greater than 1 that has only two factors: 1 and itself. We need to check which of the options fits this definition.",
    "answers": [
      {"text": "9", "feedback": "Incorrect. 9 has factors 1, 3, and 9."},
      {"text": "15", "feedback": "Incorrect. 15 has factors 1, 3, 5, and 15."},
      {"text": "21", "feedback": "Incorrect. 21 has factors 1, 3, 7, and 21."},
      {"text": "11", "feedback": "Correct. 11 can only be divided by 1 and 11."}
    ],
    "correctAnswer": "11"
  },
  {
    "id": 2,
    "question": "What is the value of 'x' in the equation x + 8 = 20?",
    "subject": "Mathematics",
    "generalFeedback": "To solve for 'x' in this simple algebraic equation, you need to isolate 'x' by performing the opposite operation. Since 8 is added to x, you should subtract 8 from both sides of the equation.",
    "answers": [
      {"text": "12", "feedback": "Correct. 20 - 8 = 12."},
      {"text": "28", "feedback": "Incorrect. This is the result of adding 8 to 20, not subtracting."},
      {"text": "160", "feedback": "Incorrect. This is the result of multiplying 20 by 8."},
      {"text": "2.5", "feedback": "Incorrect. This is the result of dividing 20 by 8."}
    ],
    "correctAnswer": "12"
  },
  {
    "id": 3,
    "question": "Calculate the perimeter of a rectangle with a length of 10cm and a width of 5cm.",
    "subject": "Mathematics",
    "generalFeedback": "The perimeter of a rectangle is the total distance around it. The formula is P = 2 * (length + width).",
    "answers": [
      {"text": "15cm", "feedback": "Incorrect. You added the length and width once, but the perimeter requires adding all four sides."},
      {"text": "50cm", "feedback": "Incorrect. This is the area (length × width), not the perimeter."},
      {"text": "30cm", "feedback": "Correct. P = 2 * (10cm + 5cm) = 2 * 15cm = 30cm."},
      {"text": "25cm", "feedback": "Incorrect. Check your formula and calculation."}
    ],
    "correctAnswer": "30cm"
  },
  {
    "id": 4,
    "question": "Convert 75% to a fraction in its simplest form.",
    "subject": "Mathematics",
    "generalFeedback": "The term 'percent' means 'out of 100'. To convert a percentage to a fraction, you write it as a fraction with a denominator of 100 and then simplify.",
    "answers": [
      {"text": "75/100", "feedback": "Incorrect. While this is the correct initial fraction, it is not in its simplest form."},
      {"text": "3/4", "feedback": "Correct. 75/100 can be simplified by dividing both the numerator and denominator by 25."},
      {"text": "1/4", "feedback": "Incorrect. 1/4 is equal to 25%, not 75%."},
      {"text": "7.5/10", "feedback": "Incorrect. Fractions should not contain decimals."}
    ],
    "correctAnswer": "3/4"
  },
    {
    "id": 5,
    "question": "Convert the number 1101₂ to base 10.",
    "subject": "Mathematics",
    "generalFeedback": "To convert a number from base 2 (binary) to base 10 (decimal), you multiply each digit by 2 raised to the power of its position, starting from 0 on the right. For 1101₂, it is (1 * 2³) + (1 * 2²) + (0 * 2¹) + (1 * 2⁰).",
    "answers": [
    {"text": "13", "feedback": "Correct. (1 * 8) + (1 * 4) + (0 * 2) + (1 * 1) = 8 + 4 + 0 + 1 = 13."},
    {"text": "11", "feedback": "Incorrect. This might be from incorrectly calculating the powers of 2, for example, (1*8) + (1*2) + (0*1) + (1*0)."},
    {"text": "27", "feedback": "Incorrect. You might have read the number from right to left or used the wrong base for conversion."},
    {"text": "6", "feedback": "Incorrect. This is the sum of the digits (1+1+0+1), not the value in base 10."}
    ],
    "correctAnswer": "13"
    },
    {
    "id": 6,
    "question": "Express 47₁₀ as a number in base 2.",
    "subject": "Mathematics",
    "generalFeedback": "To convert a base 10 number to base 2, you use repeated division by 2 and record the remainders. You then read the remainders from bottom to top.",
    "answers": [
    {"text": "101111₂", "feedback": "Correct. 47÷2=23 R 1; 23÷2=11 R 1; 11÷2=5 R 1; 5÷2=2 R 1; 2÷2=1 R 0; 1÷2=0 R 1. Reading remainders up: 101111₂."},
    {"text": "111101₂", "feedback": "Incorrect. This happens if you read the remainders from top to bottom."},
    {"text": "101110₂", "feedback": "Incorrect. Check your division steps and remainders carefully."},
    {"text": "23.5₂", "feedback": "Incorrect. The conversion process involves repeated division and collecting remainders, not just dividing by 2 once."}
    ],
    "correctAnswer": "101111₂"
    },
  {
    "id": 7,
    "question": "Which of the following is a VERB?",
    "subject": "English",
    "generalFeedback": "A verb is a word that describes an action, occurrence, or state of being. It's often called an 'action word'.",
    "answers": [
      {"text": "Happy", "feedback": "Incorrect. 'Happy' describes a noun (e.g., a happy child), so it is an adjective."},
      {"text": "Quickly", "feedback": "Incorrect. 'Quickly' describes how an action is done (e.g., he ran quickly), so it is an adverb."},
      {"text": "Jump", "feedback": "Correct. 'Jump' is an action, making it a verb."},
      {"text": "Table", "feedback": "Incorrect. 'Table' is the name of a thing, making it a noun."}
    ],
    "correctAnswer": "Jump"
  },
  {
    "id": 8,
    "question": "Choose the correct punctuation for the end of this sentence: 'What is your name'",
    "subject": "English",
    "generalFeedback": "Sentences that ask a direct question should always end with a question mark.",
    "answers": [
      {"text": ".", "feedback": "Incorrect. A full stop is used for statements, not questions."},
      {"text": "!", "feedback": "Incorrect. An exclamation mark is used to show strong feeling or excitement."},
      {"text": ",", "feedback": "Incorrect. A comma is used to separate items in a list or clauses in a sentence."},
      {"text": "?", "feedback": "Correct. This sentence is asking a question, so it requires a question mark."}
    ],
    "correctAnswer": "?"
  },
  {
    "id": 9,
    "question": "A story written to be performed on a stage by actors is called a ____.",
    "subject": "English",
    "generalFeedback": "Literature is divided into genres. The genre specifically for stage performance is known by a particular name.",
    "answers": [
      {"text": "Prose", "feedback": "Incorrect. Prose is the ordinary form of written language, found in novels and short stories."},
      {"text": "Poem", "feedback": "Incorrect. A poem is a piece of writing that uses imaginative language and is often written in verse."},
      {"text": "Drama", "feedback": "Correct. Drama is the specific term for plays written for theatre, television, or radio."},
      {"text": "Biography", "feedback": "Incorrect. A biography is the story of a person's life written by someone else."}
    ],
    "correctAnswer": "Drama"
  },
  {
    "id": 10,
    "question": "Identify the proper noun in the sentence: 'Tunde went to Lagos.'",
    "subject": "English",
    "generalFeedback": "A proper noun is the specific name of a person, place, or organization. It always starts with a capital letter. A common noun is a general name.",
    "answers": [
      {"text": "went", "feedback": "Incorrect. 'went' is a verb (action word)."},
      {"text": "to", "feedback": "Incorrect. 'to' is a preposition."},
      {"text": "Tunde", "feedback": "Correct. 'Tunde' is the specific name of a person."},
      {"text": "sentence", "feedback": "Incorrect. 'sentence' is a common noun, not a proper noun from the given example."}
    ],
    "correctAnswer": "Tunde"
  },
  {
    "id": 11,
    "question": "Which of these is NOT a characteristic of living things?",
    "subject": "Basic Science",
    "generalFeedback": "Living things have seven main characteristics, often remembered by the acronym MRS GREN (Movement, Respiration, Sensitivity, Growth, Reproduction, Excretion, Nutrition).",
    "answers": [
      {"text": "Growth", "feedback": "Incorrect. All living things grow from small to big."},
      {"text": "Respiration", "feedback": "Incorrect. All living things respire to release energy from food."},
      {"text": "Melting", "feedback": "Correct. Melting is a physical change in the state of matter, not a characteristic of life."},
      {"text": "Excretion", "feedback": "Incorrect. All living things excrete to remove waste products."}
    ],
    "correctAnswer": "Melting"
  },
  {
    "id": 12,
    "question": "The three states of matter are:",
    "subject": "Basic Science",
    "generalFeedback": "Matter is anything that has mass and occupies space. It exists in three primary physical states.",
    "answers": [
      {"text": "Hot, Cold, and Warm", "feedback": "Incorrect. These are measures of temperature, not states of matter."},
      {"text": "Solid, Liquid, and Gas", "feedback": "Correct. These are the three fundamental states of matter taught in basic science."},
      {"text": "Hard, Soft, and Smooth", "feedback": "Incorrect. These are textures or properties of solids, not the states of matter themselves."},
      {"text": "Air, Water, and Soil", "feedback": "Incorrect. These are examples of substances. Air is a gas, water is a liquid, and soil is a solid."}
    ],
    "correctAnswer": "Solid, Liquid, and Gas"
  },
  {
    "id": 13,
    "question": "Which simple machine would be most helpful for lifting a heavy box into a truck?",
    "subject": "Basic Science",
    "generalFeedback": "Simple machines are devices that make work easier by changing the direction or magnitude of a force. Think about which device reduces the effort needed to lift something.",
    "answers": [
      {"text": "A lever", "feedback": "Incorrect. While a lever could be used, it's not the most common or efficient tool for this specific task."},
      {"text": "A pulley", "feedback": "Incorrect. A pulley system could work, but an inclined plane is simpler for rolling or sliding a box up."},
      {"text": "An inclined plane", "feedback": "Correct. An inclined plane (a ramp) allows you to move the heavy object over a longer distance with less force."},
      {"text": "A wedge", "feedback": "Incorrect. A wedge is used for splitting things apart, not for lifting."}
    ],
    "correctAnswer": "An inclined plane"
  },
  {
    "id": 14,
    "question": "The part of a plant cell that is not found in an animal cell is the ______.",
    "subject": "Basic Science",
    "generalFeedback": "Plant and animal cells share many organelles, but plants have a few unique structures that support their functions, such as photosynthesis and structural rigidity.",
    "answers": [
      {"text": "Nucleus", "feedback": "Incorrect. Both plant and animal cells have a nucleus that contains genetic material."},
      {"text": "Cytoplasm", "feedback": "Incorrect. Both cell types have cytoplasm, the jelly-like substance that fills the cell."},
      {"text": "Cell wall", "feedback": "Correct. The cell wall is a rigid outer layer that provides structural support to plant cells and is absent in animal cells."},
      {"text": "Cell membrane", "feedback": "Incorrect. Both plant and animal cells have a cell membrane that controls what enters and leaves the cell."}
    ],
    "correctAnswer": "Cell wall"
  },
    {
    "id": 15,
    "question": "A balanced diet is one that contains...",
    "subject": "Basic Science",
    "generalFeedback": "A balanced diet is essential for good health and provides all the necessary nutrients the body needs to function correctly.",
    "answers": [
      {"text": "Only carbohydrates for energy.", "feedback": "Incorrect. While carbohydrates are important for energy, a diet with only one food class is not balanced."},
      {"text": "A lot of fatty foods.", "feedback": "Incorrect. Too much fat is unhealthy and does not constitute a balanced diet."},
      {"text": "All classes of food in the right proportions.", "feedback": "Correct. A balanced diet must contain carbohydrates, proteins, fats, vitamins, minerals, and water in the correct amounts."},
      {"text": "Only fruits and vegetables.", "feedback": "Incorrect. Fruits and vegetables provide vitamins and minerals but lack sufficient proteins and fats for a balanced diet."}
    ],
    "correctAnswer": "All classes of food in the right proportions."
  },
  {
    "id": 16,
    "question": "Which of these is the most important safety rule in a workshop?",
    "subject": "Basic Technology",
    "generalFeedback": "Workshop safety is crucial to prevent accidents. While all safety rules are important, one is a fundamental mindset that underpins all others.",
    "answers": [
      {"text": "Wear safety goggles", "feedback": "Incorrect. While very important for eye protection, it's a specific action. A broader, more fundamental rule exists."},
      {"text": "Clean up spills immediately", "feedback": "Incorrect. This is a good practice to prevent slips, but it's one of many specific rules."},
      {"text": "Report all accidents, no matter how small", "feedback": "Incorrect. This is important for learning and prevention, but it happens after an incident."},
      {"text": "Always think about safety first", "feedback": "Correct. This is a mindset of being aware and cautious at all times, which helps in following all other specific rules."}
    ],
    "correctAnswer": "Always think about safety first"
  },
  {
    "id": 17,
    "question": "What is a T-square primarily used for in technical drawing?",
    "subject": "Basic Technology",
    "generalFeedback": "Technical drawing requires specific instruments to create accurate and neat drawings. The T-square has a very specific primary function.",
    "answers": [
      {"text": "Drawing circles", "feedback": "Incorrect. Circles are drawn with a pair of compasses."},
      {"text": "Measuring curved lines", "feedback": "Incorrect. This is difficult to do with a T-square."},
      {"text": "Drawing horizontal lines", "feedback": "Correct. The head of the T-square rests on the edge of the drawing board, allowing the user to draw precise horizontal lines."},
      {"text": "Sharpening pencils", "feedback": "Incorrect. A sharpener or sandpaper block is used for sharpening pencils."}
    ],
    "correctAnswer": "Drawing horizontal lines"
  },
  {
    "id": 18,
    "question": "Wood, metal, and plastic are all examples of:",
    "subject": "Basic Technology",
    "generalFeedback": "In technology, the things used to make objects are grouped under a general term.",
    "answers": [
      {"text": "Tools", "feedback": "Incorrect. Tools are items used to work on materials, like a hammer or a saw."},
      {"text": "Machines", "feedback": "Incorrect. Machines are devices that use energy to perform tasks."},
      {"text": "Materials", "feedback": "Correct. These are the substances from which things are made."},
      {"text": "Projects", "feedback": "Incorrect. A project is the final object or task completed using materials."}
    ],
    "correctAnswer": "Materials"
  },
  {
    "id": 19,
    "question": "Which tool is best suited for cutting a piece of wood in a straight line?",
    "subject": "Basic Technology",
    "generalFeedback": "Different tools have specific functions in woodwork. Selecting the right tool for cutting ensures accuracy and safety.",
    "answers": [
      {"text": "A hammer", "feedback": "Incorrect. A hammer is used for driving nails."},
      {"text": "A file", "feedback": "Incorrect. A file is used for smoothing or shaping wood, not for cutting it into pieces."},
      {"text": "A chisel", "feedback": "Incorrect. A chisel is used for carving or shaping wood, often with a mallet."},
      {"text": "A tenon saw", "feedback": "Correct. A tenon saw is a type of handsaw specifically designed for making straight cuts in wood."}
    ],
    "correctAnswer": "A tenon saw"
  },
  {
    "id": 20,
    "question": "The famous terracotta heads are associated with which ancient Nigerian culture?",
    "subject": "History",
    "generalFeedback": "The Nok culture, which flourished in Northern Nigeria between 1500 BC and 500 AD, is renowned for its distinctive terracotta sculptures.",
    "answers": [
      {"text": "Nok", "feedback": "Correct. The Nok culture is globally recognized for its terracotta art."},
      {"text": "Benin", "feedback": "Incorrect. Benin is famous for its bronze castings, not terracotta heads."},
      {"text": "Ife", "feedback": "Incorrect. Ife is also known for bronze and terracotta, but the earliest and most famous terracotta heads are Nok."},
      {"text": "Oyo", "feedback": "Incorrect. The Oyo empire was known for its political and military structure, not primarily for terracotta art."}
    ],
    "correctAnswer": "Nok"
  },
  {
    "id": 21,
    "question": "What is a primary source of history?",
    "subject": "History",
    "generalFeedback": "Historians use different types of sources to learn about the past. Primary sources are those that come directly from the time period being studied.",
    "answers": [
      {"text": "A history textbook", "feedback": "Incorrect. A textbook is a secondary source because it was written later, interpreting primary sources."},
      {"text": "An interview with a historian", "feedback": "Incorrect. This is a secondary source, as the historian is providing their interpretation of past events."},
      {"text": "An eyewitness account or diary", "feedback": "Correct. These are first-hand accounts from people who were present at the event."},
      {"text": "A documentary on television", "feedback": "Incorrect. Documentaries are secondary sources that compile and explain information from various sources."}
    ],
    "correctAnswer": "An eyewitness account or diary"
  },
  {
    "id": 22,
    "question": "The amalgamation of the Northern and Southern Protectorates of Nigeria happened in what year?",
    "subject": "History",
    "generalFeedback": "This event, orchestrated by Lord Lugard, was a pivotal moment in the creation of modern Nigeria.",
    "answers": [
      {"text": "1960", "feedback": "Incorrect. This was the year Nigeria gained independence."},
      {"text": "1900", "feedback": "Incorrect. This was the year the Protectorate of Northern Nigeria was established."},
      {"text": "1914", "feedback": "Correct. The Northern and Southern Protectorates were joined in 1914 to form the Colony and Protectorate of Nigeria."},
      {"text": "1885", "feedback": "Incorrect. This was the year of the Berlin Conference when European powers divided Africa."}
    ],
    "correctAnswer": "1914"
  },
  {
    "id": 23,
    "question": "The Trans-Saharan trade was primarily based on the exchange of:",
    "subject": "History",
    "generalFeedback": "This ancient trade route across the Sahara desert connected West African kingdoms with North Africa and Europe. Two commodities were exceptionally valuable.",
    "answers": [
      {"text": "Crude oil and cars", "feedback": "Incorrect. These are modern trade items."},
      {"text": "Gold and salt", "feedback": "Correct. West Africa was rich in gold, which it traded for salt from the Sahara, a vital preservative."},
      {"text": "Slaves and guns", "feedback": "Incorrect. This became more prominent during the later Trans-Atlantic slave trade."},
      {"text": "Cocoa and groundnuts", "feedback": "Incorrect. These became major export crops during the colonial era."}
    ],
    "correctAnswer": "Gold and salt"
  },
  {
    "id": 24,
    "question": "Which of these is a simple farm tool?",
    "subject": "Agricultural Science",
    "generalFeedback": "Simple farm tools are hand-held implements used for small-scale farming operations, powered by human effort.",
    "answers": [
      {"text": "A tractor", "feedback": "Incorrect. A tractor is a farm machine, not a simple hand tool."},
      {"text": "A combine harvester", "feedback": "Incorrect. This is a complex piece of farm machinery."},
      {"text": "A cutlass", "feedback": "Correct. A cutlass is a hand-held tool used for clearing weeds and light vegetation."},
      {"text": "An irrigation system", "feedback": "Incorrect. This is a complex system, not a simple tool."}
    ],
    "correctAnswer": "A cutlass"
  },
  {
    "id": 25,
    "question": "The process of adding manure or fertilizer to the soil is done to improve its ____.",
    "subject": "Agricultural Science",
    "generalFeedback": "Soils can lose nutrients over time as crops are grown. Farmers add substances to replenish these nutrients.",
    "answers": [
      {"text": "Color", "feedback": "Incorrect. While manure can darken the soil, the primary purpose is not to change its color."},
      {"text": "Temperature", "feedback": "Incorrect. The main goal is not to change the soil temperature."},
      {"text": "Fertility", "feedback": "Correct. Manure and fertilizers add essential nutrients to the soil, making it more fertile and productive for plant growth."},
      {"text": "Water content", "feedback": "Incorrect. While organic matter can help retain water, the primary function of fertilizer is to add nutrients."}
    ],
    "correctAnswer": "Fertility"
  },
  {
    "id": 26,
    "question": "Crops like maize, rice, and yam are primarily grown for their _______ content.",
    "subject": "Agricultural Science",
    "generalFeedback": "These are staple foods in many cultures. They belong to a specific class of food that provides the body with its main source of energy.",
    "answers": [
      {"text": "Protein", "feedback": "Incorrect. While they contain some protein, it's not their primary nutrient. Beans and meat are high in protein."},
      {"text": "Vitamins", "feedback": "Incorrect. Fruits and vegetables are the primary sources of vitamins."},
      {"text": "Carbohydrates", "feedback": "Correct. These crops are rich in starch and sugars, which are carbohydrates that provide energy."},
      {"text": "Fats and oils", "feedback": "Incorrect. Groundnuts and palm fruits are examples of crops grown for oils."}
    ],
    "correctAnswer": "Carbohydrates"
  },
  {
    "id": 27,
    "question": "What is the term for animals that are raised on a farm for meat, milk, eggs, or other products?",
    "subject": "Agricultural Science",
    "generalFeedback": "There is a specific term used in agriculture to describe domesticated animals kept for economic purposes.",
    "answers": [
      {"text": "Pets", "feedback": "Incorrect. Pets are animals kept for companionship."},
      {"text": "Wildlife", "feedback": "Incorrect. Wildlife refers to animals living in their natural habitat, not on a farm."},
      {"text": "Livestock", "feedback": "Correct. Livestock is the correct term for farm animals like cattle, goats, and poultry."},
      {"text": "Pests", "feedback": "Incorrect. Pests are animals that cause damage to crops or livestock."}
    ],
    "correctAnswer": "Livestock"
  },
  {
    "id": 28,
    "question": "The basic unit of society is the ____.",
    "subject": "Social Humanity",
    "generalFeedback": "Social Studies examines human society and relationships. The smallest, most fundamental group in any society is considered its basic unit.",
    "answers": [
      {"text": "School", "feedback": "Incorrect. A school is an important institution, but the family is more fundamental."},
      {"text": "Community", "feedback": "Incorrect. A community is made up of many families."},
      {"text": "Family", "feedback": "Correct. The family is where individuals are first socialized and is considered the building block of society."},
      {"text": "Government", "feedback": "Incorrect. Government is the system that runs a state or nation, which is composed of many communities and families."}
    ],
    "correctAnswer": "Family"
  },
  {
    "id": 29,
    "question": "Which of these is a national symbol of Nigeria?",
    "subject": "Social Humanity",
    "generalFeedback": "National symbols are objects, emblems, or images that represent a country and evoke feelings of patriotism.",
    "answers": [
      {"text": "A lion", "feedback": "Incorrect. The lion is not a national symbol of Nigeria."},
      {"text": "The Coat of Arms", "feedback": "Correct. The Nigerian Coat of Arms, with the black shield, two horses, and eagle, is a major national symbol."},
      {"text": "A palm tree", "feedback": "Incorrect. While palm trees are common in Nigeria, they are not an official national symbol."},
      {"text": "The River Niger", "feedback": "Incorrect. While the country is named after the river, the river itself is a geographical feature, not an official symbol."}
    ],
    "correctAnswer": "The Coat of Arms"
  },
  {
    "id": 30,
    "question": "The three levels of government in Nigeria are:",
    "subject": "Social Humanity",
    "generalFeedback": "Nigeria operates a federal system where power is shared among different tiers or levels of government.",
    "answers": [
      {"text": "President, Governor, and King", "feedback": "Incorrect. These are titles of leaders, not the levels of government."},
      {"text": "Executive, Legislative, and Judiciary", "feedback": "Incorrect. These are the three arms of government, not the levels."},
      {"text": "Federal, State, and Local", "feedback": "Correct. These are the three tiers of government in Nigeria's federal structure."},
      {"text": "Village, Town, and City", "feedback": "Incorrect. These are types of settlements, not levels of government."}
    ],
    "correctAnswer": "Federal, State, and Local"
  },
  {
    "id": 31,
    "question": "The way of life of a group of people, including their language, dress, and food, is called their ____.",
    "subject": "Social Humanity",
    "generalFeedback": "This term encompasses all the shared beliefs, customs, arts, and social institutions of a particular nation, people, or group.",
    "answers": [
      {"text": "Religion", "feedback": "Incorrect. Religion is a part of culture, but culture is a broader term."},
      {"text": "Government", "feedback": "Incorrect. Government is the system of rule, which is an aspect of culture, not the whole thing."},
      {"text": "Environment", "feedback": "Incorrect. The environment is the physical surroundings, which influences culture but is not culture itself."},
      {"text": "Culture", "feedback": "Correct. Culture is the all-encompassing term for the shared way of life of a people."}
    ],
    "correctAnswer": "Culture"
  },
  {
    "id": 32,
    "question": "What is the primary function of an office?",
    "subject": "Business Studies",
    "generalFeedback": "An office serves as the administrative center of a business or organization, handling key information-related tasks.",
    "answers": [
      {"text": "To sell products directly to customers", "feedback": "Incorrect. While some sales may happen, this is the function of a shop or sales department, not the primary office function."},
      {"text": "To manufacture goods", "feedback": "Incorrect. This is the function of a factory or production plant."},
      {"text": "To receive, process, and store information", "feedback": "Correct. The core purpose of an office is to manage the flow of information that helps the business run."},
      {"text": "To provide a place for employees to rest", "feedback": "Incorrect. While offices have break rooms, this is not their primary function."}
    ],
    "correctAnswer": "To receive, process, and store information"
  },
  {
    "id": 33,
    "question": "The buying and selling of goods and services is known as:",
    "subject": "Business Studies",
    "generalFeedback": "This is the fundamental activity within commerce that involves the exchange of items for money.",
    "answers": [
      {"text": "Banking", "feedback": "Incorrect. Banking is an aid to trade that deals with money and credit."},
      {"text": "Insurance", "feedback": "Incorrect. Insurance is an aid to trade that provides protection against risk."},
      {"text": "Trade", "feedback": "Correct. Trade is the direct exchange of goods and services."},
      {"text": "Advertising", "feedback": "Incorrect. Advertising is an aid to trade that informs customers about products."}
    ],
    "correctAnswer": "Trade"
  },
  {
    "id": 34,
    "question": "Which of the following is an 'aid to trade'?",
    "subject": "Business Studies",
    "generalFeedback": "Aids to trade are services that facilitate the smooth process of buying and selling, overcoming various challenges like distance, risk, and finance.",
    "answers": [
      {"text": "Farming", "feedback": "Incorrect. Farming is a form of production, not a service that helps trade."},
      {"text": "Manufacturing", "feedback": "Incorrect. Manufacturing is the process of making goods."},
      {"text": "Transport", "feedback": "Correct. Transportation helps to move goods from the place of production to the place of consumption, overcoming the barrier of distance."},
      {"text": "Mining", "feedback": "Incorrect. Mining is an extractive industry."}
    ],
    "correctAnswer": "Transport"
  },
  {
    "id": 35,
    "question": "A document given to a customer to show proof of payment for goods is called a/an:",
    "subject": "Business Studies",
    "generalFeedback": "In bookkeeping, different source documents are used to record transactions. One specific document acknowledges that money has been received.",
    "answers": [
      {"text": "Invoice", "feedback": "Incorrect. An invoice is a bill requesting payment for goods or services provided."},
      {"text": "Receipt", "feedback": "Correct. A receipt is issued after payment has been made as proof of the transaction."},
      {"text": "Quotation", "feedback": "Incorrect. A quotation is an offer to sell goods at a specific price."},
      {"text": "Debit Note", "feedback": "Incorrect. A debit note is sent to inform a supplier that goods are being returned."}
    ],
    "correctAnswer": "Receipt"
  },
  {
    "id": 36,
    "question": "Which of these is an element of art?",
    "subject": "Creative Art",
    "generalFeedback": "The elements of art are the basic building blocks that artists use to create a work of art. Think of them as the ingredients.",
    "answers": [
      {"text": "A pencil", "feedback": "Incorrect. A pencil is a tool or medium used to create art."},
      {"text": "A painting", "feedback": "Incorrect. A painting is a finished work of art, made up of elements."},
      {"text": "Line", "feedback": "Correct. Line is a fundamental element of art used to define shapes, contours, and outlines."},
      {"text": "An artist", "feedback": "Incorrect. An artist is the person who creates art."}
    ],
    "correctAnswer": "Line"
  },
  {
    "id": 37,
    "question": "The three primary colours are:",
    "subject": "Creative Art",
    "generalFeedback": "Primary colours are the fundamental colours from which all other colours are mixed. They cannot be created by mixing other colours.",
    "answers": [
      {"text": "Green, Orange, and Purple", "feedback": "Incorrect. These are secondary colours, created by mixing two primary colours."},
      {"text": "Red, Yellow, and Blue", "feedback": "Correct. These are the three primary colours in traditional colour theory."},
      {"text": "Black, White, and Grey", "feedback": "Incorrect. These are considered neutral colours or shades."},
      {"text": "Brown, Pink, and Gold", "feedback": "Incorrect. These are tertiary or other colours."}
    ],
    "correctAnswer": "Red, Yellow, and Blue"
  },
  {
    "id": 38,
    "question": "The art of making objects from clay is called:",
    "subject": "Creative Art",
    "generalFeedback": "This is a form of craft that has been practiced for thousands of years, involving shaping clay and then hardening it with heat.",
    "answers": [
      {"text": "Weaving", "feedback": "Incorrect. Weaving involves interlacing threads to create fabric."},
      {"text": "Painting", "feedback": "Incorrect. Painting involves applying paint to a surface."},
      {"text": "Pottery", "feedback": "Correct. Pottery is the craft of making ceramic ware out of clay."},
      {"text": "Origami", "feedback": "Incorrect. Origami is the Japanese art of paper folding."}
    ],
    "correctAnswer": "Pottery"
  },
  {
    "id": 39,
    "question": "The speed of music is referred to as its:",
    "subject": "Music",
    "generalFeedback": "Music has several elements that describe its characteristics. There's a specific Italian term for the speed (fast or slow) of a piece of music.",
    "answers": [
      {"text": "Rhythm", "feedback": "Incorrect. Rhythm refers to the pattern of sounds and silences in music."},
      {"text": "Pitch", "feedback": "Incorrect. Pitch refers to how high or low a note is."},
      {"text": "Dynamics", "feedback": "Incorrect. Dynamics refers to the loudness or softness of the music."},
      {"text": "Tempo", "feedback": "Correct. Tempo is the term used to describe the speed at which a piece of music is played."}
    ],
    "correctAnswer": "Tempo"
  },
  {
    "id": 40,
    "question": "According to the book of Genesis, how many days did it take God to create the heavens and the earth?",
    "subject": "CRS",
    "generalFeedback": "The creation story in Genesis chapter 1 outlines a day-by-day account of God's work, followed by a day of rest.",
    "answers": [
      {"text": "One day", "feedback": "Incorrect. The creation was spread over several days."},
      {"text": "Three days", "feedback": "Incorrect. More work was done after the third day."},
      {"text": "Six days", "feedback": "Correct. Genesis 1 describes six days of creation, after which God rested on the seventh day."},
      {"text": "Forty days", "feedback": "Incorrect. Forty days is associated with Noah's flood and Jesus' temptation, not creation."}
    ],
    "correctAnswer": "Six days"
  },
  {
    "id": 41,
    "question": "Who was the man called by God to leave his home and travel to a new land, becoming the father of a great nation?",
    "subject": "CRS",
    "generalFeedback": "This figure is central to Judaism, Christianity, and Islam and is known for his great faith in God's promises.",
    "answers": [
      {"text": "Moses", "feedback": "Incorrect. Moses was called by God to lead the Israelites out of Egypt."},
      {"text": "Joseph", "feedback": "Incorrect. Joseph was sold into slavery by his brothers and later became a ruler in Egypt."},
      {"text": "David", "feedback": "Incorrect. David was a shepherd who became the king of Israel."},
      {"text": "Abraham", "feedback": "Correct. God called Abraham (then Abram) from Ur to go to the land of Canaan and promised to make him the father of many nations."}
    ],
    "correctAnswer": "Abraham"
  },
  {
    "id": 42,
    "question": "What were the Ten Commandments given to Moses on?",
    "subject": "CRS",
    "generalFeedback": "The Bible records that God gave Moses a set of moral laws for the Israelites, inscribed on a specific medium.",
    "answers": [
      {"text": "A scroll of papyrus", "feedback": "Incorrect. The commandments were not written on papyrus."},
      {"text": "Two tablets of stone", "feedback": "Correct. Exodus 31:18 states that God gave Moses two tablets of stone inscribed with the commandments."},
      {"text": "A golden plate", "feedback": "Incorrect. There is no mention of a golden plate in the biblical account."},
      {"text": "The sand of the desert", "feedback": "Incorrect. They were written on a permanent medium to be preserved."}
    ],
    "correctAnswer": "Two tablets of stone"
  },
  {
    "id": 43,
    "question": "In which town was Jesus born?",
    "subject": "CRS",
    "generalFeedback": "The New Testament Gospels of Matthew and Luke describe Jesus' birth in a specific town in Judea, also known as the 'City of David'.",
    "answers": [
      {"text": "Jerusalem", "feedback": "Incorrect. Jesus visited and taught in Jerusalem, but he was not born there."},
      {"text": "Nazareth", "feedback": "Incorrect. Jesus grew up in Nazareth, but it was not his birthplace."},
      {"text": "Bethlehem", "feedback": "Correct. Prophecy was fulfilled when Mary and Joseph traveled to Bethlehem for a census, where Jesus was born."},
      {"text": "Galilee", "feedback": "Incorrect. Galilee is a region where Jesus conducted much of his ministry, not his birth town."}
    ],
    "correctAnswer": "Bethlehem"
  },
  {
    "id": 44,
    "question": "What do the letters 'ICT' stand for?",
    "subject": "ICT",
    "generalFeedback": "ICT is a broad term that covers all technologies used for handling telecommunications, broadcast media, and computer networks.",
    "answers": [
      {"text": "Information and Computer Time", "feedback": "Incorrect. 'Time' is not part of the acronym."},
      {"text": "Internal Communication Technology", "feedback": "Incorrect. It refers to more than just internal communication."},
      {"text": "Information and Communication Technology", "feedback": "Correct. This is the full meaning of the acronym ICT."},
      {"text": "Internet and Computer Transfer", "feedback": "Incorrect. While it involves the internet, this is not the correct full form."}
    ],
    "correctAnswer": "Information and Communication Technology"
  },
  {
    "id": 45,
    "question": "Which of these is an example of a computer INPUT device?",
    "subject": "ICT",
    "generalFeedback": "Input devices are pieces of computer hardware used to provide data and control signals to a computer's information processing system.",
    "answers": [
      {"text": "A printer", "feedback": "Incorrect. A printer is an output device; it takes information from the computer and puts it on paper."},
      {"text": "A monitor", "feedback": "Incorrect. A monitor is an output device; it displays information from the computer."},
      {"text": "A keyboard", "feedback": "Correct. A keyboard is used to input text and commands into the computer."},
      {"text": "Speakers", "feedback": "Incorrect. Speakers are output devices; they produce sound from the computer."}
    ],
    "correctAnswer": "A keyboard"
  },
  {
    "id": 46,
    "question": "The 'brain' of the computer, which performs most of the calculations, is the ____.",
    "subject": "ICT",
    "generalFeedback": "This is the primary component of a computer that processes instructions. It is found inside the system unit.",
    "answers": [
      {"text": "Monitor", "feedback": "Incorrect. The monitor is a screen for displaying output."},
      {"text": "Hard Drive", "feedback": "Incorrect. The hard drive is used for long-term storage of data."},
      {"text": "CPU (Central Processing Unit)", "feedback": "Correct. The CPU is responsible for executing instructions and is often called the 'brain' of the computer."},
      {"text": "RAM (Random Access Memory)", "feedback": "Incorrect. RAM is the computer's short-term memory."}
    ],
    "correctAnswer": "CPU (Central Processing Unit)"
  },
  {
    "id": 47,
    "question": "Microsoft Windows is an example of:",
    "subject": "ICT",
    "generalFeedback": "Computer software is divided into two main categories: system software, which manages the computer hardware, and application software, which performs specific tasks for the user.",
    "answers": [
      {"text": "Application Software", "feedback": "Incorrect. Application software includes programs like Word or a web browser. Windows manages the entire system."},
      {"text": "Hardware", "feedback": "Incorrect. Windows is a program; you cannot physically touch it. Hardware refers to the physical components."},
      {"text": "System Software (Operating System)", "feedback": "Correct. Windows is an operating system, which is a type of system software that manages all other software and hardware on the computer."},
      {"text": "An input device", "feedback": "Incorrect. An input device is a piece of hardware like a mouse or keyboard."}
    ],
    "correctAnswer": "System Software (Operating System)"
  },
  {
    "id": 48,
    "question": "Kedu maka ije?",
    "subject": "Igbo",
    "generalFeedback": "This is a common Igbo phrase used when someone is about to leave or is on a journey. It's a way of wishing them well.",
    "answers": [
      {"text": "Ndeewo", "feedback": "Incorrect. 'Ndeewo' means 'well done' or 'welcome'."},
      {"text": "Gaa nke ọma", "feedback": "Correct. This means 'Go well' and is the appropriate response."},
      {"text": "Daalụ", "feedback": "Incorrect. 'Daalụ' means 'thank you'."},
      {"text": "Ọ dị mma", "feedback": "Incorrect. This means 'It is fine' or 'okay', which is a possible but less specific response."}
    ],
    "correctAnswer": "Gaa nke ọma"
  },
  {
    "id": 49,
    "question": "How many vowels (udaume) are in the standard Igbo alphabet?",
    "subject": "Igbo",
    "generalFeedback": "The Igbo alphabet (Mkpụrụ Edemede Igbo) has a specific number of letters classified as vowels, which determine the pronunciation of words.",
    "answers": [
      {"text": "5", "feedback": "Incorrect. This is the number of vowels in the English alphabet."},
      {"text": "8", "feedback": "Correct. The standard Igbo alphabet has 8 vowels: a, e, i, ị, o, ọ, u, ụ."},
      {"text": "10", "feedback": "Incorrect. This number is too high."},
      {"text": "28", "feedback": "Incorrect. This is closer to the total number of consonants, not vowels."}
    ],
    "correctAnswer": "8"
  },
  {
    "id": 50,
    "question": "What is the Igbo word for 'father'?",
    "subject": "Igbo",
    "generalFeedback": "Family terms are fundamental in any language. The word for 'father' is a common and important one in Igbo culture.",
    "answers": [
      {"text": "Nne", "feedback": "Incorrect. 'Nne' means 'mother'."},
      {"text": "Nna", "feedback": "Correct. 'Nna' is the Igbo word for 'father'."},
      {"text": "Nwa", "feedback": "Incorrect. 'Nwa' means 'child'."},
      {"text": "Dede", "feedback": "Incorrect. 'Dede' means 'senior brother' or is used as a term of respect for an older male."}
    ],
    "correctAnswer": "Nna"
  },
  {
    "id": 51,
    "question": "The number 'ise' in Igbo is:",
    "subject": "Igbo",
    "generalFeedback": "Learning to count is a basic part of any language. You need to match the Igbo word to its English number equivalent.",
    "answers": [
      {"text": "Three", "feedback": "Incorrect. 'Three' is 'atọ'."},
      {"text": "Four", "feedback": "Incorrect. 'Four' is 'anọ'."},
      {"text": "Five", "feedback": "Correct. 'Ise' is the Igbo word for the number five."},
      {"text": "Six", "feedback": "Incorrect. 'Six' is 'isii'."}
    ],
    "correctAnswer": "Five"
  },
  {
    "id": 52,
    "question": "Which of these is a key aspect of personal hygiene?",
    "subject": "Home Economics",
    "generalFeedback": "Personal hygiene refers to practices that maintain health and prevent the spread of diseases. It involves keeping the body clean.",
    "answers": [
      {"text": "Watching television", "feedback": "Incorrect. This is a leisure activity and not related to hygiene."},
      {"text": "Bathing regularly", "feedback": "Correct. Regular bathing with soap and water removes dirt, sweat, and germs from the skin."},
      {"text": "Sleeping for a long time", "feedback": "Incorrect. While sleep is important for health, it is not a hygiene practice."},
      {"text": "Eating a lot of food", "feedback": "Incorrect. This relates to nutrition, not hygiene."}
    ],
    "correctAnswer": "Bathing regularly"
  },
  {
    "id": 53,
    "question": "Foods like meat, fish, and beans are rich in ________, which helps the body to grow and repair tissues.",
    "subject": "Home Economics",
    "generalFeedback": "Different classes of food perform different functions in the body. The nutrient responsible for building the body is essential for growth.",
    "answers": [
      {"text": "Carbohydrates", "feedback": "Incorrect. Carbohydrates (like yam and rice) are the main source of energy."},
      {"text": "Vitamins", "feedback": "Incorrect. Vitamins (found in fruits and vegetables) are needed for fighting diseases."},
      {"text": "Fats and Oils", "feedback": "Incorrect. Fats and oils provide energy and warmth."},
      {"text": "Proteins", "feedback": "Correct. Proteins are the 'body-building' foods necessary for growth and repair."}
    ],
    "correctAnswer": "Proteins"
  },
  {
    "id": 54,
    "question": "Why is it important to wash your hands before cooking?",
    "subject": "Home Economics",
    "generalFeedback": "Kitchen hygiene is crucial for food safety. Handwashing is a simple but very effective step.",
    "answers": [
      {"text": "To make your hands soft", "feedback": "Incorrect. While soap might soften hands, this is not the primary reason."},
      {"text": "To warm up your hands for cooking", "feedback": "Incorrect. The temperature of your hands is not the main concern."},
      {"text": "To prevent the transfer of germs to the food", "feedback": "Correct. Hands can carry harmful bacteria that can contaminate food and cause illness."},
      {"text": "To make the food taste better", "feedback": "Incorrect. Clean hands do not change the flavour of the food."}
    ],
    "correctAnswer": "To prevent the transfer of germs to the food"
  },
  {
    "id": 55,
    "question": "A simple stitch used for temporarily holding pieces of fabric together is called:",
    "subject": "Home Economics",
    "generalFeedback": "In basic sewing, different stitches serve different purposes. One type of stitch is specifically designed to be easily removed later.",
    "answers": [
      {"text": "A running stitch", "feedback": "Incorrect. A running stitch is a permanent, simple stitch."},
      {"text": "A backstitch", "feedback": "Incorrect. A backstitch is a strong, permanent stitch."},
      {"text": "A tacking or basting stitch", "feedback": "Correct. Tacking stitches are large, loose stitches used for temporarily holding seams before final sewing."},
      {"text": "A chain stitch", "feedback": "Incorrect. A chain stitch is a decorative, permanent stitch."}
    ],
    "correctAnswer": "A tacking or basting stitch"
  },
  {
    "id": 56,
    "question": "How would you say 'Hello' in French?",
    "subject": "French",
    "generalFeedback": "This is one of the most common greetings in French, used during the daytime.",
    "answers": [
      {"text": "Au revoir", "feedback": "Incorrect. 'Au revoir' means 'Goodbye'."},
      {"text": "Merci", "feedback": "Incorrect. 'Merci' means 'Thank you'."},
      {"text": "Bonjour", "feedback": "Correct. 'Bonjour' means 'Good day' or 'Hello'."},
      {"text": "Oui", "feedback": "Incorrect. 'Oui' means 'Yes'."}
    ],
    "correctAnswer": "Bonjour"
  },
  {
    "id": 57,
    "question": "What is the French word for the number 'three'?",
    "subject": "French",
    "generalFeedback": "Learning numbers is a basic step in acquiring a new language. You need to know the French equivalent of 'three'.",
    "answers": [
      {"text": "Un", "feedback": "Incorrect. 'Un' means 'one'."},
      {"text": "Deux", "feedback": "Incorrect. 'Deux' means 'two'."},
      {"text": "Trois", "feedback": "Correct. 'Trois' is the French word for 'three'."},
      {"text": "Quatre", "feedback": "Incorrect. 'Quatre' means 'four'."}
    ],
    "correctAnswer": "Trois"
  },
  {
    "id": 58,
    "question": "The verb 'être' in French means:",
    "subject": "French",
    "generalFeedback": "'Être' is one of the most important and frequently used verbs in the French language. It is an irregular verb.",
    "answers": [
      {"text": "To have", "feedback": "Incorrect. 'To have' is 'avoir'."},
      {"text": "To go", "feedback": "Incorrect. 'To go' is 'aller'."},
      {"text": "To do", "feedback": "Incorrect. 'To do' or 'to make' is 'faire'."},
      {"text": "To be", "feedback": "Correct. 'Être' is the verb 'to be'."}
    ],
    "correctAnswer": "To be"
  },
  {
    "id": 59,
    "question": "Which of these is a day of the week in French?",
    "subject": "French",
    "generalFeedback": "The days of the week are part of the basic vocabulary for talking about time and schedules.",
    "answers": [
      {"text": "Janvier", "feedback": "Incorrect. 'Janvier' is a month (January)."},
      {"text": "Lundi", "feedback": "Correct. 'Lundi' is Monday."},
      {"text": "Matin", "feedback": "Incorrect. 'Matin' means 'morning'."},
      {"text": "École", "feedback": "Incorrect. 'École' means 'school'."}
    ],
    "correctAnswer": "Lundi"
  },
  {
    "id": 60,
    "question": "Find the next number in the sequence: 2, 4, 6, 8, __",
    "subject": "Mathematics",
    "generalFeedback": "This is an arithmetic sequence. To find the next number, you need to identify the common difference between consecutive terms and add it to the last term.",
    "answers": [
        {"text": "9", "feedback": "Incorrect. The pattern is adding 2 each time, not alternating odd and even numbers."},
        {"text": "12", "feedback": "Incorrect. You skipped a number. The next number after 8 is 8 + 2."},
        {"text": "10", "feedback": "Correct. Each number is 2 more than the previous one (8 + 2 = 10)."},
        {"text": "16", "feedback": "Incorrect. This would be the result of multiplying by 2, but the sequence is based on addition."}
    ],
    "correctAnswer": "10"
  },
  {
    "id": 61,
    "question": "Which sentence is in the simple present tense?",
    "subject": "English",
    "generalFeedback": "The simple present tense is used to describe habits, un-changing situations, general truths, and fixed arrangements.",
    "answers": [
        {"text": "He is playing football.", "feedback": "Incorrect. This is the present continuous tense, describing an action happening now."},
        {"text": "He played football.", "feedback": "Incorrect. This is the simple past tense, describing a completed action."},
        {"text": "He plays football every day.", "feedback": "Correct. This describes a habitual action, which is a key use of the simple present tense."},
        {"text": "He will play football.", "feedback": "Incorrect. This is the simple future tense, describing a future action."}
    ],
    "correctAnswer": "He plays football every day."
  },
  {
    "id": 62,
    "question": "The energy an object has due to its motion is called:",
    "subject": "Basic Science",
    "generalFeedback": "Energy comes in many forms. There is a specific name for the energy associated with movement.",
    "answers": [
        {"text": "Potential energy", "feedback": "Incorrect. Potential energy is stored energy, often due to an object's position or height."},
        {"text": "Kinetic energy", "feedback": "Correct. Kinetic energy is the energy of motion. A moving car has kinetic energy."},
        {"text": "Chemical energy", "feedback": "Incorrect. Chemical energy is stored in the bonds of chemical compounds, like in food or batteries."},
        {"text": "Thermal energy", "feedback": "Incorrect. Thermal energy is related to the heat of an object."}
    ],
    "correctAnswer": "Kinetic energy"
  },
  {
    "id": 63,
    "question": "What does a set square help you draw in technical drawing?",
    "subject": "Basic Technology",
    "generalFeedback": "Set squares are triangular drawing tools used in conjunction with a T-square to create accurate angles and lines.",
    "answers": [
        {"text": "Perfect freehand circles", "feedback": "Incorrect. Freehand drawing does not use tools, and a compass is used for perfect circles."},
        {"text": "Curved lines", "feedback": "Incorrect. A French curve is used for drawing curved lines."},
        {"text": "Vertical and angled lines", "feedback": "Correct. A set square, when placed on a T-square, can be used to draw vertical lines (90°) and angled lines (like 30°, 45°, 60°)."},
        {"text": "Shading and texture", "feedback": "Incorrect. Shading is a technique done with pencils, not a set square."}
    ],
    "correctAnswer": "Vertical and angled lines"
  },
  {
    "id": 64,
    "question": "The ancient Oyo Empire was famous for its powerful:",
    "subject": "History",
    "generalFeedback": "The Oyo Empire, a Yoruba empire, was one of the largest and most powerful in West Africa. Its military strength was based on a particular unit.",
    "answers": [
        {"text": "Navy", "feedback": "Incorrect. Oyo was an inland empire and did not have a powerful navy."},
        {"text": "Air force", "feedback": "Incorrect. Air forces are a modern military invention."},
        {"text": "Cavalry", "feedback": "Correct. The Oyo Empire's military might was centered on its skilled and organized cavalry (horsemen)."},
        {"text": "Bronze sculptures", "feedback": "Incorrect. This is a characteristic of the Benin Kingdom."}
    ],
    "correctAnswer": "Cavalry"
  },
  {
    "id": 65,
    "question": "The top layer of the earth's surface where plants grow is called:",
    "subject": "Agricultural Science",
    "generalFeedback": "This layer is a mixture of organic matter, minerals, gases, liquids, and organisms that together support life.",
    "answers": [
        {"text": "Rock", "feedback": "Incorrect. Rock is the solid mineral material forming part of the earth's surface, often found beneath the top layer."},
        {"text": "Water", "feedback": "Incorrect. Water is a liquid essential for life, but it is not the growing medium itself."},
        {"text": "Soil", "feedback": "Correct. Soil is the specific term for the upper layer of earth in which plants grow."},
        {"text": "Sand", "feedback": "Incorrect. Sand is a type of soil, but 'soil' is the more general and correct term."}
    ],
    "correctAnswer": "Soil"
  },
  {
    "id": 66,
    "question": "A feeling of love and pride for one's country is called:",
    "subject": "Social Humanity",
    "generalFeedback": "This is an important civic value that encourages citizens to be loyal and supportive of their nation.",
    "answers": [
        {"text": "Culture", "feedback": "Incorrect. Culture is the way of life of a people."},
        {"text": "Government", "feedback": "Incorrect. Government is the system of rule."},
        {"text": "Patriotism", "feedback": "Correct. Patriotism is the devotion to and vigorous support for one's country."},
        {"text": "Family", "feedback": "Incorrect. This is love for one's family, not country."}
    ],
    "correctAnswer": "Patriotism"
  },
  {
    "id": 67,
    "question": "What is the main goal of a business?",
    "subject": "Business Studies",
    "generalFeedback": "While businesses have many objectives, there is one primary financial goal that drives their operations.",
    "answers": [
        {"text": "To provide free services", "feedback": "Incorrect. Non-profit or charitable organizations do this, not typical businesses."},
        {"text": "To make a profit", "feedback": "Correct. The fundamental aim of a commercial enterprise is to generate profit by ensuring revenue exceeds costs."},
        {"text": "To employ as many people as possible", "feedback": "Incorrect. While businesses create employment, it is a byproduct of their main goal, not the goal itself."},
        {"text": "To follow government rules", "feedback": "Incorrect. Following rules is a requirement (compliance), not the main goal."}
    ],
    "correctAnswer": "To make a profit"
  },
  {
    "id": 68,
    "question": "The use of contrasting colours, like black and white, side-by-side in art is an example of:",
    "subject": "Creative Art",
    "generalFeedback": "Artists use principles of design to organize the elements of art. One principle involves creating a strong visual difference to draw attention.",
    "answers": [
        {"text": "Balance", "feedback": "Incorrect. Balance refers to the visual weight of elements in a composition."},
        {"text": "Rhythm", "feedback": "Incorrect. Rhythm suggests movement through the repetition of elements."},
        {"text": "Contrast", "feedback": "Correct. Contrast is the arrangement of opposite elements (light vs. dark, rough vs. smooth) to create visual interest."},
        {"text": "Unity", "feedback": "Incorrect. Unity is the feeling of harmony between all parts of the work of art."}
    ],
    "correctAnswer": "Contrast"
  },
  {
    "id": 69,
    "question": "In the story of David and Goliath, what did David use to defeat the giant?",
    "subject": "CRS",
    "generalFeedback": "The biblical story emphasizes David's faith and courage, using a simple shepherd's tool against a heavily armed warrior.",
    "answers": [
        {"text": "A sword", "feedback": "Incorrect. He used Goliath's sword only after the giant had fallen."},
        {"text": "A spear", "feedback": "Incorrect. Goliath was armed with a spear, but David was not."},
        {"text": "A sling and a stone", "feedback": "Correct. David, a skilled shepherd, used his sling to hurl a stone that struck Goliath in the forehead."},
        {"text": "A bow and arrow", "feedback": "Incorrect. The story specifically mentions a sling, not a bow and arrow."}
    ],
    "correctAnswer": "A sling and a stone"
  },
  {
    "id": 70,
    "question": "What is a major risk of sharing personal information online?",
    "subject": "ICT",
    "generalFeedback": "The internet provides many benefits, but it's important to be aware of the dangers of sharing private details like your address or phone number.",
    "answers": [
        {"text": "Your computer might slow down.", "feedback": "Incorrect. Sharing information doesn't typically affect computer speed."},
        {"text": "You could win a prize.", "feedback": "Incorrect. While there are legitimate competitions, sharing information is more often a risk than a benefit."},
        {"text": "Strangers could use it to harm you.", "feedback": "Correct. People with bad intentions can use your personal information for identity theft, bullying, or even physical harm."},
        {"text": "You will get more friend requests.", "feedback": "Incorrect. While possible, the primary concern is safety and privacy."}
    ],
    "correctAnswer": "Strangers could use it to harm you."
  },
  {
    "id": 71,
    "question": "The Igbo greeting for the morning is:",
    "subject": "Igbo",
    "generalFeedback": "Greetings are an important part of Igbo culture and vary depending on the time of day.",
    "answers": [
        {"text": "Ka chi fọ", "feedback": "Incorrect. This means 'Good night'."},
        {"text": "I boola?", "feedback": "Incorrect. This is an alternative morning greeting asking 'Have you woken up?', but 'ụtụtụ ọma' is the direct translation."},
        {"text": "Nnọọ", "feedback": "Incorrect. This means 'Welcome'."},
        {"text": "Ị bọla chi / Ụtụtụ ọma", "feedback": "Correct. Both 'Ị bọla chi?' (Have you woken into a new day?) and 'Ụtụtụ ọma' (Good morning) are correct greetings."}
    ],
    "correctAnswer": "Ị bọla chi / Ụtụtụ ọma"
  },
  {
    "id": 72,
    "question": "Yams, cassava, and potatoes are examples of foods that provide the body with:",
    "subject": "Home Economics",
    "generalFeedback": "These are staple foods known as energy-giving foods. They belong to a specific class of nutrients.",
    "answers": [
        {"text": "Protein", "feedback": "Incorrect. These foods are low in protein."},
        {"text": "Vitamins", "feedback": "Incorrect. While they contain some vitamins, it's not their main contribution."},
        {"text": "Carbohydrates", "feedback": "Correct. These are starchy foods, which are a major source of carbohydrates for energy."},
        {"text": "Water", "feedback": "Incorrect. They contain water, but their primary nutrient is carbohydrate."}
    ],
    "correctAnswer": "Carbohydrates"
  },
  {
    "id": 73,
    "question": "What does 'Je m'appelle' mean in French?",
    "subject": "French",
    "generalFeedback": "This is a fundamental phrase used for introductions in French.",
    "answers": [
        {"text": "I am going", "feedback": "Incorrect. 'I am going' is 'Je vais'."},
        {"text": "I have", "feedback": "Incorrect. 'I have' is 'J'ai'."},
        {"text": "My name is", "feedback": "Correct. 'Je m'appelle' is used to state your name."},
        {"text": "I like", "feedback": "Incorrect. 'I like' is 'J'aime'."}
    ],
    "correctAnswer": "My name is"
  },
  {
    "id": 74,
    "question": "If a shirt costs ₦2,000 and is sold at a 10% discount, what is the new price?",
    "subject": "Mathematics",
    "generalFeedback": "To find the discount amount, calculate 10% of the original price. Then, subtract the discount amount from the original price to get the new price.",
    "answers": [
        {"text": "₦200", "feedback": "Incorrect. This is the discount amount, not the final price."},
        {"text": "₦2,200", "feedback": "Incorrect. You added the discount instead of subtracting it."},
        {"text": "₦1,800", "feedback": "Correct. 10% of ₦2,000 is ₦200. The new price is ₦2,000 - ₦200 = ₦1,800."},
        {"text": "₦1,990", "feedback": "Incorrect. Check your percentage calculation."}
    ],
    "correctAnswer": "₦1,800"
  },
  {
    "id": 75,
    "question": "Which of these is a synonym for 'happy'?",
    "subject": "English",
    "generalFeedback": "A synonym is a word that has the same or nearly the same meaning as another word.",
    "answers": [
        {"text": "Sad", "feedback": "Incorrect. 'Sad' is an antonym (opposite) of 'happy'."},
        {"text": "Angry", "feedback": "Incorrect. 'Angry' describes a different emotion."},
        {"text": "Joyful", "feedback": "Correct. 'Joyful' means full of happiness."},
        {"text": "Tired", "feedback": "Incorrect. 'Tired' describes a state of low energy."}
    ],
    "correctAnswer": "Joyful"
  },
  {
    "id": 76,
    "question": "The process by which plants make their own food using sunlight is called:",
    "subject": "Basic Science",
    "generalFeedback": "This is a vital process for life on Earth, as it produces oxygen and is the foundation of most food chains. It requires sunlight, water, and carbon dioxide.",
    "answers": [
        {"text": "Respiration", "feedback": "Incorrect. Respiration is the process of releasing energy from food."},
        {"text": "Photosynthesis", "feedback": "Correct. 'Photo' means light and 'synthesis' means to make. Plants use light to make food."},
        {"text": "Transpiration", "feedback": "Incorrect. Transpiration is the loss of water vapour from plants."},
        {"text": "Germination", "feedback": "Incorrect. Germination is the process of a seed sprouting into a plant."}
    ],
    "correctAnswer": "Photosynthesis"
  },
  {
    "id": 77,
    "question": "A metal that is attracted to a magnet is described as:",
    "subject": "Basic Technology",
    "generalFeedback": "Materials have different properties. The property of being attracted by a magnet has a specific scientific name.",
    "answers": [
        {"text": "Ductile", "feedback": "Incorrect. Ductility is the ability to be drawn into a wire."},
        {"text": "Malleable", "feedback": "Incorrect. Malleability is the ability to be hammered into a thin sheet."},
        {"text": "Magnetic", "feedback": "Correct. Materials like iron, nickel, and cobalt that are attracted to magnets are called magnetic materials."},
        {"text": "Brittle", "feedback": "Incorrect. Brittle means the material breaks easily without bending."}
    ],
    "correctAnswer": "Magnetic"
  },
  {
    "id": 78,
    "question": "Who was the first Prime Minister of Nigeria?",
    "subject": "History",
    "generalFeedback": "Upon gaining independence in 1960, Nigeria was led by a key northern political figure who served as the head of government.",
    "answers": [
        {"text": "Nnamdi Azikiwe", "feedback": "Incorrect. Nnamdi Azikiwe was the first President of Nigeria (a ceremonial role at the time)."},
        {"text": "Obafemi Awolowo", "feedback": "Incorrect. Obafemi Awolowo was the Premier of the Western Region and later the leader of the opposition."},
        {"text": "Abubakar Tafawa Balewa", "feedback": "Correct. Sir Abubakar Tafawa Balewa was the first and only Prime Minister of Nigeria."},
        {"text": "Ahmadu Bello", "feedback": "Incorrect. Ahmadu Bello was the Premier of the Northern Region."}
    ],
    "correctAnswer": "Abubakar Tafawa Balewa"
  },
  {
    "id": 79,
    "question": "The rearing of birds like chicken and turkey for meat and eggs is known as:",
    "subject": "Agricultural Science",
    "generalFeedback": "This is a specific branch of animal husbandry focused on domestic birds.",
    "answers": [
        {"text": "Fishery", "feedback": "Incorrect. Fishery is the rearing of fish."},
        {"text": "Piggery", "feedback": "Incorrect. Piggery is the rearing of pigs."},
        {"text": "Poultry farming", "feedback": "Correct. This is the correct term for raising domestic birds."},
        {"text": "Apiculture", "feedback": "Incorrect. Apiculture is beekeeping."}
    ],
    "correctAnswer": "Poultry farming"
  },
  {
    "id": 80,
    "question": "A group of people who are related by blood, marriage, or adoption is called a:",
    "subject": "Social Humanity",
    "generalFeedback": "This is the core definition of the fundamental unit of society.",
    "answers": [
        {"text": "Peer group", "feedback": "Incorrect. A peer group consists of people of the same age or social status."},
        {"text": "Community", "feedback": "Incorrect. A community is a group of people living in the same place."},
        {"text": "Family", "feedback": "Correct. This is the definition of a family."},
        {"text": "Club", "feedback": "Incorrect. A club is a group of people with a common interest."}
    ],
    "correctAnswer": "Family"
  },
  {
    "id": 81,
    "question": "In bookkeeping, a 'Debit' entry is typically recorded on which side of an account?",
    "subject": "Business Studies",
    "generalFeedback": "The double-entry bookkeeping system is based on the principle that every transaction has two effects. The 'T' account has a left and a right side with specific names.",
    "answers": [
        {"text": "The left-hand side", "feedback": "Correct. By convention, debits are recorded on the left side of a T-account."},
        {"text": "The right-hand side", "feedback": "Incorrect. The right-hand side is for credit entries."},
        {"text": "The top", "feedback": "Incorrect. The top is for the account title."},
        {"text": "The bottom", "feedback": "Incorrect. The bottom is for totals."}
    ],
    "correctAnswer": "The left-hand side"
  },
  {
    "id": 82,
    "question": "A person who creates a sculpture is called a:",
    "subject": "Creative Art",
    "generalFeedback": "Different forms of art have specific names for the artists who practice them.",
    "answers": [
        {"text": "Musician", "feedback": "Incorrect. A musician creates or performs music."},
        {"text": "Dancer", "feedback": "Incorrect. A dancer performs dances."},
        {"text": "Sculptor", "feedback": "Correct. A sculptor is an artist who creates three-dimensional artworks."},
        {"text": "Poet", "feedback": "Incorrect. A poet writes poetry."}
    ],
    "correctAnswer": "Sculptor"
  },
  {
    "id": 83,
    "question": "Which of these instruments belongs to the string family?",
    "subject": "Music",
    "generalFeedback": "Musical instruments are classified into families based on how they produce sound. String instruments produce sound from vibrating strings.",
    "answers": [
        {"text": "A drum", "feedback": "Incorrect. A drum is a percussion instrument."},
        {"text": "A flute", "feedback": "Incorrect. A flute is a woodwind instrument."},
        {"text": "A guitar", "feedback": "Correct. A guitar produces sound by plucking its strings."},
        {"text": "A trumpet", "feedback": "Incorrect. A trumpet is a brass instrument."}
    ],
    "correctAnswer": "A guitar"
  },
  {
    "id": 84,
    "question": "What miracle is Jesus most famous for performing with five loaves and two fish?",
    "subject": "CRS",
    "generalFeedback": "This is a well-known miracle recorded in all four Gospels, demonstrating Jesus' power to provide for a large crowd.",
    "answers": [
        {"text": "Walking on water", "feedback": "Incorrect. This is another famous miracle, but it did not involve bread and fish."},
        {"text": "Healing a blind man", "feedback": "Incorrect. Jesus performed many healing miracles, but this one was about provision."},
        {"text": "Feeding five thousand people", "feedback": "Correct. Jesus multiplied the small amount of food to feed a crowd of over 5,000 men, plus women and children."},
        {"text": "Calming a storm", "feedback": "Incorrect. This miracle demonstrated his power over nature, but not over food."}
    ],
    "correctAnswer": "Feeding five thousand people"
  },
  {
    "id": 85,
    "question": "Which software would be best for writing a letter or an essay?",
    "subject": "ICT",
    "generalFeedback": "Different types of application software are designed for specific tasks. For tasks involving mostly text, a particular category of software is used.",
    "answers": [
        {"text": "A spreadsheet program (e.g., Excel)", "feedback": "Incorrect. Spreadsheets are best for calculations and organizing data in tables."},
        {"text": "A web browser (e.g., Chrome)", "feedback": "Incorrect. A web browser is used to access the internet."},
        {"text": "A word processor (e.g., Microsoft Word)", "feedback": "Correct. Word processors are specifically designed for creating, editing, and formatting text-based documents."},
        {"text": "A presentation program (e.g., PowerPoint)", "feedback": "Incorrect. Presentation software is used to create slides for a speech or lecture."}
    ],
    "correctAnswer": "A word processor (e.g., Microsoft Word)"
  },
  {
    "id": 86,
    "question": "The Igbo word for 'child' is:",
    "subject": "Igbo",
    "generalFeedback": "This is a fundamental vocabulary word related to the family.",
    "answers": [
        {"text": "Eze", "feedback": "Incorrect. 'Eze' means 'king'."},
        {"text": "Mmadụ", "feedback": "Incorrect. 'Mmadụ' means 'person' or 'human being'."},
        {"text": "Nwa", "feedback": "Correct. 'Nwa' is the Igbo word for 'child'."},
        {"text": "Onyi", "feedback": "Incorrect. 'Onyi' means 'friend'."}
    ],
    "correctAnswer": "Nwa"
  },
  {
    "id": 87,
    "question": "Which of these is NOT a good way to care for your clothes?",
    "subject": "Home Economics",
    "generalFeedback": "Proper care of clothes helps them last longer and look better. This involves cleaning, repairing, and storing them correctly.",
    "answers": [
        {"text": "Washing them when they are dirty", "feedback": "Incorrect. This is a good way to care for clothes."},
        {"text": "Mending any rips or tears", "feedback": "Incorrect. Repairing clothes is an important part of caring for them."},
        {"text": "Storing them in a clean, dry place", "feedback": "Incorrect. Proper storage prevents damage from mould and pests."},
        {"text": "Leaving them in a pile on the floor when wet", "feedback": "Correct. This is a bad practice that can lead to mildew, bad smells, and damage to the fabric."}
    ],
    "correctAnswer": "Leaving them in a pile on the floor when wet"
  },
  {
    "id": 88,
    "question": "The French word for 'cat' is:",
    "subject": "French",
    "generalFeedback": "Learning the names of common animals is a fun part of building vocabulary in a new language.",
    "answers": [
        {"text": "Chien", "feedback": "Incorrect. 'Chien' means 'dog'."},
        {"text": "Livre", "feedback": "Incorrect. 'Livre' means 'book'."},
        {"text": "Chat", "feedback": "Correct. 'Le chat' is the French word for 'the cat'."},
        {"text": "Poisson", "feedback": "Incorrect. 'Poisson' means 'fish'."}
    ],
    "correctAnswer": "Chat"
  },
  {
    "id": 89,
    "question": "What is the area of a square with a side length of 6cm?",
    "subject": "Mathematics",
    "generalFeedback": "The area of a square is calculated by multiplying the length of one side by itself (Area = side × side or side²).",
    "answers": [
      {"text": "24cm", "feedback": "Incorrect. This is the perimeter of the square (6cm × 4)."},
      {"text": "12cm²", "feedback": "Incorrect. This is the result of multiplying the side by 2."},
      {"text": "36cm²", "feedback": "Correct. The area is 6cm × 6cm = 36cm²."},
      {"text": "6cm²", "feedback": "Incorrect. You need to multiply the side length by itself."}
    ],
    "correctAnswer": "36cm²"
  },
  {
    "id": 90,
    "question": "An antonym for the word 'brave' is:",
    "subject": "English",
    "generalFeedback": "An antonym is a word that has the opposite meaning of another word.",
    "answers": [
      {"text": "Courageous", "feedback": "Incorrect. This is a synonym for brave."},
      {"text": "Strong", "feedback": "Incorrect. While related, 'strong' is not the direct opposite of 'brave'."},
      {"text": "Cowardly", "feedback": "Correct. 'Cowardly' means lacking courage, which is the opposite of being brave."},
      {"text": "Bold", "feedback": "Incorrect. This is another synonym for brave."}
    ],
    "correctAnswer": "Cowardly"
  },
  {
    "id": 91,
    "question": "A change from a liquid to a gas is called:",
    "subject": "Basic Science",
    "generalFeedback": "This change of state occurs when a liquid is heated to its boiling point.",
    "answers": [
      {"text": "Melting", "feedback": "Incorrect. Melting is the change from a solid to a liquid."},
      {"text": "Freezing", "feedback": "Incorrect. Freezing is the change from a liquid to a solid."},
      {"text": "Evaporation", "feedback": "Correct. Evaporation (or boiling) is the process where a liquid turns into a gas."},
      {"text": "Condensation", "feedback": "Incorrect. Condensation is the change from a gas to a liquid."}
    ],
    "correctAnswer": "Evaporation"
  },
  {
    "id": 92,
    "question": "A tool used to drive nails into wood is a:",
    "subject": "Basic Technology",
    "generalFeedback": "This is a fundamental tool in woodwork and construction, used for impact.",
    "answers": [
      {"text": "Screwdriver", "feedback": "Incorrect. A screwdriver is used to turn screws."},
      {"text": "Saw", "feedback": "Incorrect. A saw is used for cutting."},
      {"text": "Hammer", "feedback": "Correct. A hammer is designed to strike things, most commonly nails."},
      {"text": "Pliers", "feedback": "Incorrect. Pliers are used for gripping and pulling things."}
    ],
    "correctAnswer": "Hammer"
  },
  {
    "id": 93,
    "question": "What was the main purpose of the Berlin Conference of 1884-1885?",
    "subject": "History",
    "generalFeedback": "This conference was a meeting of European powers that had a significant and lasting impact on the continent of Africa.",
    "answers": [
      {"text": "To end the slave trade.", "feedback": "Incorrect. While the slave trade was discussed, the primary purpose was different."},
      {"text": "To promote African unity.", "feedback": "Incorrect. The conference was held by European powers, not African ones, and it did the opposite of promoting unity."},
      {"text": "To regulate European colonization and trade in Africa.", "feedback": "Correct. It was convened to peacefully divide Africa among European powers, an event known as the 'Scramble for Africa'."},
      {"text": "To form an alliance against Asia.", "feedback": "Incorrect. The focus was solely on the colonization of Africa."}
    ],
    "correctAnswer": "To regulate European colonization and trade in Africa."
  },
  {
    "id": 94,
    "question": "What is 'crop rotation'?",
    "subject": "Agricultural Science",
    "generalFeedback": "This is a farming practice designed to manage soil fertility and combat pests and diseases.",
    "answers": [
      {"text": "Watering crops in a circle.", "feedback": "Incorrect. This describes a method of irrigation, not crop rotation."},
      {"text": "Growing different crops in the same area in different seasons.", "feedback": "Correct. This practice helps to prevent the depletion of specific soil nutrients and breaks the life cycles of pests."},
      {"text": "Harvesting crops very quickly.", "feedback": "Incorrect. The speed of harvesting is not related to crop rotation."},
      {"text": "Using machines to turn the crops.", "feedback": "Incorrect. This does not accurately describe any farming practice."}
    ],
    "correctAnswer": "Growing different crops in the same area in different seasons."
  },
  {
    "id": 95,
    "question": "The rights and duties of a citizen in a country are studied under:",
    "subject": "Social Humanity",
    "generalFeedback": "A specific area of Social Studies focuses on government, law, and the role of individuals within the state.",
    "answers": [
      {"text": "Geography", "feedback": "Incorrect. Geography studies the Earth's physical features and atmosphere."},
      {"text": "History", "feedback": "Incorrect. History studies past events."},
      {"text": "Civic Education", "feedback": "Correct. Civic Education deals with the rights, responsibilities, and duties of citizens."},
      {"text": "Economics", "feedback": "Incorrect. Economics studies the production, consumption, and transfer of wealth."}
    ],
    "correctAnswer": "Civic Education"
  },
  {
    "id": 96,
    "question": "A person who organizes and operates a business, taking on financial risks to do so, is called a/an:",
    "subject": "Business Studies",
    "generalFeedback": "This term describes an individual who creates a new business, bearing most of the risks and enjoying most of the rewards.",
    "answers": [
      {"text": "Employee", "feedback": "Incorrect. An employee works for someone else."},
      {"text": "Customer", "feedback": "Incorrect. A customer buys goods or services."},
      {"text": "Entrepreneur", "feedback": "Correct. This is the specific term for a business founder and risk-taker."},
      {"text": "Manager", "feedback": "Incorrect. A manager may operate a business but doesn't necessarily own it or take the primary financial risk."}
    ],
    "correctAnswer": "Entrepreneur"
  },
  {
    "id": 97,
    "question": "A type of art that is three-dimensional (has height, width, and depth) is called:",
    "subject": "Creative Art",
    "generalFeedback": "Art can be two-dimensional (like a painting) or three-dimensional. There is a specific term for 3D art.",
    "answers": [
      {"text": "A drawing", "feedback": "Incorrect. A drawing is a 2D art form."},
      {"text": "A photograph", "feedback": "Incorrect. A photograph is a 2D image."},
      {"text": "A sculpture", "feedback": "Correct. Sculptures are 3D artworks that can be viewed from all sides."},
      {"text": "A print", "feedback": "Incorrect. A print is a 2D artwork."}
    ],
    "correctAnswer": "A sculpture"
  },
  {
    "id": 98,
    "question": "Who betrayed Jesus to the authorities for thirty pieces of silver?",
    "subject": "CRS",
    "generalFeedback": "One of Jesus' twelve disciples is known for this act of betrayal, which led to Jesus' arrest and crucifixion.",
    "answers": [
      {"text": "Peter", "feedback": "Incorrect. Peter denied Jesus three times, but he did not betray him to the authorities for money."},
      {"text": "John", "feedback": "Incorrect. John was known as the disciple whom Jesus loved and was loyal to the end."},
      {"text": "Judas Iscariot", "feedback": "Correct. Judas Iscariot is the disciple who betrayed Jesus."},
      {"text": "Thomas", "feedback": "Incorrect. Thomas is known for doubting Jesus' resurrection, not for betraying him."}
    ],
    "correctAnswer": "Judas Iscariot"
  },
  {
    "id": 99,
    "question": "What does WWW stand for in a website address?",
    "subject": "ICT",
    "generalFeedback": "This acronym is a key part of the internet's infrastructure, referring to the global system of interconnected documents and web resources.",
    "answers": [
      {"text": "World Wide Web", "feedback": "Correct. This is the full name for the WWW, which is the system we use to access web pages on the internet."},
      {"text": "World Web Wide", "feedback": "Incorrect. The order of the words is wrong."},
      {"text": "Wide World Web", "feedback": "Incorrect. The order of the words is wrong."},
      {"text": "Web World Wide", "feedback": "Incorrect. The order of the words is wrong."}
    ],
    "correctAnswer": "World Wide Web"
  },
  {
    "id": 100,
    "question": "What is the Igbo word for 'God'?",
    "subject": "Igbo",
    "generalFeedback": "This is a central word in Igbo culture and spirituality, referring to the Supreme Being.",
    "answers": [
      {"text": "Mụọ", "feedback": "Incorrect. 'Mụọ' refers to a spirit or masquerade."},
      {"text": "Chukwu", "feedback": "Correct. 'Chukwu' (or 'Chineke') is the Igbo name for the Almighty God."},
      {"text": "Dibia", "feedback": "Incorrect. 'Dibia' refers to a native doctor or diviner."},
      {"text": "Chi", "feedback": "Incorrect. 'Chi' refers to a personal god or destiny, a part of the Supreme Being but not the Being itself."}
    ],
    "correctAnswer": "Chukwu"
  },
  {
    "id": 101,
    "question": "A kitchen utensil with a mesh bowl, used to separate solids from liquids, is a:",
    "subject": "Home Economics",
    "generalFeedback": "This tool is essential for tasks like draining pasta or washing vegetables.",
    "answers": [
      {"text": "Frying pan", "feedback": "Incorrect. A frying pan is used for frying food."},
      {"text": "Spatula", "feedback": "Incorrect. A spatula is used for lifting or spreading."},
      {"text": "Sieve or Strainer", "feedback": "Correct. A sieve or strainer has holes or a mesh to allow liquid to pass through while retaining solid items."},
      {"text": "Rolling pin", "feedback": "Incorrect. A rolling pin is used to flatten dough."}
    ],
    "correctAnswer": "Sieve or Strainer"
  },
  {
    "id": 102,
    "question": "How do you say 'Thank you' in French?",
    "subject": "French",
    "generalFeedback": "This is a basic polite expression used in everyday conversations.",
    "answers": [
      {"text": "S'il vous plaît", "feedback": "Incorrect. This means 'Please'."},
      {"text": "Pardon", "feedback": "Incorrect. This means 'Sorry' or 'Excuse me'."},
      {"text": "De rien", "feedback": "Incorrect. This means 'You're welcome'."},
      {"text": "Merci", "feedback": "Correct. 'Merci' is the French word for 'Thank you'."}
    ],
    "correctAnswer": "Merci"
  },
  {
    "id": 103,
    "question": "Convert the number 1101\u2082 to base 10.",
    "generalFeedback": "To convert a number from base 2 (binary) to base 10 (decimal), you multiply each digit by 2 raised to the power of its position, starting from 0 on the right. For 1101\u2082, it is (1 * 2\u00b3) + (1 * 2\u00b2) + (0 * 2\u00b9) + (1 * 2\u2070).",
    "answers": [
        {
            "text": "13",
            "feedback": "Correct. (1 * 8) + (1 * 4) + (0 * 2) + (1 * 1) = 8 + 4 + 0 + 1 = 13."
        },
        {
            "text": "11",
            "feedback": "Incorrect. This might be from incorrectly calculating the powers of 2, for example, (1*8) + (1*2) + (0*1) + (1*0)."
        },
        {
            "text": "27",
            "feedback": "Incorrect. You might have read the number from right to left or used the wrong base for conversion."
        },
        {
            "text": "6",
            "feedback": "Incorrect. This is the sum of the digits (1+1+0+1), not the value in base 10."
        }
    ],
    "correctAnswer": "13"
},
{
    "id": 104,
    "question": "Express 47\u2081\u2080 as a number in base 2.",
    "generalFeedback": "To convert a base 10 number to base 2, you use repeated division by 2 and record the remainders. You then read the remainders from bottom to top.",
    "answers": [
        {
            "text": "101111\u2082",
            "feedback": "Correct. 47\u00f72=23 R 1; 23\u00f72=11 R 1; 11\u00f72=5 R 1; 5\u00f72=2 R 1; 2\u00f72=1 R 0; 1\u00f72=0 R 1. Reading remainders up: 101111\u2082."
        },
        {
            "text": "111101\u2082",
            "feedback": "Incorrect. This happens if you read the remainders from top to bottom."
        },
        {
            "text": "101110\u2082",
            "feedback": "Incorrect. Check your division steps and remainders carefully."
        },
        {
            "text": "23.5\u2082",
            "feedback": "Incorrect. The conversion process involves repeated division and collecting remainders, not just dividing by 2 once."
        }
    ],
    "correctAnswer": "101111\u2082"
},
{
    "id": 105,
    "question": "Calculate the value of 10 + 4 x 2 - 5.",
    "generalFeedback": "This question tests the order of operations, commonly remembered by the acronym BODMAS or PEMDAS. Multiplication and Division are performed before Addition and Subtraction.",
    "answers": [
        {
            "text": "13",
            "feedback": "Correct. First, multiply 4 by 2 to get 8. Then, calculate 10 + 8 - 5, which equals 13."
        },
        {
            "text": "23",
            "feedback": "Incorrect. You might have added 10 and 4 first, which violates the order of operations."
        },
        {
            "text": "3",
            "feedback": "Incorrect. This result might come from subtracting 5 from 2 first (2-5 = -3), which is not the correct order."
        },
        {
            "text": "28",
            "feedback": "Incorrect. You may have added 10 and 4 to get 14, then multiplied by 2 to get 28. This ignores the BODMAS rule."
        }
    ],
    "correctAnswer": "13"
},
{
    "id": 106,
    "question": "What is the sum of 1/2 and 1/4?",
    "generalFeedback": "To add fractions, you must first find a common denominator. The least common multiple (LCM) of 2 and 4 is 4. Then, convert the fractions to have this denominator and add the numerators.",
    "answers": [
        {
            "text": "3/4",
            "feedback": "Correct. 1/2 is equivalent to 2/4. So, 2/4 + 1/4 = 3/4."
        },
        {
            "text": "2/6",
            "feedback": "Incorrect. It appears you added the numerators (1+1) and the denominators (2+4), which is not the correct method for adding fractions."
        },
        {
            "text": "1/3",
            "feedback": "Incorrect. This is 2/6 simplified. Remember to find a common denominator before adding."
        },
        {
            "text": "1/8",
            "feedback": "Incorrect. This looks like you might have multiplied the fractions instead of adding them."
        }
    ],
    "correctAnswer": "3/4"
},
{
    "id": 107,
    "question": "Find 20% of 150.",
    "generalFeedback": "To find the percentage of a number, convert the percentage to a fraction or a decimal and then multiply it by the number. 20% can be written as 20/100 or 0.20.",
    "answers": [
        {
            "text": "30",
            "feedback": "Correct. (20/100) * 150 = 30."
        },
        {
            "text": "20",
            "feedback": "Incorrect. This might be a guess, or a misunderstanding of how to calculate a percentage."
        },
        {
            "text": "170",
            "feedback": "Incorrect. You seem to have added 20 to 150 instead of finding the percentage."
        },
        {
            "text": "7.5",
            "feedback": "Incorrect. This would be the result if you divided 150 by 20, which is not the correct operation."
        }
    ],
    "correctAnswer": "30"
},
{
    "id": 108,
    "question": "If two angles on a straight line are 110\u00b0 and x, what is the value of x?",
    "generalFeedback": "The sum of angles on a straight line is always 180\u00b0. To find the unknown angle, subtract the known angle from 180\u00b0.",
    "answers": [
        {
            "text": "70\u00b0",
            "feedback": "Correct. 180\u00b0 - 110\u00b0 = 70\u00b0."
        },
        {
            "text": "90\u00b0",
            "feedback": "Incorrect. The sum of angles on a straight line is 180\u00b0, not 200\u00b0."
        },
        {
            "text": "250\u00b0",
            "feedback": "Incorrect. This would be the sum of 110\u00b0 and 180\u00b0. Remember to subtract from 180\u00b0."
        },
        {
            "text": "110\u00b0",
            "feedback": "Incorrect. Angles on a straight line are supplementary (add up to 180\u00b0), not necessarily equal."
        }
    ],
    "correctAnswer": "70\u00b0"
},
{
    "id": 109,
    "question": "Which of the following is a type of noun?",
    "generalFeedback": "A noun is a word that names a person, place, thing, or idea. Nouns are categorized into different types, such as proper, common, abstract, and collective.",
    "answers": [
        {
            "text": "Proper Noun",
            "feedback": "Correct. A proper noun names a specific person, place, or thing, and always begins with a capital letter (e.g., Lagos, Tunde)."
        },
        {
            "text": "Running Noun",
            "feedback": "Incorrect. 'Running' is a verb (action word), not a type of noun."
        },
        {
            "text": "Quickly Noun",
            "feedback": "Incorrect. 'Quickly' is an adverb that describes how an action is done."
        },
        {
            "text": "Beautiful Noun",
            "feedback": "Incorrect. 'Beautiful' is an adjective that describes a noun."
        }
    ],
    "correctAnswer": "Proper Noun"
},
{
    "id": 110,
    "question": "Choose the correct past tense of the verb 'go'.",
    "generalFeedback": "The past tense of a verb indicates that an action happened in the past. 'Go' is an irregular verb, meaning its past tense form doesn't follow the typical '-ed' rule.",
    "answers": [
        {
            "text": "Went",
            "feedback": "Correct. 'Went' is the simple past tense of 'go'."
        },
        {
            "text": "Goed",
            "feedback": "Incorrect. This follows the regular verb rule, but 'go' is an irregular verb."
        },
        {
            "text": "Gone",
            "feedback": "Incorrect. 'Gone' is the past participle, used with auxiliary verbs like 'has', 'have', or 'had' (e.g., 'I have gone')."
        },
        {
            "text": "Going",
            "feedback": "Incorrect. 'Going' is the present participle, indicating an ongoing action."
        }
    ],
    "correctAnswer": "Went"
},
{
    "id": 111,
    "question": "The sentence 'He is as brave as a lion' contains which figure of speech?",
    "generalFeedback": "Figures of speech are literary devices used to make language more colorful and impactful. This question is about identifying a specific type of comparison.",
    "answers": [
        {
            "text": "Simile",
            "feedback": "Correct. A simile is a figure of speech that directly compares two different things using the words 'as' or 'like'."
        },
        {
            "text": "Metaphor",
            "feedback": "Incorrect. A metaphor is a direct comparison that states one thing IS another, without using 'as' or 'like' (e.g., 'He is a lion')."
        },
        {
            "text": "Personification",
            "feedback": "Incorrect. Personification gives human qualities to inanimate objects or animals."
        },
        {
            "text": "Hyperbole",
            "feedback": "Incorrect. Hyperbole is an extreme exaggeration."
        }
    ],
    "correctAnswer": "Simile"
},
{
    "id": 112,
    "question": "Which punctuation mark is used to show possession?",
    "generalFeedback": "Punctuation marks help clarify the meaning of written sentences. Possession shows that something belongs to someone or something else.",
    "answers": [
        {
            "text": "Apostrophe (')",
            "feedback": "Correct. An apostrophe is used to show ownership, for example, 'the boy's book'."
        },
        {
            "text": "Comma (,)",
            "feedback": "Incorrect. A comma is used to separate items in a list or clauses in a sentence."
        },
        {
            "text": "Full Stop (.)",
            "feedback": "Incorrect. A full stop is used to end a declarative sentence."
        },
        {
            "text": "Question Mark (?)",
            "feedback": "Incorrect. A question mark is used at the end of a question."
        }
    ],
    "correctAnswer": "Apostrophe (')"
},
{
    "id": 113,
    "question": "Prose, Poetry, and Drama are known as ___.",
    "generalFeedback": "Literature is broadly categorized into major forms or types. Understanding these categories is fundamental to literary studies.",
    "answers": [
        {
            "text": "Genres of literature",
            "feedback": "Correct. These are the three main genres or categories of literature."
        },
        {
            "text": "Figures of speech",
            "feedback": "Incorrect. Figures of speech are devices like similes and metaphors used within the genres."
        },
        {
            "text": "Parts of a story",
            "feedback": "Incorrect. Parts of a story include plot, character, and setting."
        },
        {
            "text": "Types of sentences",
            "feedback": "Incorrect. Types of sentences relate to grammar, not literary forms."
        }
    ],
    "correctAnswer": "Genres of literature"
},
{
    "id": 114,
    "question": "Which of these is a characteristic of all living things?",
    "generalFeedback": "Living organisms share several key characteristics that distinguish them from non-living things. The acronym MRS NIGER D is often used to remember them.",
    "answers": [
        {
            "text": "Respiration",
            "feedback": "Correct. All living things respire to release energy from their food."
        },
        {
            "text": "Walking",
            "feedback": "Incorrect. While many animals walk, plants and some microorganisms do not. Movement is the characteristic, not necessarily walking."
        },
        {
            "text": "Talking",
            "feedback": "Incorrect. Only humans and some trained birds can talk. Communication is a broader characteristic, but not talking specifically."
        },
        {
            "text": "Sleeping",
            "feedback": "Incorrect. While many animals sleep, the concept doesn't apply in the same way to all living things, like bacteria or plants."
        }
    ],
    "correctAnswer": "Respiration"
},
{
    "id": 115,
    "question": "What is the basic unit of life?",
    "generalFeedback": "All living organisms are composed of fundamental building blocks. Understanding what this block is is a core concept in biology.",
    "answers": [
        {
            "text": "The cell",
            "feedback": "Correct. The cell is the smallest, most basic structural and functional unit of all known living organisms."
        },
        {
            "text": "The atom",
            "feedback": "Incorrect. An atom is the basic unit of a chemical element, which makes up both living and non-living matter, but it's not the basic unit of life itself."
        },
        {
            "text": "The tissue",
            "feedback": "Incorrect. A tissue is a group of similar cells that work together to perform a specific function."
        },
        {
            "text": "The organ",
            "feedback": "Incorrect. An organ is a collection of tissues that form a functional unit, like the heart or liver."
        }
    ],
    "correctAnswer": "The cell"
},
{
    "id": 116,
    "question": "Which of the following is a state of matter?",
    "generalFeedback": "Matter is anything that has mass and takes up space. It exists in several distinct forms, or states, with different properties.",
    "answers": [
        {
            "text": "Gas",
            "feedback": "Correct. The three common states of matter are solid, liquid, and gas."
        },
        {
            "text": "Energy",
            "feedback": "Incorrect. Energy is the capacity to do work; it is not a state of matter."
        },
        {
            "text": "Water",
            "feedback": "Incorrect. Water is a substance (a compound), which can exist in all three states: solid (ice), liquid (water), and gas (steam)."
        },
        {
            "text": "Heat",
            "feedback": "Incorrect. Heat is a form of energy, not a state of matter."
        }
    ],
    "correctAnswer": "Gas"
},
{
    "id": 117,
    "question": "A lever is a type of ___.",
    "generalFeedback": "In science, tools that make work easier by changing the direction or magnitude of a force are called simple machines.",
    "answers": [
        {
            "text": "Simple machine",
            "feedback": "Correct. A lever is one of the six classical simple machines used to gain a mechanical advantage."
        },
        {
            "text": "Energy source",
            "feedback": "Incorrect. A lever uses energy to do work, but it doesn't produce energy."
        },
        {
            "text": "Living thing",
            "feedback": "Incorrect. A lever is a non-living tool."
        },
        {
            "text": "Chemical element",
            "feedback": "Incorrect. A lever is a physical object, not a fundamental substance like oxygen or carbon."
        }
    ],
    "correctAnswer": "Simple machine"
},
{
    "id": 118,
    "question": "What is the main reason for wearing goggles in a workshop or laboratory?",
    "generalFeedback": "Safety is the most important rule in any workshop or science laboratory. Protective equipment is designed to prevent specific types of injuries.",
    "answers": [
        {
            "text": "To protect the eyes",
            "feedback": "Correct. Goggles or safety glasses protect the eyes from flying debris, chemical splashes, and harmful fumes."
        },
        {
            "text": "To look fashionable",
            "feedback": "Incorrect. Safety equipment is for protection, not for fashion."
        },
        {
            "text": "To see things more clearly",
            "feedback": "Incorrect. While some goggles can be prescription, their primary purpose in a workshop is protection, not vision correction."
        },
        {
            "text": "To keep dust out of the hair",
            "feedback": "Incorrect. A hairnet or cap would be used for that purpose; goggles are specifically for eye safety."
        }
    ],
    "correctAnswer": "To protect the eyes"
},
{
    "id": 119,
    "question": "In technical drawing, which instrument is used to draw circles?",
    "generalFeedback": "Technical drawing requires precise instruments to create accurate shapes and lines. Each instrument has a specific function.",
    "answers": [
        {
            "text": "A pair of compasses",
            "feedback": "Correct. A pair of compasses is used to draw circles and arcs."
        },
        {
            "text": "A ruler",
            "feedback": "Incorrect. A ruler is used to measure and draw straight lines."
        },
        {
            "text": "A protractor",
            "feedback": "Incorrect. A protractor is used to measure and draw angles."
        },
        {
            "text": "A T-square",
            "feedback": "Incorrect. A T-square is used to draw horizontal lines and to align other drawing instruments."
        }
    ],
    "correctAnswer": "A pair of compasses"
},
{
    "id": 120,
    "question": "Which of these is a type of hardwood?",
    "generalFeedback": "Wood is generally classified into two main categories: hardwood (from deciduous trees) and softwood (from coniferous trees). They have different properties and uses.",
    "answers": [
        {
            "text": "Mahogany",
            "feedback": "Correct. Mahogany is a well-known hardwood, valued for its durability and reddish-brown color, often used in furniture."
        },
        {
            "text": "Pine",
            "feedback": "Incorrect. Pine is a common type of softwood."
        },
        {
            "text": "Cedar",
            "feedback": "Incorrect. Cedar is another type of softwood, known for its aroma."
        },
        {
            "text": "Spruce",
            "feedback": "Incorrect. Spruce is a lightweight softwood often used in construction and for making paper."
        }
    ],
    "correctAnswer": "Mahogany"
},
{
    "id": 121,
    "question": "Which tool is primarily used for cutting metal?",
    "generalFeedback": "Different tools are designed for working with specific materials. Using the right tool is important for both safety and effectiveness.",
    "answers": [
        {
            "text": "Hacksaw",
            "feedback": "Correct. A hacksaw is a fine-toothed saw, originally and mainly made for cutting metal."
        },
        {
            "text": "Chisel",
            "feedback": "Incorrect. A chisel is primarily used for carving or cutting hard materials like wood or stone."
        },
        {
            "text": "Tenon saw",
            "feedback": "Incorrect. A tenon saw has a stiffening rib on its top edge and is used for precise woodworking."
        },
        {
            "text": "Screwdriver",
            "feedback": "Incorrect. A screwdriver is used for turning screws."
        }
    ],
    "correctAnswer": "Hacksaw"
},
{
    "id": 122,
    "question": "An eyewitness account of an event is an example of what kind of historical source?",
    "generalFeedback": "Historians use different types of sources to learn about the past. These are generally categorized based on when and by whom they were created.",
    "answers": [
        {
            "text": "Primary source",
            "feedback": "Correct. A primary source is a firsthand account or direct evidence of an event, created by someone who was present at the time."
        },
        {
            "text": "Secondary source",
            "feedback": "Incorrect. A secondary source interprets or analyzes primary sources. Examples include textbooks and biographies written long after the event."
        },
        {
            "text": "Oral tradition",
            "feedback": "Incorrect. While an eyewitness account can be part of oral tradition, 'primary source' is the more precise classification for any firsthand account."
        },
        {
            "text": "Archaeology",
            "feedback": "Incorrect. Archaeology is the study of human history through the excavation and analysis of artifacts, which are themselves primary sources."
        }
    ],
    "correctAnswer": "Primary source"
},
{
    "id": 123,
    "question": "The famous terracotta sculptures are associated with which ancient Nigerian culture?",
    "generalFeedback": "Ancient Nigerian cultures left behind distinct artifacts that tell us about their society. The terracotta heads are one of the most famous examples.",
    "answers": [
        {
            "text": "Nok",
            "feedback": "Correct. The Nok culture, which existed in what is now central Nigeria around 1500 BC, is famous for its life-sized terracotta sculptures."
        },
        {
            "text": "Benin",
            "feedback": "Incorrect. The Benin Kingdom is famous for its bronze castings, especially the Benin Bronzes."
        },
        {
            "text": "Ife",
            "feedback": "Incorrect. Ife is renowned for its highly naturalistic bronze, stone, and terracotta sculptures, but the earliest widespread terracotta finds are from Nok."
        },
        {
            "text": "Oyo",
            "feedback": "Incorrect. The Oyo Empire was known more for its political and military structure than for a specific art form like terracotta sculptures."
        }
    ],
    "correctAnswer": "Nok"
},
{
    "id": 124,
    "question": "The head of the pre-colonial Oyo Empire was known as the ___.",
    "generalFeedback": "Different pre-colonial states and empires in Nigeria had unique political structures and titles for their rulers.",
    "answers": [
        {
            "text": "Alaafin",
            "feedback": "Correct. The Alaafin of Oyo was the emperor of the Oyo Empire."
        },
        {
            "text": "Oba",
            "feedback": "Incorrect. Oba is the title for the ruler of the Benin Kingdom and other Yoruba states, but Alaafin was specific to the head of the entire Oyo Empire."
        },
        {
            "text": "Emir",
            "feedback": "Incorrect. Emir is the title used for rulers in the Hausa states and other Islamic caliphates in Northern Nigeria."
        },
        {
            "text": "Obi",
            "feedback": "Incorrect. Obi is the title for the ruler in many Igbo communities."
        }
    ],
    "correctAnswer": "Alaafin"
},
{
    "id": 125,
    "question": "What year did the Northern and Southern Protectorates of Nigeria amalgamate?",
    "generalFeedback": "The amalgamation of the two British protectorates is a pivotal event in the creation of modern Nigeria.",
    "answers": [
        {
            "text": "1914",
            "feedback": "Correct. Lord Frederick Lugard oversaw the amalgamation of the Colony and Protectorate of Southern Nigeria and the Protectorate of Northern Nigeria in 1914."
        },
        {
            "text": "1960",
            "feedback": "Incorrect. Nigeria gained its independence in 1960."
        },
        {
            "text": "1900",
            "feedback": "Incorrect. This year marks the establishment of the protectorates, not their amalgamation."
        },
        {
            "text": "1885",
            "feedback": "Incorrect. This date is associated with the Berlin Conference, where European powers divided Africa."
        }
    ],
    "correctAnswer": "1914"
},
{
    "id": 126,
    "question": "The science and practice of cultivating the soil, producing crops, and raising livestock is called ___.",
    "generalFeedback": "This question asks for the definition of a key term that encompasses a wide range of activities related to food production.",
    "answers": [
        {
            "text": "Agriculture",
            "feedback": "Correct. This is the precise definition of agriculture."
        },
        {
            "text": "Horticulture",
            "feedback": "Incorrect. Horticulture is a branch of agriculture that deals specifically with garden crops, generally fruits, vegetables, and ornamental plants."
        },
        {
            "text": "Agronomy",
            "feedback": "Incorrect. Agronomy is a branch of agriculture that deals with soil management and the production of field crops."
        },
        {
            "text": "Forestry",
            "feedback": "Incorrect. Forestry is the science and craft of creating, managing, using, conserving, and repairing forests."
        }
    ],
    "correctAnswer": "Agriculture"
},
{
    "id": 127,
    "question": "Which of these is a simple farm tool used for digging?",
    "generalFeedback": "Simple farm tools are manually operated and essential for basic farming activities. It's important to identify them and know their primary use.",
    "answers": [
        {
            "text": "Spade",
            "feedback": "Correct. A spade is designed for digging, lifting, and moving loose materials like soil, coal, and gravel."
        },
        {
            "text": "Rake",
            "feedback": "Incorrect. A rake is used for gathering leaves, hay, or leveling soil, not for digging."
        },
        {
            "text": "Watering can",
            "feedback": "Incorrect. A watering can is used for watering plants."
        },
        {
            "text": "Sickle",
            "feedback": "Incorrect. A sickle is a curved blade used for harvesting or reaping grain crops."
        }
    ],
    "correctAnswer": "Spade"
},
{
    "id": 128,
    "question": "Which type of soil feels sticky when wet and is good for moulding?",
    "generalFeedback": "Soils are classified based on their texture, which is determined by the size of their particles. These properties affect their suitability for different purposes.",
    "answers": [
        {
            "text": "Clay soil",
            "feedback": "Correct. Clay soil has very fine particles, holds a lot of water, and becomes sticky and mouldable when wet."
        },
        {
            "text": "Sandy soil",
            "feedback": "Incorrect. Sandy soil has large particles, feels gritty, and does not hold water well."
        },
        {
            "text": "Loamy soil",
            "feedback": "Incorrect. Loamy soil is a mixture of sand, silt, and clay and is considered ideal for most plants. It's crumbly, not overly sticky."
        },
        {
            "text": "Gravel",
            "feedback": "Incorrect. Gravel consists of large rock fragments and is not considered a type of soil for growing crops."
        }
    ],
    "correctAnswer": "Clay soil"
},
{
    "id": 129,
    "question": "What is the basic unit of society?",
    "generalFeedback": "Social Studies explores how society is structured. The most fundamental group in any society is the starting point for this exploration.",
    "answers": [
        {
            "text": "The family",
            "feedback": "Correct. The family is universally considered the basic social unit from which larger communities and societies are built."
        },
        {
            "text": "The school",
            "feedback": "Incorrect. The school is an important institution for education, but it is not the most basic unit of society."
        },
        {
            "text": "The community",
            "feedback": "Incorrect. A community is a group of families living together, so the family is a more basic unit."
        },
        {
            "text": "The individual",
            "feedback": "Incorrect. While society is made up of individuals, the family is the basic functional unit or group."
        }
    ],
    "correctAnswer": "The family"
},
{
    "id": 130,
    "question": "The Nigerian Coat of Arms has a black shield which represents ___.",
    "generalFeedback": "National symbols like the Coat of Arms contain imagery that represents important aspects of a country's geography, resources, or values.",
    "answers": [
        {
            "text": "The fertile soil of Nigeria",
            "feedback": "Correct. The black shield on the Coat of Arms represents the rich, fertile land of Nigeria."
        },
        {
            "text": "The River Niger and Benue",
            "feedback": "Incorrect. The two white wavy bands (the 'Y' shape) on the shield represent the meeting of the River Niger and River Benue."
        },
        {
            "text": "The strength of the nation",
            "feedback": "Incorrect. The two horses on either side of the shield represent dignity and strength."
        },
        {
            "text": "The oil wealth of Nigeria",
            "feedback": "Incorrect. While important, oil wealth is not what the black shield symbolizes."
        }
    ],
    "correctAnswer": "The fertile soil of Nigeria"
},
{
    "id": 131,
    "question": "Which of these is NOT a level of government in Nigeria?",
    "generalFeedback": "Nigeria operates a federal system of government with power shared among different tiers or levels.",
    "answers": [
        {
            "text": "Regional Government",
            "feedback": "Correct. Nigeria had regional governments in the First Republic, but the current structure consists of Federal, State, and Local governments."
        },
        {
            "text": "Federal Government",
            "feedback": "Incorrect. The Federal Government, headed by the President, is the highest level of government in Nigeria."
        },
        {
            "text": "State Government",
            "feedback": "Incorrect. State Governments, each headed by a Governor, are the second tier of government."
        },
        {
            "text": "Local Government",
            "feedback": "Incorrect. Local Governments, headed by a Chairman, are the third and grassroots level of government."
        }
    ],
    "correctAnswer": "Regional Government"
},
{
    "id": 132,
    "question": "The accepted way of life of a group of people is known as their ___.",
    "generalFeedback": "This question asks for the term that describes the shared values, beliefs, customs, behaviors, and artifacts of a society.",
    "answers": [
        {
            "text": "Culture",
            "feedback": "Correct. Culture encompasses all aspects of a group's way of life."
        },
        {
            "text": "Religion",
            "feedback": "Incorrect. Religion is a component of culture, but it is not the entire way of life for all groups."
        },
        {
            "text": "Government",
            "feedback": "Incorrect. Government is the system that rules a society, which is part of its culture, but not the whole concept."
        },
        {
            "text": "Family",
            "feedback": "Incorrect. The family is the basic unit where culture is first learned, but culture itself is broader."
        }
    ],
    "correctAnswer": "Culture"
},
{
    "id": 133,
    "question": "Which of the following is a component of Business Studies?",
    "generalFeedback": "Business Studies in JSS 1 is an introductory subject that combines several related fields.",
    "answers": [
        {
            "text": "Commerce",
            "feedback": "Correct. Business Studies is typically composed of Commerce, Office Practice, and Bookkeeping."
        },
        {
            "text": "History",
            "feedback": "Incorrect. History is a separate subject in the humanities."
        },
        {
            "text": "Biology",
            "feedback": "Incorrect. Biology is a science subject."
        },
        {
            "text": "Fine Art",
            "feedback": "Incorrect. Fine Art is part of Cultural and Creative Arts."
        }
    ],
    "correctAnswer": "Commerce"
},
{
    "id": 134,
    "question": "Trade, which involves the buying and selling of goods, is a key part of ___.",
    "generalFeedback": "Business Studies covers the various activities that facilitate the exchange of goods and services.",
    "answers": [
        {
            "text": "Commerce",
            "feedback": "Correct. Commerce is the branch of business concerned with the exchange of goods and services, including all activities which facilitate that exchange (aids to trade)."
        },
        {
            "text": "Office Practice",
            "feedback": "Incorrect. Office Practice deals with the administrative work and procedures within an office."
        },
        {
            "text": "Bookkeeping",
            "feedback": "Incorrect. Bookkeeping is the recording of financial transactions."
        },
        {
            "text": "Keyboarding",
            "feedback": "Incorrect. Keyboarding is the skill of typing, which is a part of Office Practice."
        }
    ],
    "correctAnswer": "Commerce"
},
{
    "id": 135,
    "question": "A document sent by a seller to a buyer requesting payment for goods sold is called an ___.",
    "generalFeedback": "Bookkeeping involves understanding various source documents that provide evidence of financial transactions.",
    "answers": [
        {
            "text": "Invoice",
            "feedback": "Correct. An invoice is a commercial document that itemizes and records a transaction between a buyer and a seller."
        },
        {
            "text": "Receipt",
            "feedback": "Incorrect. A receipt is a document acknowledging that a person has received money or property in payment following a sale."
        },
        {
            "text": "Credit Note",
            "feedback": "Incorrect. A credit note is issued to a buyer if goods are returned or overpaid."
        },
        {
            "text": "Cheque",
            "feedback": "Incorrect. A cheque is an instruction to a bank to pay a specific amount of money from a person's account."
        }
    ],
    "correctAnswer": "Invoice"
},
{
    "id": 136,
    "question": "The keys A, S, D, F, J, K, L, ; on a computer keyboard are known as the ___.",
    "generalFeedback": "In touch typing, the keyboard is divided into sections, and a specific row is used as the base position for the fingers.",
    "answers": [
        {
            "text": "Home row keys",
            "feedback": "Correct. These are the base keys where you rest your fingers when you are not typing."
        },
        {
            "text": "Top row keys",
            "feedback": "Incorrect. The top row keys are Q, W, E, R, T, Y, U, I, O, P."
        },
        {
            "text": "Bottom row keys",
            "feedback": "Incorrect. The bottom row keys are Z, X, C, V, B, N, M."
        },
        {
            "text": "Function keys",
            "feedback": "Incorrect. The function keys are F1 through F12 at the very top of the keyboard."
        }
    ],
    "correctAnswer": "Home row keys"
},
{
    "id": 137,
    "question": "Which of these is a primary colour?",
    "generalFeedback": "In color theory, primary colors are the base colors from which all other colors are derived by mixing.",
    "answers": [
        {
            "text": "Red",
            "feedback": "Correct. The three primary colors are red, yellow, and blue."
        },
        {
            "text": "Green",
            "feedback": "Incorrect. Green is a secondary color, made by mixing blue and yellow."
        },
        {
            "text": "Orange",
            "feedback": "Incorrect. Orange is a secondary color, made by mixing red and yellow."
        },
        {
            "text": "Purple",
            "feedback": "Incorrect. Purple (or violet) is a secondary color, made by mixing red and blue."
        }
    ],
    "correctAnswer": "Red"
},
{
    "id": 138,
    "question": "The art of using dyed fabric and wax to create patterns, popular in Nigeria, is called ___.",
    "generalFeedback": "Cultural and Creative Arts includes the study of various traditional crafts practiced in Nigeria.",
    "answers": [
        {
            "text": "Batik",
            "feedback": "Correct. Batik is a wax-resist dyeing technique applied to the whole cloth."
        },
        {
            "text": "Weaving",
            "feedback": "Incorrect. Weaving involves interlacing threads to form a fabric, like with Aso Oke."
        },
        {
            "text": "Pottery",
            "feedback": "Incorrect. Pottery is the craft of making objects from clay."
        },
        {
            "text": "Sculpture",
            "feedback": "Incorrect. Sculpture is the art of making two- or three-dimensional representative or abstract forms."
        }
    ],
    "correctAnswer": "Batik"
},
{
    "id": 139,
    "question": "A story acted out on a stage by actors is called ___.",
    "generalFeedback": "The performing arts have different forms. This question asks to identify the term for a live theatrical performance.",
    "answers": [
        {
            "text": "Drama",
            "feedback": "Correct. Drama is the specific mode of fiction represented in performance: a play, opera, mime, ballet, etc., performed in a theatre, or on radio or television."
        },
        {
            "text": "Poetry",
            "feedback": "Incorrect. Poetry is literature that uses aesthetic and rhythmic qualities of language."
        },
        {
            "text": "A novel",
            "feedback": "Incorrect. A novel is a long work of prose fiction that is typically read, not acted out live."
        },
        {
            "text": "A drawing",
            "feedback": "Incorrect. A drawing is a form of visual art."
        }
    ],
    "correctAnswer": "Drama"
},
{
    "id": 140,
    "question": "According to the book of Genesis, what did God create on the first day?",
    "generalFeedback": "The creation story in Genesis chapter 1 describes God's work over a period of six days. Each day has a specific creation associated with it.",
    "answers": [
        {
            "text": "Light",
            "feedback": "Correct. Genesis 1:3-5 states, 'And God said, Let there be light: and there was light.' He then separated the light from the darkness."
        },
        {
            "text": "The sky",
            "feedback": "Incorrect. God created the sky (firmament) on the second day."
        },
        {
            "text": "Land and plants",
            "feedback": "Incorrect. God created the dry land and vegetation on the third day."
        },
        {
            "text": "The sun, moon, and stars",
            "feedback": "Incorrect. God created the sun, moon, and stars on the fourth day."
        }
    ],
    "correctAnswer": "Light"
},
{
    "id": 141,
    "question": "Who is known as the 'Father of Faith' in Christianity because of his great trust in God?",
    "generalFeedback": "The Old Testament features key figures whose lives demonstrate profound faith and obedience to God, establishing covenants with Him.",
    "answers": [
        {
            "text": "Abraham",
            "feedback": "Correct. Abraham is called the 'Father of Faith' because he obeyed God's call to leave his home and was willing to sacrifice his son, Isaac, trusting in God's promise."
        },
        {
            "text": "Moses",
            "feedback": "Incorrect. Moses is known as the great lawgiver who led the Israelites out of Egypt, but Abraham holds the title 'Father of Faith'."
        },
        {
            "text": "David",
            "feedback": "Incorrect. David was a great king of Israel, known for defeating Goliath and writing many Psalms."
        },
        {
            "text": "Adam",
            "feedback": "Incorrect. Adam was the first man created by God."
        }
    ],
    "correctAnswer": "Abraham"
},
{
    "id": 142,
    "question": "God gave the Ten Commandments to the Israelites through ___.",
    "generalFeedback": "The Ten Commandments are a set of biblical principles relating to ethics and worship, which play a central role in Judaism and Christianity.",
    "answers": [
        {
            "text": "Moses",
            "feedback": "Correct. According to the book of Exodus, Moses received the Ten Commandments from God on Mount Sinai."
        },
        {
            "text": "Aaron",
            "feedback": "Incorrect. Aaron was Moses' brother and the first High Priest, but he did not receive the commandments directly."
        },
        {
            "text": "Joshua",
            "feedback": "Incorrect. Joshua was Moses' successor who led the Israelites into the Promised Land."
        },
        {
            "text": "Abraham",
            "feedback": "Incorrect. Abraham lived many generations before Moses and the giving of the Law."
        }
    ],
    "correctAnswer": "Moses"
},
{
    "id": 143,
    "question": "In which town was Jesus Christ born?",
    "generalFeedback": "The New Testament Gospels of Matthew and Luke provide accounts of the birth of Jesus, specifying the location as prophesied in the Old Testament.",
    "answers": [
        {
            "text": "Bethlehem",
            "feedback": "Correct. As prophesied in Micah 5:2, Jesus was born in Bethlehem of Judea."
        },
        {
            "text": "Nazareth",
            "feedback": "Incorrect. Jesus grew up in Nazareth, which is why he was called Jesus of Nazareth, but he was not born there."
        },
        {
            "text": "Jerusalem",
            "feedback": "Incorrect. Jerusalem was the religious and political capital, where Jesus was crucified, but it was not his birthplace."
        },
        {
            "text": "Galilee",
            "feedback": "Incorrect. Galilee was the region where Jesus conducted much of his ministry, but not his birthplace."
        }
    ],
    "correctAnswer": "Bethlehem"
},
{
    "id": 144,
    "question": "Which of the following is an input device for a computer?",
    "generalFeedback": "Computer hardware is categorized by its function. Input devices are used to send data and control signals to a computer.",
    "answers": [
        {
            "text": "Mouse",
            "feedback": "Correct. A mouse is a pointing device that detects two-dimensional motion relative to a surface, allowing a user to control a graphical pointer and send commands to the computer."
        },
        {
            "text": "Monitor",
            "feedback": "Incorrect. A monitor is an output device that displays information in visual form."
        },
        {
            "text": "Printer",
            "feedback": "Incorrect. A printer is an output device that produces a hard copy (paper document) of data stored on a computer."
        },
        {
            "text": "Speaker",
            "feedback": "Incorrect. A speaker is an output device that produces sound."
        }
    ],
    "correctAnswer": "Mouse"
},
{
    "id": 145,
    "question": "The physical parts of a computer that you can touch are called ___.",
    "generalFeedback": "A computer system is made up of two main components: the physical equipment and the programs that run on it.",
    "answers": [
        {
            "text": "Hardware",
            "feedback": "Correct. Hardware refers to all the physical components of a computer system, such as the CPU, monitor, keyboard, and mouse."
        },
        {
            "text": "Software",
            "feedback": "Incorrect. Software is the set of instructions, data, or programs used to operate computers and execute specific tasks. You cannot physically touch software."
        },
        {
            "text": "Firmware",
            "feedback": "Incorrect. Firmware is a specific class of computer software that provides low-level control for a device's specific hardware."
        },
        {
            "text": "Peopleware",
            "feedback": "Incorrect. Peopleware refers to the human users who operate the computer."
        }
    ],
    "correctAnswer": "Hardware"
},
{
    "id": 146,
    "question": "What does CPU stand for?",
    "generalFeedback": "The CPU is a crucial component of any computer, often referred to by a common analogy.",
    "answers": [
        {
            "text": "Central Processing Unit",
            "feedback": "Correct. The CPU is the primary component of a computer that executes instructions. It is often called the 'brain' of the computer."
        },
        {
            "text": "Computer Processing Unit",
            "feedback": "Incorrect. This is a common mistake, but the correct term is 'Central'."
        },
        {
            "text": "Central Power Unit",
            "feedback": "Incorrect. The power supply unit (PSU) handles power, not the CPU."
        },
        {
            "text": "Computer Personal Unit",
            "feedback": "Incorrect. This acronym does not represent a standard computer component."
        }
    ],
    "correctAnswer": "Central Processing Unit"
},
{
    "id": 147,
    "question": "Which of the following is a rule for staying safe online?",
    "generalFeedback": "The internet is a useful tool, but it also has risks. Following safety rules is important to protect personal information and well-being.",
    "answers": [
        {
            "text": "Do not share personal information with strangers",
            "feedback": "Correct. Sharing details like your full name, address, phone number, or school name can be dangerous."
        },
        {
            "text": "Accept friend requests from everyone",
            "feedback": "Incorrect. You should only accept friend requests from people you know and trust in real life."
        },
        {
            "text": "Share your password with your best friend",
            "feedback": "Incorrect. Passwords should be kept private and never shared, even with close friends."
        },
        {
            "text": "Download files from any website",
            "feedback": "Incorrect. You should only download files from trusted and secure websites to avoid viruses and malware."
        }
    ],
    "correctAnswer": "Do not share personal information with strangers"
},
{
    "id": 148,
    "question": "Kedu maka \u1ee5t\u1ee5t\u1ee5 a?",
    "generalFeedback": "This is a common Igbo greeting used in the morning.",
    "answers": [
        {
            "text": "Good morning",
            "feedback": "Correct. This phrase translates to 'How is this morning?' or simply 'Good morning'."
        },
        {
            "text": "Good afternoon",
            "feedback": "Incorrect. Good afternoon is 'Ehihie \u1ecdma' or 'Kedu maka ehihie a?'."
        },
        {
            "text": "Good evening",
            "feedback": "Incorrect. Good evening is 'Mgbede \u1ecdma' or 'Kedu maka mgbede a?'."
        },
        {
            "text": "Goodbye",
            "feedback": "Incorrect. Goodbye is 'Ka \u1ecd d\u1ecb' or 'Gaan\u1ee5 nke \u1ecdma'."
        }
    ],
    "correctAnswer": "Good morning"
},
{
    "id": 149,
    "question": "What is the Igbo word for the number 'five'?",
    "generalFeedback": "Learning to count is a fundamental part of any language.",
    "answers": [
        {
            "text": "Ise",
            "feedback": "Correct. Otu (1), ab\u1ee5\u1ecd (2), at\u1ecd (3), an\u1ecd (4), ise (5)."
        },
        {
            "text": "An\u1ecd",
            "feedback": "Incorrect. An\u1ecd means four."
        },
        {
            "text": "Isii",
            "feedback": "Incorrect. Isii means six."
        },
        {
            "text": "At\u1ecd",
            "feedback": "Incorrect. At\u1ecd means three."
        }
    ],
    "correctAnswer": "Ise"
},
{
    "id": 150,
    "question": "The Igbo alphabet is known as ___.",
    "generalFeedback": "Every language has a name for its writing system or alphabet.",
    "answers": [
        {
            "text": "Mkp\u1ee5r\u1ee5 Edemede Igbo",
            "feedback": "Correct. This is the correct term for the Igbo alphabet."
        },
        {
            "text": "Abidii Igbo",
            "feedback": "Incorrect. While 'Abidii' is a common transliteration of 'alphabet', the formal term is 'Mkp\u1ee5r\u1ee5 Edemede'."
        },
        {
            "text": "Akw\u1ee5kw\u1ecd Igbo",
            "feedback": "Incorrect. This means 'Igbo book' or 'Igbo paper'."
        },
        {
            "text": "Okwu Igbo",
            "feedback": "Incorrect. This means 'Igbo word' or 'Igbo speech'."
        }
    ],
    "correctAnswer": "Mkp\u1ee5r\u1ee5 Edemede Igbo"
},
{
    "id": 151,
    "question": "Which of these is NOT a part of personal hygiene?",
    "generalFeedback": "Personal hygiene involves practices performed by an individual to care for their bodily health and well-being through cleanliness.",
    "answers": [
        {
            "text": "Watching television",
            "feedback": "Correct. Watching television is a leisure activity and has no direct connection to personal hygiene."
        },
        {
            "text": "Brushing your teeth",
            "feedback": "Incorrect. This is a key part of oral hygiene, which is a component of personal hygiene."
        },
        {
            "text": "Bathing regularly",
            "feedback": "Incorrect. Bathing cleans the skin and is a fundamental aspect of personal hygiene."
        },
        {
            "text": "Washing your hands",
            "feedback": "Incorrect. Hand washing is one of the most effective ways to prevent the spread of germs and is crucial for good hygiene."
        }
    ],
    "correctAnswer": "Watching television"
},
{
    "id": 152,
    "question": "Which class of food is the main source of energy for the body?",
    "generalFeedback": "A balanced diet consists of different classes of food, and each class has a primary function in the body.",
    "answers": [
        {
            "text": "Carbohydrates",
            "feedback": "Correct. Carbohydrates, found in foods like rice, bread, and yam, are the body's primary source of energy."
        },
        {
            "text": "Proteins",
            "feedback": "Incorrect. Proteins, found in beans, meat, and eggs, are primarily for building and repairing body tissues."
        },
        {
            "text": "Vitamins",
            "feedback": "Incorrect. Vitamins are needed in small amounts for various body processes and to protect against diseases."
        },
        {
            "text": "Fats and Oils",
            "feedback": "Incorrect. While fats and oils are a concentrated source of energy, carbohydrates are the main and most readily available source."
        }
    ],
    "correctAnswer": "Carbohydrates"
},
{
    "id": 153,
    "question": "A sharp knife should be stored ___ in the kitchen.",
    "generalFeedback": "Kitchen safety is a very important part of Home Economics to prevent accidents like cuts and burns.",
    "answers": [
        {
            "text": "In a knife block or a separate drawer",
            "feedback": "Correct. Storing knives safely prevents accidental cuts when reaching into drawers."
        },
        {
            "text": "In the sink with other utensils",
            "feedback": "Incorrect. This is very dangerous as someone could get a serious cut when washing dishes."
        },
        {
            "text": "On the edge of the counter",
            "feedback": "Incorrect. This is unsafe as the knife could easily fall and injure someone."
        },
        {
            "text": "Mixed in a drawer with other spoons and forks",
            "feedback": "Incorrect. This increases the risk of getting cut when looking for another utensil."
        }
    ],
    "correctAnswer": "In a knife block or a separate drawer"
},
{
    "id": 154,
    "question": "A simple stitch used to temporarily hold pieces of fabric together is called a ___.",
    "generalFeedback": "In sewing, different stitches serve different purposes, from permanent seams to temporary guides.",
    "answers": [
        {
            "text": "Tacking stitch",
            "feedback": "Correct. Tacking stitches (or basting stitches) are temporary stitches that are removed after the final sewing is done."
        },
        {
            "text": "Running stitch",
            "feedback": "Incorrect. A running stitch is a basic permanent stitch used for sewing seams and gathering."
        },
        {
            "text": "Backstitch",
            "feedback": "Incorrect. A backstitch is a strong, permanent hand stitch used to secure seams."
        },
        {
            "text": "Buttonhole stitch",
            "feedback": "Incorrect. This is a strong stitch used to neaten and reinforce the edges of buttonholes."
        }
    ],
    "correctAnswer": "Tacking stitch"
},
{
    "id": 155,
    "question": "How do you say 'Hello' or 'Good day' in French?",
    "generalFeedback": "Learning basic greetings is the first step in communicating in a new language.",
    "answers": [
        {
            "text": "Bonjour",
            "feedback": "Correct. 'Bonjour' is the standard formal and informal greeting for 'hello' or 'good day'."
        },
        {
            "text": "Au revoir",
            "feedback": "Incorrect. 'Au revoir' means 'Goodbye'."
        },
        {
            "text": "Merci",
            "feedback": "Incorrect. 'Merci' means 'Thank you'."
        },
        {
            "text": "Oui",
            "feedback": "Incorrect. 'Oui' means 'Yes'."
        }
    ],
    "correctAnswer": "Bonjour"
},
{
    "id": 156,
    "question": "What is the French word for the number 'ten'?",
    "generalFeedback": "Counting is a fundamental skill when learning a new language like French.",
    "answers": [
        {
            "text": "Dix",
            "feedback": "Correct. The number ten in French is 'dix'."
        },
        {
            "text": "Deux",
            "feedback": "Incorrect. 'Deux' is the French word for two."
        },
        {
            "text": "Cinq",
            "feedback": "Incorrect. 'Cinq' is the French word for five."
        },
        {
            "text": "Huit",
            "feedback": "Incorrect. 'Huit' is the French word for eight."
        }
    ],
    "correctAnswer": "Dix"
},
{
    "id": 157,
    "question": "The question 'Comment \u00e7a va?' in French means ___.",
    "generalFeedback": "Asking about someone's well-being is a common part of everyday conversation.",
    "answers": [
        {
            "text": "How are you?",
            "feedback": "Correct. 'Comment \u00e7a va?' is a common way to ask 'How are you?' or 'How's it going?'"
        },
        {
            "text": "What is your name?",
            "feedback": "Incorrect. 'What is your name?' is 'Comment t'appelles-tu?'"
        },
        {
            "text": "Where are you from?",
            "feedback": "Incorrect. 'Where are you from?' is 'D'o\u00f9 viens-tu?'"
        },
        {
            "text": "Do you speak English?",
            "feedback": "Incorrect. 'Do you speak English?' is 'Parlez-vous anglais?'"
        }
    ],
    "correctAnswer": "How are you?"
},
{
    "id": 158,
    "question": "The five horizontal lines on which musical notes are written is called the ___.",
    "generalFeedback": "The foundation of written music is a system of lines and spaces that represent different musical pitches.",
    "answers": [
        {
            "text": "Staff or Stave",
            "feedback": "Correct. The staff (or stave) is the set of five parallel lines and four spaces used in music notation."
        },
        {
            "text": "Clef",
            "feedback": "Incorrect. A clef is a symbol placed at the beginning of the staff to indicate the pitch of the notes written on it."
        },
        {
            "text": "Bar line",
            "feedback": "Incorrect. A bar line is a vertical line that divides the staff into measures."
        },
        {
            "text": "Scale",
            "feedback": "Incorrect. A scale is a sequence of notes arranged in ascending or descending order of pitch."
        }
    ],
    "correctAnswer": "Staff or Stave"
},
{
    "id": 159,
    "question": "Which clef is also known as the G-clef?",
    "generalFeedback": "Clefs are named based on the note they anchor to a specific line on the staff. The shape of this clef curls around a particular line.",
    "answers": [
        {
            "text": "Treble clef",
            "feedback": "Correct. The Treble clef's curl wraps around the second line from the bottom of the staff, indicating that this line is the note G."
        },
        {
            "text": "Bass clef",
            "feedback": "Incorrect. The Bass clef is known as the F-clef because its two dots surround the F line."
        },
        {
            "text": "Alto clef",
            "feedback": "Incorrect. The Alto clef is a type of C-clef, which indicates the position of middle C."
        },
        {
            "text": "Tenor clef",
            "feedback": "Incorrect. The Tenor clef is also a type of C-clef, used for instruments like the cello and trombone."
        }
    ],
    "correctAnswer": "Treble clef"
},
{
    "id": 160,
    "question": "In music, the speed at which a piece is played is called the ___.",
    "generalFeedback": "Musical expression involves more than just the right notes; it also involves how fast or slow the music is performed.",
    "answers": [
        {
            "text": "Tempo",
            "feedback": "Correct. Tempo is the Italian word for 'time' and it refers to the speed of the music."
        },
        {
            "text": "Rhythm",
            "feedback": "Incorrect. Rhythm refers to the pattern of sounds and silences in music."
        },
        {
            "text": "Dynamics",
            "feedback": "Incorrect. Dynamics refers to the volume of the music (how loud or soft it is)."
        },
        {
            "text": "Pitch",
            "feedback": "Incorrect. Pitch refers to how high or low a note sounds."
        }
    ],
    "correctAnswer": "Tempo"
},
{
    "id": 161,
    "question": "Which of these notes has the longest duration?",
    "generalFeedback": "Musical notes have different shapes to indicate how long they should be held. A whole note serves as the baseline for duration.",
    "answers": [
        {
            "text": "Semibreve (Whole Note)",
            "feedback": "Correct. The semibreve, or whole note, typically lasts for four beats in common time and is the longest standard note value."
        },
        {
            "text": "Minim (Half Note)",
            "feedback": "Incorrect. A minim, or half note, lasts for half the duration of a semibreve (typically two beats)."
        },
        {
            "text": "Crotchet (Quarter Note)",
            "feedback": "Incorrect. A crotchet, or quarter note, lasts for a quarter of the duration of a semibreve (typically one beat)."
        },
        {
            "text": "Quaver (Eighth Note)",
            "feedback": "Incorrect. A quaver, or eighth note, is the shortest duration among these options, lasting for half a beat."
        }
    ],
    "correctAnswer": "Semibreve (Whole Note)"
},
{
    "id": 162,
    "question": "What is the value of the Roman numeral XIX?",
    "generalFeedback": "Roman numerals use letters to represent numbers. When a smaller value appears before a larger value, it is subtracted. X = 10, I = 1, V = 5.",
    "answers": [
        {
            "text": "19",
            "feedback": "Correct. X = 10, and IX = 9 (1 subtracted from 10). So, 10 + 9 = 19."
        },
        {
            "text": "21",
            "feedback": "Incorrect. 21 would be written as XXI (10 + 10 + 1)."
        },
        {
            "text": "11",
            "feedback": "Incorrect. 11 is written as XI (10 + 1)."
        },
        {
            "text": "9",
            "feedback": "Incorrect. 9 is written as IX."
        }
    ],
    "correctAnswer": "19"
},
{
    "id": 163,
    "question": "If x - 7 = 15, what is the value of x?",
    "generalFeedback": "This is a simple algebraic equation. To find the value of the unknown (x), you need to isolate it on one side of the equation. You can do this by performing the opposite operation.",
    "answers": [
        {
            "text": "22",
            "feedback": "Correct. To solve for x, you add 7 to both sides of the equation: x - 7 + 7 = 15 + 7, which gives x = 22."
        },
        {
            "text": "8",
            "feedback": "Incorrect. This is the result of subtracting 7 from 15, instead of adding it."
        },
        {
            "text": "15",
            "feedback": "Incorrect. The value of x must be a number that, when 7 is subtracted from it, equals 15."
        },
        {
            "text": "105",
            "feedback": "Incorrect. This looks like the result of multiplying 15 by 7, which is not the correct operation for this equation."
        }
    ],
    "correctAnswer": "22"
},
{
    "id": 164,
    "question": "A word that describes a noun is called an ___.",
    "generalFeedback": "Parts of speech are categories of words based on their function in a sentence. This question asks for the term for a 'describing word'.",
    "answers": [
        {
            "text": "Adjective",
            "feedback": "Correct. An adjective modifies or describes a noun or pronoun (e.g., a 'beautiful' flower)."
        },
        {
            "text": "Adverb",
            "feedback": "Incorrect. An adverb describes a verb, adjective, or another adverb (e.g., he ran 'quickly')."
        },
        {
            "text": "Verb",
            "feedback": "Incorrect. A verb is an action word or a state of being (e.g., 'run', 'is')."
        },
        {
            "text": "Conjunction",
            "feedback": "Incorrect. A conjunction is a connecting word (e.g., 'and', 'but', 'or')."
        }
    ],
    "correctAnswer": "Adjective"
},
{
    "id": 165,
    "question": "Which of these is the opposite of 'brave'?",
    "generalFeedback": "Antonyms are words that have opposite meanings. Identifying antonyms is a key vocabulary skill.",
    "answers": [
        {
            "text": "Cowardly",
            "feedback": "Correct. Cowardly means lacking courage, which is the direct opposite of brave."
        },
        {
            "text": "Strong",
            "feedback": "Incorrect. Strong can be a quality of a brave person, but it is not its opposite. The opposite of strong is weak."
        },
        {
            "text": "Fearful",
            "feedback": "Incorrect. While a brave person might act despite fear, 'fearful' is close but 'cowardly' is the more precise antonym for the character trait."
        },
        {
            "text": "Bold",
            "feedback": "Incorrect. Bold is a synonym for brave, meaning it has a similar meaning."
        }
    ],
    "correctAnswer": "Cowardly"
},
{
    "id": 166,
    "question": "A balanced diet is one that ___.",
    "generalFeedback": "Nutrition is a key topic in both Basic Science and Home Economics. A balanced diet is essential for good health.",
    "answers": [
        {
            "text": "Contains all classes of food in the right proportions",
            "feedback": "Correct. This is the definition of a balanced diet, providing all necessary nutrients for the body to function properly."
        },
        {
            "text": "Contains only fruits and vegetables",
            "feedback": "Incorrect. While fruits and vegetables are important, a diet consisting only of them would lack sufficient protein and other nutrients."
        },
        {
            "text": "Is very expensive",
            "feedback": "Incorrect. A balanced diet can be achieved with affordable, local foodstuffs; price does not determine its nutritional balance."
        },
        {
            "text": "Has a large amount of sugary foods",
            "feedback": "Incorrect. A large amount of sugar is unhealthy and would make a diet unbalanced."
        }
    ],
    "correctAnswer": "Contains all classes of food in the right proportions"
},
{
    "id": 167,
    "question": "Rusting of iron is an example of a ___.",
    "generalFeedback": "Science distinguishes between changes that alter the form of a substance and changes that create a new substance with different properties.",
    "answers": [
        {
            "text": "Chemical change",
            "feedback": "Correct. Rusting is a chemical reaction between iron, oxygen, and water, forming a new substance (iron oxide). The change is irreversible."
        },
        {
            "text": "Physical change",
            "feedback": "Incorrect. A physical change alters the form but not the chemical composition, like melting ice into water. The change is usually reversible."
        },
        {
            "text": "Biological change",
            "feedback": "Incorrect. A biological change relates to processes in living organisms, like growth."
        },
        {
            "text": "State change",
            "feedback": "Incorrect. A state change is a type of physical change, like evaporation or freezing."
        }
    ],
    "correctAnswer": "Chemical change"
},
{
    "id": 168,
    "question": "The definition of technology is the application of ___ knowledge to solve practical problems.",
    "generalFeedback": "Basic Technology starts with understanding the relationship between science and the tools and systems we create.",
    "answers": [
        {
            "text": "Scientific",
            "feedback": "Correct. Technology is essentially the practical application of scientific knowledge and discoveries."
        },
        {
            "text": "Historical",
            "feedback": "Incorrect. While we can learn from the history of technology, technology itself is based on science, not history."
        },
        {
            "text": "Artistic",
            "feedback": "Incorrect. Art and technology can intersect, but the core definition of technology is based on science."
        },
        {
            "text": "Ancient",
            "feedback": "Incorrect. Technology can be ancient or modern, but its foundation is always scientific principles, whether understood at the time or not."
        }
    ],
    "correctAnswer": "Scientific"
},
{
    "id": 169,
    "question": "Which of these is a non-renewable source of energy?",
    "generalFeedback": "Energy sources are classified as renewable (can be replenished) or non-renewable (exist in finite quantities and will run out).",
    "answers": [
        {
            "text": "Crude Oil (Petroleum)",
            "feedback": "Correct. Crude oil is a fossil fuel that was formed over millions of years and cannot be replaced once it is used up."
        },
        {
            "text": "Sunlight",
            "feedback": "Incorrect. Solar energy from the sun is a renewable resource because the sun is expected to last for billions of years."
        },
        {
            "text": "Wind",
            "feedback": "Incorrect. Wind is a renewable resource generated by the heating of the atmosphere by the sun."
        },
        {
            "text": "Water (Hydropower)",
            "feedback": "Incorrect. Hydropower from flowing water is a renewable resource as it is part of the water cycle."
        }
    ],
    "correctAnswer": "Crude Oil (Petroleum)"
},
{
    "id": 170,
    "question": "The main goods traded across the Sahara desert in pre-colonial times were gold and ___.",
    "generalFeedback": "The Trans-Saharan trade was a vital network that connected West Africa with North Africa and Europe, based on the exchange of key commodities.",
    "answers": [
        {
            "text": "Salt",
            "feedback": "Correct. West Africa was rich in gold, which was traded for salt from the Sahara desert. Salt was essential for preserving food and for health."
        },
        {
            "text": "Crude oil",
            "feedback": "Incorrect. Crude oil was not a commodity in the Trans-Saharan trade; its value was only realized in the industrial era."
        },
        {
            "text": "Cocoa",
            "feedback": "Incorrect. Cocoa was introduced to West Africa much later and was a key export during the colonial era."
        },
        {
            "text": "Weapons",
            "feedback": "Incorrect. While weapons were traded, the primary and most famous exchange was between gold and salt."
        }
    ],
    "correctAnswer": "Salt"
},
{
    "id": 171,
    "question": "Which branch of agriculture deals with the rearing of animals?",
    "generalFeedback": "Agriculture is a broad field with specialized branches focusing on different areas like crops, animals, and soil.",
    "answers": [
        {
            "text": "Animal Husbandry",
            "feedback": "Correct. Animal husbandry is the branch of agriculture concerned with animals that are raised for meat, fibre, milk, eggs, or other products."
        },
        {
            "text": "Crop Production",
            "feedback": "Incorrect. Crop production (or agronomy) focuses on growing plants."
        },
        {
            "text": "Agricultural Economics",
            "feedback": "Incorrect. This branch deals with the business and financial aspects of farming."
        },
        {
            "text": "Soil Science",
            "feedback": "Incorrect. This branch focuses on the study of soil as a natural resource."
        }
    ],
    "correctAnswer": "Animal Husbandry"
},
{
    "id": 172,
    "question": "The love and devotion for one's country is called ___.",
    "generalFeedback": "Social Studies teaches about civic responsibilities and the attitudes citizens should have towards their nation.",
    "answers": [
        {
            "text": "Patriotism",
            "feedback": "Correct. Patriotism is the feeling of love, devotion, and sense of attachment to a homeland and alliance with other citizens who share the same sentiment."
        },
        {
            "text": "Culture",
            "feedback": "Incorrect. Culture is the way of life of a people, which can inspire patriotism, but is not the same thing."
        },
        {
            "text": "Government",
            "feedback": "Incorrect. Government is the system that rules a country."
        },
        {
            "text": "Family",
            "feedback": "Incorrect. This refers to love for one's family, not one's country."
        }
    ],
    "correctAnswer": "Patriotism"
},
{
    "id": 173,
    "question": "Which of these is considered an 'Aid to Trade'?",
    "generalFeedback": "Aids to trade are services that facilitate the smooth exchange of goods from producers to consumers. They help overcome various hindrances in commerce.",
    "answers": [
        {
            "text": "Banking",
            "feedback": "Correct. Banking helps overcome the hindrance of finance by providing loans, payment systems, and a safe place for money."
        },
        {
            "text": "Farming",
            "feedback": "Incorrect. Farming is a production activity, not an aid to trade."
        },
        {
            "text": "Manufacturing",
            "feedback": "Incorrect. Manufacturing is the process of making goods."
        },
        {
            "text": "Selling",
            "feedback": "Incorrect. Selling is the act of trading itself, while aids to trade support this act."
        }
    ],
    "correctAnswer": "Banking"
},
{
    "id": 174,
    "question": "The act of performing a play or a piece of music in front of an audience is called a ___.",
    "generalFeedback": "Cultural and Creative Arts involves both creating art and presenting it.",
    "answers": [
        {
            "text": "Performance",
            "feedback": "Correct. This is the general term for presenting an artistic work to an audience."
        },
        {
            "text": "Drawing",
            "feedback": "Incorrect. Drawing is a visual art form."
        },
        {
            "text": "Rehearsal",
            "feedback": "Incorrect. A rehearsal is a practice session before the actual performance."
        },
        {
            "text": "Exhibition",
            "feedback": "Incorrect. An exhibition is a public display of works of art or other items of interest, typically for visual arts."
        }
    ],
    "correctAnswer": "Performance"
},
{
    "id": 175,
    "question": "In the story of the fall of man, the serpent tempted Eve to eat the fruit from which tree?",
    "generalFeedback": "The story in Genesis 3 is foundational to the Christian understanding of sin and disobedience. It revolves around a specific prohibition from God.",
    "answers": [
        {
            "text": "The tree of the knowledge of good and evil",
            "feedback": "Correct. God had forbidden Adam and Eve from eating from this specific tree."
        },
        {
            "text": "The tree of life",
            "feedback": "Incorrect. The tree of life was also in the garden, but it was not the one they were forbidden to eat from initially."
        },
        {
            "text": "A mango tree",
            "feedback": "Incorrect. The Bible does not specify the type of fruit, only the name of the tree."
        },
        {
            "text": "An orange tree",
            "feedback": "Incorrect. The Bible does not specify the type of fruit, only the name of the tree."
        }
    ],
    "correctAnswer": "The tree of the knowledge of good and evil"
},
{
    "id": 176,
    "question": "What does ICT stand for?",
    "generalFeedback": "Understanding the full name of ICT helps to clarify the scope of the subject, which covers more than just computers.",
    "answers": [
        {
            "text": "Information and Communication Technology",
            "feedback": "Correct. This term encompasses all technologies used to handle telecommunications, broadcast media, information management systems, and more."
        },
        {
            "text": "Internet and Computer Technology",
            "feedback": "Incorrect. While the internet and computers are major parts of ICT, this is not the full meaning of the acronym."
        },
        {
            "text": "Information and Computing Tools",
            "feedback": "Incorrect. This describes some aspects of ICT, but it is not the standard full name."
        },
        {
            "text": "Internal Communication Technology",
            "feedback": "Incorrect. ICT deals with both internal and external communication."
        }
    ],
    "correctAnswer": "Information and Communication Technology"
},
{
    "id": 177,
    "question": "The programs and instructions that run on a computer are called ___.",
    "generalFeedback": "A computer system requires both physical components (hardware) and the instructions that tell the hardware what to do.",
    "answers": [
        {
            "text": "Software",
            "feedback": "Correct. Software is the set of instructions that operates a computer."
        },
        {
            "text": "Hardware",
            "feedback": "Incorrect. Hardware refers to the physical parts of the computer."
        },
        {
            "text": "Malware",
            "feedback": "Incorrect. Malware is a type of malicious software designed to harm a computer."
        },
        {
            "text": "Freeware",
            "feedback": "Incorrect. Freeware is a specific type of software that is available for use at no cost."
        }
    ],
    "correctAnswer": "Software"
},
{
    "id": 178,
    "question": "G\u1ecbn\u1ecb b\u1ee5 aha nna g\u1ecb?",
    "generalFeedback": "This is an Igbo question asking for a specific family member's name.",
    "answers": [
        {
            "text": "What is your father's name?",
            "feedback": "Correct. 'Nna' means father. The question asks for your father's name."
        },
        {
            "text": "What is your mother's name?",
            "feedback": "Incorrect. 'Mother' is 'nne'. The question would be 'G\u1ecbn\u1ecb b\u1ee5 aha nne g\u1ecb?'"
        },
        {
            "text": "What is your name?",
            "feedback": "Incorrect. 'What is your name?' is 'G\u1ecbn\u1ecb b\u1ee5 aha g\u1ecb?'"
        },
        {
            "text": "What is your brother's name?",
            "feedback": "Incorrect. 'Brother' is 'nwanne nwoke'."
        }
    ],
    "correctAnswer": "What is your father's name?"
},
{
    "id": 179,
    "question": "Which food group is primarily responsible for building and repairing body tissues?",
    "generalFeedback": "Different food groups have primary roles. While carbohydrates provide energy, another group is essential for growth and repair.",
    "answers": [
        {
            "text": "Proteins",
            "feedback": "Correct. Proteins, found in foods like beans, meat, fish, and eggs, are the building blocks of the body."
        },
        {
            "text": "Carbohydrates",
            "feedback": "Incorrect. Carbohydrates are the main source of energy."
        },
        {
            "text": "Vitamins",
            "feedback": "Incorrect. Vitamins are essential for protecting the body against diseases and helping with various metabolic processes."
        },
        {
            "text": "Water",
            "feedback": "Incorrect. Water is essential for hydration and many bodily functions, but not primarily for building tissue."
        }
    ],
    "correctAnswer": "Proteins"
},
{
    "id": 180,
    "question": "What is the first day of the week in French?",
    "generalFeedback": "Learning the days of the week is a basic but important vocabulary set in any language.",
    "answers": [
        {
            "text": "Lundi",
            "feedback": "Correct. Lundi is Monday, which is considered the first day of the week in many cultures."
        },
        {
            "text": "Dimanche",
            "feedback": "Incorrect. Dimanche is Sunday."
        },
        {
            "text": "Mardi",
            "feedback": "Incorrect. Mardi is Tuesday."
        },
        {
            "text": "Jeudi",
            "feedback": "Incorrect. Jeudi is Thursday."
        }
    ],
    "correctAnswer": "Lundi"
},
{
    "id": 181,
    "question": "The volume of music (how loud or soft it is) is referred to as ___.",
    "generalFeedback": "In music, there are specific terms to describe different expressive qualities of a performance.",
    "answers": [
        {
            "text": "Dynamics",
            "feedback": "Correct. Dynamics refers to the variation in loudness between notes or phrases."
        },
        {
            "text": "Tempo",
            "feedback": "Incorrect. Tempo refers to the speed of the music."
        },
        {
            "text": "Pitch",
            "feedback": "Incorrect. Pitch refers to the highness or lowness of a sound."
        },
        {
            "text": "Rhythm",
            "feedback": "Incorrect. Rhythm is the pattern of sounds and silences in time."
        }
    ],
    "correctAnswer": "Dynamics"
},
{
    "id": 182,
    "question": "A shape with three sides and three angles is called a ___.",
    "generalFeedback": "Geometry is the branch of mathematics concerned with properties of space such as the distance, shape, size, and relative position of figures.",
    "answers": [
        {
            "text": "Triangle",
            "feedback": "Correct. A triangle is a polygon with three edges and three vertices."
        },
        {
            "text": "Square",
            "feedback": "Incorrect. A square has four equal sides and four right angles."
        },
        {
            "text": "Circle",
            "feedback": "Incorrect. A circle is a shape with no sides or angles."
        },
        {
            "text": "Rectangle",
            "feedback": "Incorrect. A rectangle has four sides and four right angles, with opposite sides being equal in length."
        }
    ],
    "correctAnswer": "Triangle"
},
{
    "id": 183,
    "question": "The sentence 'The cat sat on the mat' is in which tense?",
    "generalFeedback": "Tense indicates the time of an action or state of being. The form of the verb determines the tense.",
    "answers": [
        {
            "text": "Simple Past Tense",
            "feedback": "Correct. The verb 'sat' is the past tense of 'sit', indicating the action happened in the past."
        },
        {
            "text": "Simple Present Tense",
            "feedback": "Incorrect. The present tense would be 'The cat sits on the mat'."
        },
        {
            "text": "Simple Future Tense",
            "feedback": "Incorrect. The future tense would be 'The cat will sit on the mat'."
        },
        {
            "text": "Present Continuous Tense",
            "feedback": "Incorrect. The present continuous tense would be 'The cat is sitting on the mat'."
        }
    ],
    "correctAnswer": "Simple Past Tense"
},
{
    "id": 184,
    "question": "Which system in the human body is responsible for breaking down food?",
    "generalFeedback": "The human body is made up of several organ systems that work together. Each system has a specific major function.",
    "answers": [
        {
            "text": "Digestive System",
            "feedback": "Correct. The digestive system, which includes the stomach and intestines, breaks down food to absorb nutrients."
        },
        {
            "text": "Respiratory System",
            "feedback": "Incorrect. The respiratory system, including the lungs, is responsible for breathing."
        },
        {
            "text": "Skeletal System",
            "feedback": "Incorrect. The skeletal system provides structure, support, and protection for the body."
        },
        {
            "text": "Nervous System",
            "feedback": "Incorrect. The nervous system transmits nerve impulses between parts of the body."
        }
    ],
    "correctAnswer": "Digestive System"
},
{
    "id": 185,
    "question": "A line drawn with a ruler and pencil is called a ___ line.",
    "generalFeedback": "In technical drawing, there are different types of lines used to represent different features of an object.",
    "answers": [
        {
            "text": "Construction line",
            "feedback": "Correct. Construction lines are drawn very lightly and are used to lay out a drawing. They are not typically part of the finished drawing."
        },
        {
            "text": "Outline",
            "feedback": "Incorrect. An outline or visible line is a thick, dark line used to show the main shape of an object."
        },
        {
            "text": "Hidden line",
            "feedback": "Incorrect. A hidden line is a dashed line used to show edges that are not visible from the current view."
        },
        {
            "text": "Center line",
            "feedback": "Incorrect. A center line is a long-short-long dashed line used to show the center of circles and symmetrical parts."
        }
    ],
    "correctAnswer": "Construction line"
},
{
    "id": 186,
    "question": "Who was the first Prime Minister of Nigeria?",
    "generalFeedback": "Understanding the key figures in Nigeria's journey to independence and its early leadership is a crucial part of its history.",
    "answers": [
        {
            "text": "Sir Abubakar Tafawa Balewa",
            "feedback": "Correct. He was the first and only Prime Minister of Nigeria after independence in 1960."
        },
        {
            "text": "Dr. Nnamdi Azikiwe",
            "feedback": "Incorrect. Dr. Nnamdi Azikiwe was the first President of Nigeria (a ceremonial role at the time)."
        },
        {
            "text": "Chief Obafemi Awolowo",
            "feedback": "Incorrect. Chief Obafemi Awolowo was the Premier of the Western Region and later the leader of the opposition."
        },
        {
            "text": "Sir Ahmadu Bello",
            "feedback": "Incorrect. Sir Ahmadu Bello was the Premier of the Northern Region."
        }
    ],
    "correctAnswer": "Sir Abubakar Tafawa Balewa"
},
{
    "id": 187,
    "question": "Crops that are grown to be sold for profit are called ___ crops.",
    "generalFeedback": "Crops can be classified based on their primary use, whether for family consumption or for sale in the market.",
    "answers": [
        {
            "text": "Cash crops",
            "feedback": "Correct. Cash crops like cocoa, rubber, and palm oil are grown primarily for sale rather than for use by the grower."
        },
        {
            "text": "Food crops",
            "feedback": "Incorrect. Food crops, like yam and cassava, are grown primarily for consumption by the farmer's family."
        },
        {
            "text": "Cereal crops",
            "feedback": "Incorrect. This is a classification based on the type of plant (grasses grown for their edible grains), not their economic purpose."
        },
        {
            "text": "Legume crops",
            "feedback": "Incorrect. This is a classification based on the type of plant (those that produce a pod), not their economic purpose."
        }
    ],
    "correctAnswer": "Cash crops"
},
{
    "id": 188,
    "question": "The green, white, green Nigerian flag was designed by ___.",
    "generalFeedback": "The national flag is a powerful symbol of a nation's identity, and its designer holds a special place in the country's history.",
    "answers": [
        {
            "text": "Michael Taiwo Akinkunmi",
            "feedback": "Correct. He designed the Nigerian flag in 1959 as a student."
        },
        {
            "text": "Benedict Odiase",
            "feedback": "Incorrect. Benedict Odiase composed the Nigerian national anthem, 'Arise, O Compatriots'."
        },
        {
            "text": "Lord Lugard",
            "feedback": "Incorrect. Lord Lugard was the colonial administrator who amalgamated Nigeria."
        },
        {
            "text": "Funmilayo Ransome-Kuti",
            "feedback": "Incorrect. She was a prominent nationalist and activist."
        }
    ],
    "correctAnswer": "Michael Taiwo Akinkunmi"
},
{
    "id": 189,
    "question": "A place where clerical and administrative work is done is called an ___.",
    "generalFeedback": "Business Studies starts with defining the basic environments where business activities are coordinated.",
    "answers": [
        {
            "text": "Office",
            "feedback": "Correct. This is the definition of an office."
        },
        {
            "text": "Market",
            "feedback": "Incorrect. A market is a place where buying and selling takes place."
        },
        {
            "text": "Warehouse",
            "feedback": "Incorrect. A warehouse is a place where goods are stored."
        },
        {
            "text": "Factory",
            "feedback": "Incorrect. A factory is a place where goods are manufactured."
        }
    ],
    "correctAnswer": "Office"
},
{
    "id": 190,
    "question": "The elements of art include line, shape, and ___.",
    "generalFeedback": "The elements of art are the fundamental building blocks used by artists to create a work of art.",
    "answers": [
        {
            "text": "Colour",
            "feedback": "Correct. Colour is one of the key elements of art, along with line, shape, form, texture, space, and value."
        },
        {
            "text": "Music",
            "feedback": "Incorrect. Music is a separate art form, though it shares some conceptual elements like rhythm."
        },
        {
            "text": "History",
            "feedback": "Incorrect. History can be a subject of art, but it is not an element of art itself."
        },
        {
            "text": "Aesthetics",
            "feedback": "Incorrect. Aesthetics is the branch of philosophy that deals with the principles of beauty and artistic taste."
        }
    ],
    "correctAnswer": "Colour"
},
{
    "id": 191,
    "question": "The first man and woman created by God were named ___.",
    "generalFeedback": "The book of Genesis provides the account of the very first humans in the biblical narrative.",
    "answers": [
        {
            "text": "Adam and Eve",
            "feedback": "Correct. According to Genesis, Adam was the first man and Eve was the first woman."
        },
        {
            "text": "Abraham and Sarah",
            "feedback": "Incorrect. Abraham and Sarah were the ancestors of the Israelite nation."
        },
        {
            "text": "Isaac and Rebekah",
            "feedback": "Incorrect. Isaac was the son of Abraham and Sarah, and Rebekah was his wife."
        },
        {
            "text": "Joseph and Mary",
            "feedback": "Incorrect. Joseph and Mary were the earthly parents of Jesus Christ."
        }
    ],
    "correctAnswer": "Adam and Eve"
},
{
    "id": 192,
    "question": "What is the correct procedure for shutting down a Windows computer?",
    "generalFeedback": "Properly shutting down a computer is important to ensure data is saved and the system is not damaged.",
    "answers": [
        {
            "text": "Click the Start Menu, then Power, then Shut Down",
            "feedback": "Correct. This is the standard, safe procedure to shut down a Windows computer."
        },
        {
            "text": "Press and hold the power button until it turns off",
            "feedback": "Incorrect. This is a forced shutdown and should only be used if the computer is frozen, as it can lead to data loss."
        },
        {
            "text": "Unplug the computer from the wall socket",
            "feedback": "Incorrect. This can damage the computer's hardware and cause file corruption."
        },
        {
            "text": "Close all the open windows",
            "feedback": "Incorrect. Closing windows will not shut down the operating system."
        }
    ],
    "correctAnswer": "Click the Start Menu, then Power, then Shut Down"
},
{
    "id": 193,
    "question": "How many vowels are in the standard Igbo alphabet (Mkp\u1ee5r\u1ee5 Edemede Igbo)?",
    "generalFeedback": "The Igbo alphabet has a specific number of vowels, which are crucial for pronunciation and vowel harmony.",
    "answers": [
        {
            "text": "8",
            "feedback": "Correct. The eight Igbo vowels are a, e, i, \u1ecb, o, \u1ecd, u, \u1ee5."
        },
        {
            "text": "5",
            "feedback": "Incorrect. English has 5 vowels (a, e, i, o, u). Igbo has more."
        },
        {
            "text": "10",
            "feedback": "Incorrect. This is too many. There are only eight vowels."
        },
        {
            "text": "36",
            "feedback": "Incorrect. This is the total number of letters in the standard Igbo alphabet."
        }
    ],
    "correctAnswer": "8"
},
{
    "id": 194,
    "question": "The process of washing, ironing, and storing clothes properly is called ___.",
    "generalFeedback": "Home Economics teaches essential life skills, including how to care for personal belongings like clothing.",
    "answers": [
        {
            "text": "Care of clothes",
            "feedback": "Correct. This is the general term that covers all aspects of maintaining clothing."
        },
        {
            "text": "Fashion design",
            "feedback": "Incorrect. Fashion design is the art of creating clothes."
        },
        {
            "text": "Sewing",
            "feedback": "Incorrect. Sewing is the craft of fastening or attaching objects using stitches made with a needle and thread."
        },
        {
            "text": "Shopping",
            "feedback": "Incorrect. Shopping is the act of buying clothes."
        }
    ],
    "correctAnswer": "Care of clothes"
},
{
    "id": 195,
    "question": "How do you say 'Thank you' in French?",
    "generalFeedback": "Expressing gratitude is a fundamental part of politeness in any language.",
    "answers": [
        {
            "text": "Merci",
            "feedback": "Correct. 'Merci' is the standard way to say 'Thank you'."
        },
        {
            "text": "S'il vous pla\u00eet",
            "feedback": "Incorrect. This means 'Please'."
        },
        {
            "text": "Bonjour",
            "feedback": "Incorrect. This means 'Hello'."
        },
        {
            "text": "Excusez-moi",
            "feedback": "Incorrect. This means 'Excuse me'."
        }
    ],
    "correctAnswer": "Merci"
},
{
    "id": 196,
    "question": "The highness or lowness of a musical sound is called its ___.",
    "generalFeedback": "Sound has several properties, and this term specifically describes its frequency.",
    "answers": [
        {
            "text": "Pitch",
            "feedback": "Correct. Pitch is determined by the frequency of sound wave vibrations."
        },
        {
            "text": "Volume",
            "feedback": "Incorrect. Volume (or dynamics) refers to the loudness or softness of the sound."
        },
        {
            "text": "Tempo",
            "feedback": "Incorrect. Tempo refers to the speed of the music."
        },
        {
            "text": "Timbre",
            "feedback": "Incorrect. Timbre (or tone quality) is what distinguishes different types of sound production, such as voices and musical instruments."
        }
    ],
    "correctAnswer": "Pitch"
},
{
    "id": 197,
    "question": "Find the area of a rectangle with length 10cm and width 5cm.",
    "generalFeedback": "The area of a rectangle is calculated by multiplying its length by its width. The unit for area is a square unit.",
    "answers": [
        {
            "text": "50 cm\u00b2",
            "feedback": "Correct. Area = Length \u00d7 Width = 10 cm \u00d7 5 cm = 50 cm\u00b2."
        },
        {
            "text": "30 cm",
            "feedback": "Incorrect. This is the perimeter of the rectangle (10+5+10+5). The question asks for the area."
        },
        {
            "text": "15 cm",
            "feedback": "Incorrect. This is the sum of the length and width, not the product."
        },
        {
            "text": "50 cm",
            "feedback": "Incorrect. The calculation is correct, but the unit for area should be square centimeters (cm\u00b2), not centimeters (cm)."
        }
    ],
    "correctAnswer": "50 cm\u00b2"
},
{
    "id": 198,
    "question": "A story, poem, or picture that can be interpreted to reveal a hidden meaning, typically a moral or political one, is called ___.",
    "generalFeedback": "In literature, some stories work on two levels: a literal level and a symbolic level.",
    "answers": [
        {
            "text": "An allegory",
            "feedback": "Correct. An allegory is a narrative in which characters and events represent abstract ideas or historical events. George Orwell's 'Animal Farm' is a famous example."
        },
        {
            "text": "A biography",
            "feedback": "Incorrect. A biography is the story of a person's life written by someone else."
        },
        {
            "text": "A comedy",
            "feedback": "Incorrect. A comedy is a genre of fiction intended to be humorous."
        },
        {
            "text": "A rhyme",
            "feedback": "Incorrect. A rhyme is the repetition of similar sounds in words, often used in poetry."
        }
    ],
    "correctAnswer": "An allegory"
},
{
    "id": 199,
    "question": "The release of harmful substances into the environment is called ___.",
    "generalFeedback": "A key topic in Basic Science and Social Studies is understanding the impact of human activities on the natural world.",
    "answers": [
        {
            "text": "Pollution",
            "feedback": "Correct. Pollution is the introduction of contaminants into the natural environment that cause adverse change."
        },
        {
            "text": "Erosion",
            "feedback": "Incorrect. Erosion is the process by which soil and rock are removed from the Earth's surface by processes such as water flow or wind."
        },
        {
            "text": "Recycling",
            "feedback": "Incorrect. Recycling is the process of converting waste materials into new materials and objects; it is a solution to pollution, not the problem itself."
        },
        {
            "text": "Conservation",
            "feedback": "Incorrect. Conservation is the protection of animals, plants, and natural resources."
        }
    ],
    "correctAnswer": "Pollution"
},
{
    "id": 200,
    "question": "What does a T-square help you draw in technical drawing?",
    "generalFeedback": "A T-square is a fundamental tool in manual technical drawing, used for establishing a consistent reference on the drawing board.",
    "answers": [
        {
            "text": "Horizontal lines",
            "feedback": "Correct. A T-square is used to draw accurate horizontal lines and serves as a base for triangles to draw vertical and angled lines."
        },
        {
            "text": "Vertical lines",
            "feedback": "Incorrect. To draw vertical lines, you would place a set square or triangle on the T-square."
        },
        {
            "text": "Circles",
            "feedback": "Incorrect. Circles are drawn using a pair of compasses."
        },
        {
            "text": "Freehand curves",
            "feedback": "Incorrect. These are drawn without instruments, or with a French curve for more precise shapes."
        }
    ],
    "correctAnswer": "Horizontal lines"
},
{
    "id": 201,
    "question": "The title of a traditional ruler in the Benin Kingdom is ___.",
    "generalFeedback": "Nigeria's rich history includes powerful kingdoms with unique titles for their sovereigns.",
    "answers": [
        {
            "text": "Oba",
            "feedback": "Correct. The Oba is the traditional ruler of the Edo people and head of the historic Eweka dynasty of the Benin Kingdom."
        },
        {
            "text": "Alaafin",
            "feedback": "Incorrect. This is the title for the ruler of the Oyo Empire."
        },
        {
            "text": "Emir",
            "feedback": "Incorrect. This is the title for rulers in the northern Islamic states."
        },
        {
            "text": "Ooni",
            "feedback": "Incorrect. This is the title for the traditional ruler of Ile-Ife."
        }
    ],
    "correctAnswer": "Oba"
},
{
    "id": 202,
    "question": "An animal that eats only plants is called a/an ___.",
    "generalFeedback": "In Agricultural Science and Biology, animals are classified based on their diet.",
    "answers": [
        {
            "text": "Herbivore",
            "feedback": "Correct. Herbivores, like cows and goats, are anatomically and physiologically adapted to eating plant material."
        },
        {
            "text": "Carnivore",
            "feedback": "Incorrect. Carnivores, like lions, eat other animals."
        },
        {
            "text": "Omnivore",
            "feedback": "Incorrect. Omnivores, like humans and pigs, eat both plants and animals."
        },
        {
            "text": "Predator",
            "feedback": "Incorrect. A predator is an animal that hunts other animals for food. It is a type of carnivore or omnivore."
        }
    ],
    "correctAnswer": "Herbivore"
},
{
    "id": 203,
    "question": "A family that consists of a father, mother, and their children is called a ___.",
    "generalFeedback": "Social Studies classifies family structures based on their composition.",
    "answers": [
        {
            "text": "Nuclear family",
            "feedback": "Correct. A nuclear family is the core family unit."
        },
        {
            "text": "Extended family",
            "feedback": "Incorrect. An extended family includes other relatives like grandparents, uncles, aunts, and cousins living together."
        },
        {
            "text": "Single-parent family",
            "feedback": "Incorrect. A single-parent family consists of one parent raising one or more children on their own."
        },
        {
            "text": "Compound family",
            "feedback": "Incorrect. A compound family, often associated with polygamy, includes a husband with multiple wives and their children."
        }
    ],
    "correctAnswer": "Nuclear family"
},
{
    "id": 204,
    "question": "What is the primary function of an office secretary?",
    "generalFeedback": "Office Practice involves understanding the roles and responsibilities of different office personnel.",
    "answers": [
        {
            "text": "Handling correspondence and administrative tasks",
            "feedback": "Correct. A secretary's duties typically include typing, answering phones, managing appointments, and handling mail."
        },
        {
            "text": "Making major financial decisions for the company",
            "feedback": "Incorrect. This is the role of a manager, director, or chief financial officer (CFO)."
        },
        {
            "text": "Cleaning the office",
            "feedback": "Incorrect. This is the responsibility of the cleaning staff or janitor."
        },
        {
            "text": "Repairing office equipment",
            "feedback": "Incorrect. This is the job of a technician."
        }
    ],
    "correctAnswer": "Handling correspondence and administrative tasks"
},
{
    "id": 205,
    "question": "Mixing blue and yellow paint creates which colour?",
    "generalFeedback": "Color mixing is a fundamental concept in visual arts. Secondary colors are created by mixing two primary colors.",
    "answers": [
        {
            "text": "Green",
            "feedback": "Correct. Green is the secondary color produced by mixing the primary colors blue and yellow."
        },
        {
            "text": "Orange",
            "feedback": "Incorrect. Orange is created by mixing red and yellow."
        },
        {
            "text": "Purple",
            "feedback": "Incorrect. Purple is created by mixing red and blue."
        },
        {
            "text": "Brown",
            "feedback": "Incorrect. Brown is a tertiary color, often created by mixing complementary colors or all three primary colors."
        }
    ],
    "correctAnswer": "Green"
},
{
    "id": 206,
    "question": "Jesus' teaching in stories to illustrate a moral or spiritual lesson are called ___.",
    "generalFeedback": "Jesus used a specific teaching method to make complex spiritual truths accessible to his listeners.",
    "answers": [
        {
            "text": "Parables",
            "feedback": "Correct. Parables, like the Parable of the Good Samaritan or the Prodigal Son, are a key feature of Jesus' teachings in the Gospels."
        },
        {
            "text": "Miracles",
            "feedback": "Incorrect. Miracles were supernatural acts performed by Jesus, such as healing the sick or walking on water."
        },
        {
            "text": "Commandments",
            "feedback": "Incorrect. Commandments are direct orders or laws, like the Ten Commandments."
        },
        {
            "text": "Prophecies",
            "feedback": "Incorrect. Prophecies are predictions of future events."
        }
    ],
    "correctAnswer": "Parables"
},
{
    "id": 207,
    "question": "A global network of interconnected computers is known as the ___.",
    "generalFeedback": "This term describes the massive infrastructure that allows computers worldwide to communicate with one another.",
    "answers": [
        {
            "text": "Internet",
            "feedback": "Correct. The Internet is the worldwide system of computer networks that uses the Internet protocol suite (TCP/IP) to link devices."
        },
        {
            "text": "World Wide Web (WWW)",
            "feedback": "Incorrect. The World Wide Web is a system of interlinked hypertext documents accessed via the Internet. It is a service on the Internet, not the network itself."
        },
        {
            "text": "Intranet",
            "feedback": "Incorrect. An intranet is a private network contained within an enterprise."
        },
        {
            "text": "CPU",
            "feedback": "Incorrect. The CPU is the central processing unit of a single computer."
        }
    ],
    "correctAnswer": "Internet"
},
{
    "id": 208,
    "question": "What is the Igbo word for 'child' or 'children'?",
    "generalFeedback": "Knowing basic vocabulary for family members is essential in learning Igbo.",
    "answers": [
        {
            "text": "Nwa / \u1ee4m\u1ee5aka",
            "feedback": "Correct. 'Nwa' is singular for child, and '\u1ee4m\u1ee5aka' is plural for children."
        },
        {
            "text": "Okenye",
            "feedback": "Incorrect. 'Okenye' means an elder or adult."
        },
        {
            "text": "Mmad\u1ee5",
            "feedback": "Incorrect. 'Mmad\u1ee5' means person or human being."
        },
        {
            "text": "Enyi",
            "feedback": "Incorrect. 'Enyi' means friend."
        }
    ],
    "correctAnswer": "Nwa / \u1ee4m\u1ee5aka"
},
{
    "id": 209,
    "question": "Which of these is a healthy habit related to eating?",
    "generalFeedback": "Home Economics teaches not just how to cook, but also the principles of healthy eating for overall well-being.",
    "answers": [
        {
            "text": "Washing hands before and after eating",
            "feedback": "Correct. This is a crucial hygiene practice to prevent the transfer of germs."
        },
        {
            "text": "Eating very fast without chewing properly",
            "feedback": "Incorrect. This can lead to indigestion and is not a healthy habit."
        },
        {
            "text": "Watching TV or using a phone while eating",
            "feedback": "Incorrect. This can lead to mindless overeating and poor digestion."
        },
        {
            "text": "Skipping breakfast regularly",
            "feedback": "Incorrect. Breakfast is often considered the most important meal of the day as it provides energy to start the day."
        }
    ],
    "correctAnswer": "Washing hands before and after eating"
},
{
    "id": 210,
    "question": "In French, how do you ask 'What is your name?'",
    "generalFeedback": "Introducing oneself and asking for someone's name is a fundamental conversational skill.",
    "answers": [
        {
            "text": "Comment t'appelles-tu ?",
            "feedback": "Correct. This is the standard way to ask 'What is your name?' in an informal setting."
        },
        {
            "text": "Quel \u00e2ge as-tu ?",
            "feedback": "Incorrect. This means 'How old are you?'"
        },
        {
            "text": "Comment \u00e7a va ?",
            "feedback": "Incorrect. This means 'How are you?'"
        },
        {
            "text": "O\u00f9 habites-tu ?",
            "feedback": "Incorrect. This means 'Where do you live?'"
        }
    ],
    "correctAnswer": "Comment t'appelles-tu ?"
},
{
  "id": 211,
  "question": "Calculate the value of 3 + 5 x 2 using BODMAS.",
  "subject": "Mathematics",
  "generalFeedback": "The order of operations, often remembered by the acronym BODMAS/PEMDAS, dictates that Multiplication should be performed before Addition. BODMAS stands for Brackets, Orders, Division, Multiplication, Addition, Subtraction.",
  "answers": [
      {
          "text": "13",
          "feedback": "Correct. You correctly performed multiplication first (5 x 2 = 10) and then added 3 (10 + 3 = 13)."
      },
      {
          "text": "16",
          "feedback": "Incorrect. This result comes from adding first (3 + 5 = 8) and then multiplying by 2 (8 x 2 = 16), which violates the BODMAS rule."
      },
      {
          "text": "10",
          "feedback": "Incorrect. This is the result of only the multiplication part. You forgot to add the 3."
      },
      {
          "text": "30",
          "feedback": "Incorrect. This seems to be a calculation error. Recheck the order of operations."
      }
  ],
  "correctAnswer": "13"
},
{
  "id": 212,
  "question": "What is the perimeter of a rectangle with a length of 8cm and a width of 5cm?",
  "subject": "Mathematics",
  "generalFeedback": "The perimeter of a shape is the total distance around its edges. For a rectangle, the formula is P = 2(Length + Width) or P = L + L + W + W.",
  "answers": [
      {
          "text": "13cm",
          "feedback": "Incorrect. This is the sum of the length and width (8 + 5). You need to account for all four sides."
      },
      {
          "text": "40cm",
          "feedback": "Incorrect. This is the area of the rectangle (Length x Width), not the perimeter."
      },
      {
          "text": "26cm",
          "feedback": "Correct. Using the formula 2(8 + 5), we get 2(13) = 26cm. Or, 8 + 8 + 5 + 5 = 26cm."
      },
      {
          "text": "16cm",
          "feedback": "Incorrect. This is the sum of two lengths only. A rectangle has four sides."
      }
  ],
  "correctAnswer": "26cm"
},
{
  "id": 213,
  "question": "Convert 75% to a fraction in its simplest form.",
  "subject": "Mathematics",
  "generalFeedback": "The word 'percent' means 'out of 100'. To convert a percentage to a fraction, you write the number over 100 and then simplify by dividing the numerator and denominator by their greatest common factor.",
  "answers": [
      {
          "text": "75/100",
          "feedback": "Partially correct, but this is not the simplest form. You need to simplify the fraction."
      },
      {
          "text": "3/4",
          "feedback": "Correct. 75/100 can be simplified by dividing both the top and bottom by 25, which gives 3/4."
      },
      {
          "text": "1/4",
          "feedback": "Incorrect. This represents 25%, not 75%."
      },
      {
          "text": "7.5/10",
          "feedback": "Incorrect. This is not the standard way to represent a fraction, and it is not simplified."
      }
  ],
  "correctAnswer": "3/4"
},
{
  "id": 214,
  "question": "Find the value of x in the equation: x - 7 = 15.",
  "subject": "Mathematics",
  "generalFeedback": "To solve for 'x' in this simple algebraic equation, you need to isolate 'x' on one side. You can do this by performing the opposite operation. Since 7 is being subtracted from x, you should add 7 to both sides of the equation.",
  "answers": [
      {
          "text": "8",
          "feedback": "Incorrect. This result is from subtracting 7 from 15 (15 - 7), not adding it."
      },
      {
          "text": "22",
          "feedback": "Correct. When you add 7 to both sides (x - 7 + 7 = 15 + 7), you get x = 22."
      },
      {
          "text": "15",
          "feedback": "Incorrect. This is the value on the other side of the equation, not the value of x."
      },
      {
          "text": "105",
          "feedback": "Incorrect. This looks like a multiplication (15 x 7). The equation requires addition to solve for x."
      }
  ],
  "correctAnswer": "22"
},
{
  "id": 215,
  "question": "Which of these is a unit of mass?",
  "subject": "Mathematics",
  "generalFeedback": "Units of measurement are specific to the quantity being measured. Mass measures the amount of matter in an object.",
  "answers": [
      {
          "text": "Metre (m)",
          "feedback": "Incorrect. A metre is a unit of length or distance."
      },
      {
          "text": "Litre (l)",
          "feedback": "Incorrect. A litre is a unit of volume or capacity."
      },
      {
          "text": "Kilogram (kg)",
          "feedback": "Correct. The kilogram (and gram) is a standard unit used to measure mass."
      },
      {
          "text": "Second (s)",
          "feedback": "Incorrect. A second is a unit of time."
      }
  ],
  "correctAnswer": "Kilogram (kg)"
},
{
  "id": 216,
  "question": "A straight line has an angle of...",
  "subject": "Mathematics",
  "generalFeedback": "Angles are measured in degrees. A full circle is 360\u00b0, and different types of angles have specific degree measures.",
  "answers": [
      {
          "text": "90\u00b0",
          "feedback": "Incorrect. 90\u00b0 is a right angle, typically found at the corner of a square."
      },
      {
          "text": "180\u00b0",
          "feedback": "Correct. An angle on a straight line is always 180\u00b0."
      },
      {
          "text": "360\u00b0",
          "feedback": "Incorrect. 360\u00b0 represents a full circle or a complete revolution."
      },
      {
          "text": "45\u00b0",
          "feedback": "Incorrect. This is an acute angle, which is less than 90\u00b0."
      }
  ],
  "correctAnswer": "180\u00b0"
},
{
  "id": 217,
  "question": "Which of these numbers is a prime number?",
  "subject": "Mathematics",
  "generalFeedback": "A prime number is a whole number greater than 1 that has only two factors: 1 and itself.",
  "answers": [
      {
          "text": "9",
          "feedback": "Incorrect. 9 has factors 1, 3, and 9. Since it has more than two factors, it is not prime."
      },
      {
          "text": "15",
          "feedback": "Incorrect. 15 has factors 1, 3, 5, and 15."
      },
      {
          "text": "11",
          "feedback": "Correct. The only numbers that can divide 11 without a remainder are 1 and 11."
      },
      {
          "text": "21",
          "feedback": "Incorrect. 21 has factors 1, 3, 7, and 21."
      }
  ],
  "correctAnswer": "11"
},
{
  "id": 218,
  "question": "Find the average (mean) of these numbers: 4, 6, 8.",
  "subject": "Mathematics",
  "generalFeedback": "To find the mean or average of a set of numbers, you first add all the numbers together and then divide the sum by the count of the numbers in the set.",
  "answers": [
      {
          "text": "18",
          "feedback": "Incorrect. This is the sum of the numbers (4 + 6 + 8), not the average."
      },
      {
          "text": "6",
          "feedback": "Correct. The sum is 4 + 6 + 8 = 18. There are 3 numbers, so the average is 18 \u00f7 3 = 6."
      },
      {
          "text": "8",
          "feedback": "Incorrect. This is the largest number in the set, not the average."
      },
      {
          "text": "3",
          "feedback": "Incorrect. This is the count of the numbers, not their average."
      }
  ],
  "correctAnswer": "6"
},
{
  "id": 219,
  "question": "Which of the following is a pronoun?",
  "subject": "English Language",
  "generalFeedback": "A pronoun is a word that is used instead of a noun or noun phrase. Examples include he, she, it, they, we, you.",
  "answers": [
      {
          "text": "Run",
          "feedback": "Incorrect. 'Run' is a verb, which describes an action."
      },
      {
          "text": "Happy",
          "feedback": "Incorrect. 'Happy' is an adjective, which describes a noun."
      },
      {
          "text": "They",
          "feedback": "Correct. 'They' is a pronoun used to refer to a group of people or things."
      },
      {
          "text": "Quickly",
          "feedback": "Incorrect. 'Quickly' is an adverb, which describes a verb."
      }
  ],
  "correctAnswer": "They"
},
{
  "id": 220,
  "question": "Choose the correct past tense of the verb 'go'.",
  "subject": "English Language",
  "generalFeedback": "Verbs change their form to show the time of an action. The past tense shows that an action has already happened. 'Go' is an irregular verb, so its past tense form doesn't end in '-ed'.",
  "answers": [
      {
          "text": "Goed",
          "feedback": "Incorrect. This is a common mistake for irregular verbs. 'Go' does not follow the regular '-ed' rule."
      },
      {
          "text": "Gone",
          "feedback": "Incorrect. 'Gone' is the past participle, used with auxiliary verbs like 'has', 'have', or 'had' (e.g., 'They have gone')."
      },
      {
          "text": "Went",
          "feedback": "Correct. 'Went' is the simple past tense of 'go' (e.g., 'She went to the market')."
      },
      {
          "text": "Going",
          "feedback": "Incorrect. 'Going' is the present participle, used to show continuous action (e.g., 'He is going')."
      }
  ],
  "correctAnswer": "Went"
},
{
  "id": 221,
  "question": "Which sentence is correctly punctuated?",
  "subject": "English Language",
  "generalFeedback": "A sentence should begin with a capital letter and end with a punctuation mark like a full stop, question mark, or exclamation mark.",
  "answers": [
      {
          "text": "where are you going",
          "feedback": "Incorrect. This is a question and should start with a capital letter and end with a question mark."
      },
      {
          "text": "Where are you going?",
          "feedback": "Correct. It starts with a capital letter and ends with a question mark, which is appropriate for a question."
      },
      {
          "text": "Where are you going.",
          "feedback": "Incorrect. While it has a capital letter, it ends with a full stop. Questions must end with a question mark."
      },
      {
          "text": "where are you going?",
          "feedback": "Incorrect. It ends with the correct punctuation but does not start with a capital letter."
      }
  ],
  "correctAnswer": "Where are you going?"
},
{
  "id": 222,
  "question": "An antonym is a word that means the...",
  "subject": "English Language",
  "generalFeedback": "Vocabulary includes understanding the relationships between words. Synonyms are words with similar meanings, while antonyms are words with opposite meanings.",
  "answers": [
      {
          "text": "same",
          "feedback": "Incorrect. A word that means the same is a synonym."
      },
      {
          "text": "opposite",
          "feedback": "Correct. Antonyms are words with opposite meanings, like 'hot' and 'cold' or 'happy' and 'sad'."
      },
      {
          "text": "sound",
          "feedback": "Incorrect. Words that sound the same but have different meanings are called homophones (e.g., 'their' and 'there')."
      },
      {
          "text": "spelling",
          "feedback": "Incorrect. This is not a standard definition for a word relationship."
      }
  ],
  "correctAnswer": "opposite"
},
{
  "id": 223,
  "question": "In the sentence 'The cat sat on the mat,' what part of speech is 'on'?",
  "subject": "English Language",
  "generalFeedback": "Parts of speech define the function of a word in a sentence. A preposition is a word that shows the relationship between a noun (or pronoun) and another word in the sentence, often indicating location or direction.",
  "answers": [
      {
          "text": "Noun",
          "feedback": "Incorrect. A noun is a person, place, or thing, like 'cat' or 'mat'."
      },
      {
          "text": "Verb",
          "feedback": "Incorrect. A verb is an action word, like 'sat'."
      },
      {
          "text": "Adjective",
          "feedback": "Incorrect. An adjective describes a noun, like 'the *fluffy* cat'."
      },
      {
          "text": "Preposition",
          "feedback": "Correct. 'On' shows the location of the cat in relation to the mat."
      }
  ],
  "correctAnswer": "Preposition"
},
{
  "id": 224,
  "question": "A story written to be acted on a stage is called a...",
  "subject": "English Language",
  "generalFeedback": "Literature is divided into different genres or types, each with its own unique structure and purpose.",
  "answers": [
      {
          "text": "Poem",
          "feedback": "Incorrect. A poem is a piece of writing that uses imaginative language and is often written in verse."
      },
      {
          "text": "Novel",
          "feedback": "Incorrect. A novel is a long work of prose fiction."
      },
      {
          "text": "Drama",
          "feedback": "Correct. Drama (or a play) is a literary work written in dialogue form, intended for performance by actors on a stage."
      },
      {
          "text": "Biography",
          "feedback": "Incorrect. A biography is the story of a person's life written by someone else."
      }
  ],
  "correctAnswer": "Drama"
},
{
  "id": 225,
  "question": "The phrase 'as brave as a lion' is an example of a...",
  "subject": "English Language",
  "generalFeedback": "Figures of speech are literary devices used to make language more colorful and impactful. A simile is a comparison between two different things using the words 'like' or 'as'.",
  "answers": [
      {
          "text": "Metaphor",
          "feedback": "Incorrect. A metaphor is a direct comparison without using 'like' or 'as' (e.g., 'He is a lion')."
      },
      {
          "text": "Simile",
          "feedback": "Correct. This phrase compares someone's bravery to that of a lion using the word 'as'."
      },
      {
          "text": "Personification",
          "feedback": "Incorrect. Personification gives human qualities to inanimate objects (e.g., 'The wind whispered')."
      },
      {
          "text": "Hyperbole",
          "feedback": "Incorrect. Hyperbole is an extreme exaggeration (e.g., 'I'm so hungry I could eat a horse')."
      }
  ],
  "correctAnswer": "Simile"
},
{
  "id": 226,
  "question": "Which of these is NOT an informal letter?",
  "subject": "English Language",
  "generalFeedback": "Letters are categorized as formal or informal. Informal letters are written to friends and family in a casual tone, while formal letters are written for official or professional purposes.",
  "answers": [
      {
          "text": "A letter to your friend",
          "feedback": "Incorrect. This is a classic example of an informal letter."
      },
      {
          "text": "A letter to your mother",
          "feedback": "Incorrect. This is an informal letter written to a family member."
      },
      {
          "text": "A letter applying for a job",
          "feedback": "Correct. A letter of application is a formal letter, requiring a specific structure and professional tone."
      },
      {
          "text": "A letter to your cousin",
          "feedback": "Incorrect. This is another example of an informal letter."
      }
  ],
  "correctAnswer": "A letter applying for a job"
},
{
  "id": 227,
  "question": "Which of the following is a characteristic of all living things?",
  "subject": "Basic Science",
  "generalFeedback": "All living organisms share certain life processes. These are often remembered by the acronym MR NIGER D: Movement, Respiration, Nutrition, Irritability, Growth, Excretion, Reproduction.",
  "answers": [
      {
          "text": "Walking",
          "feedback": "Incorrect. Not all living things walk. Plants, for example, are living but do not walk."
      },
      {
          "text": "Talking",
          "feedback": "Incorrect. Talking is a form of communication specific to humans and some animals, not all living things."
      },
      {
          "text": "Growth",
          "feedback": "Correct. All living things grow, meaning they increase in size and complexity."
      },
      {
          "text": "Sleeping",
          "feedback": "Incorrect. While many animals sleep, plants and microorganisms do not sleep in the same way."
      }
  ],
  "correctAnswer": "Growth"
},
{
  "id": 228,
  "question": "What are the three states of matter?",
  "subject": "Basic Science",
  "generalFeedback": "Matter is anything that has mass and takes up space. It exists mainly in three states or phases, which are determined by the arrangement and energy of its particles.",
  "answers": [
      {
          "text": "Hot, Cold, and Warm",
          "feedback": "Incorrect. These are measures of temperature, not states of matter."
      },
      {
          "text": "Solid, Liquid, and Gas",
          "feedback": "Correct. These are the three fundamental states of matter. For example, water can be a solid (ice), a liquid (water), or a gas (steam)."
      },
      {
          "text": "Hard, Soft, and Rough",
          "feedback": "Incorrect. These are descriptions of texture, which is a property of matter, but not a state of matter."
      },
      {
          "text": "Element, Compound, and Mixture",
          "feedback": "Incorrect. These are classifications of substances, not states of matter."
      }
  ],
  "correctAnswer": "Solid, Liquid, and Gas"
},
{
  "id": 229,
  "question": "The process by which green plants make their own food using sunlight is called...",
  "subject": "Basic Science",
  "generalFeedback": "Plants are producers in the food chain. They have a unique ability to convert light energy into chemical energy (food).",
  "answers": [
      {
          "text": "Respiration",
          "feedback": "Incorrect. Respiration is the process of breaking down food to release energy, which occurs in both plants and animals."
      },
      {
          "text": "Photosynthesis",
          "feedback": "Correct. 'Photo' means light and 'synthesis' means to make. Photosynthesis is the process of making food using light."
      },
      {
          "text": "Transpiration",
          "feedback": "Incorrect. Transpiration is the process of water movement through a plant and its evaporation from leaves."
      },
      {
          "text": "Digestion",
          "feedback": "Incorrect. Digestion is the process of breaking down food in animals."
      }
  ],
  "correctAnswer": "Photosynthesis"
},
{
  "id": 230,
  "question": "Which of these is a form of energy?",
  "subject": "Basic Science",
  "generalFeedback": "Energy is the ability to do work. It exists in many different forms that can be converted from one to another.",
  "answers": [
      {
          "text": "Air",
          "feedback": "Incorrect. Air is a mixture of gases; it is matter, not a form of energy."
      },
      {
          "text": "Water",
          "feedback": "Incorrect. Water is a compound (matter), not a form of energy."
      },
      {
          "text": "Heat",
          "feedback": "Correct. Heat is a form of thermal energy that transfers from a hotter object to a colder one."
      },
      {
          "text": "Wood",
          "feedback": "Incorrect. Wood is a material (matter) that contains chemical energy, but it is not a form of energy itself."
      }
  ],
  "correctAnswer": "Heat"
},
{
  "id": 231,
  "question": "The control center of a living cell is the...",
  "subject": "Basic Science",
  "generalFeedback": "A cell has various parts called organelles, each with a specific function. The nucleus acts like the 'brain' of the cell.",
  "answers": [
      {
          "text": "Cell membrane",
          "feedback": "Incorrect. The cell membrane controls what enters and leaves the cell, like a gatekeeper."
      },
      {
          "text": "Cytoplasm",
          "feedback": "Incorrect. The cytoplasm is the jelly-like substance where all the other organelles are located."
      },
      {
          "text": "Nucleus",
          "feedback": "Correct. The nucleus contains the cell's genetic material (DNA) and controls all the cell's activities."
      },
      {
          "text": "Vacuole",
          "feedback": "Incorrect. The vacuole is primarily used for storage of water, food, and waste."
      }
  ],
  "correctAnswer": "Nucleus"
},
{
  "id": 232,
  "question": "A change from liquid to gas is called...",
  "subject": "Basic Science",
  "generalFeedback": "Matter can change from one state to another when heat is added or removed. These changes have specific names.",
  "answers": [
      {
          "text": "Melting",
          "feedback": "Incorrect. Melting is the change from a solid to a liquid."
      },
      {
          "text": "Freezing",
          "feedback": "Incorrect. Freezing is the change from a liquid to a solid."
      },
      {
          "text": "Evaporation",
          "feedback": "Correct. Evaporation is the process where a liquid turns into a gas, such as water boiling to become steam."
      },
      {
          "text": "Condensation",
          "feedback": "Incorrect. Condensation is the change from a gas to a liquid."
      }
  ],
  "correctAnswer": "Evaporation"
},
{
  "id": 233,
  "question": "Which simple machine would be most helpful for lifting a heavy box into a truck?",
  "subject": "Basic Science",
  "generalFeedback": "Simple machines help us do work by changing the direction or magnitude of a force. Each type is suited for different tasks.",
  "answers": [
      {
          "text": "A lever",
          "feedback": "Incorrect. While a lever can lift heavy objects, an inclined plane is more typically used for this specific task."
      },
      {
          "text": "A pulley",
          "feedback": "Incorrect. A pulley is used to lift objects vertically, often with a rope or cable."
      },
      {
          "text": "An inclined plane",
          "feedback": "Correct. An inclined plane, like a ramp, allows you to move a heavy object to a higher level with less effort than lifting it straight up."
      },
      {
          "text": "A wheel and axle",
          "feedback": "Incorrect. A wheel and axle helps in moving objects along a surface, but not necessarily lifting them to a different height."
      }
  ],
  "correctAnswer": "An inclined plane"
},
{
  "id": 234,
  "question": "A balanced diet is a meal that...",
  "subject": "Basic Science",
  "generalFeedback": "Good nutrition is essential for health. A balanced diet ensures the body gets all the necessary nutrients in the right amounts.",
  "answers": [
      {
          "text": "tastes very delicious.",
          "feedback": "Incorrect. While a balanced diet can be delicious, taste is subjective and not its defining feature."
      },
      {
          "text": "is very expensive to buy.",
          "feedback": "Incorrect. A balanced diet can be made from affordable, locally available foods."
      },
      {
          "text": "contains only one class of food.",
          "feedback": "Incorrect. A diet with only one class of food would be unbalanced and lead to nutrient deficiencies."
      },
      {
          "text": "contains all classes of food in the right proportions.",
          "feedback": "Correct. This is the definition of a balanced diet, providing carbohydrates, proteins, fats, vitamins, minerals, and water."
      }
  ],
  "correctAnswer": "contains all classes of food in the right proportions."
},
{
  "id": 235,
  "question": "In a technology workshop, why is it important to wear safety goggles?",
  "subject": "Basic Technology",
  "generalFeedback": "Safety in the workshop is the number one priority. Personal Protective Equipment (PPE) like safety goggles is designed to prevent specific types of injuries.",
  "answers": [
      {
          "text": "To look like a professional",
          "feedback": "Incorrect. While they are part of a professional's gear, their purpose is safety, not appearance."
      },
      {
          "text": "To protect your eyes from flying debris",
          "feedback": "Correct. Activities like cutting, grinding, or hammering can send small particles flying, which can cause serious eye injury."
      },
      {
          "text": "To keep your hair out of your face",
          "feedback": "Incorrect. A hairnet or tying back long hair is the correct way to manage hair in a workshop."
      },
      {
          "text": "To see your work more clearly",
          "feedback": "Incorrect. While some goggles can have prescription lenses, their primary function is protection, not vision enhancement."
      }
  ],
  "correctAnswer": "To protect your eyes from flying debris"
},
{
  "id": 236,
  "question": "Which of these is a technical drawing instrument used for drawing circles?",
  "subject": "Basic Technology",
  "generalFeedback": "Technical drawing requires precision, and specific instruments are used to create accurate lines and shapes.",
  "answers": [
      {
          "text": "A ruler",
          "feedback": "Incorrect. A ruler is used for measuring and drawing straight lines."
      },
      {
          "text": "A T-square",
          "feedback": "Incorrect. A T-square is used for drawing horizontal lines on a drawing board."
      },
      {
          "text": "A pair of compasses",
          "feedback": "Correct. A pair of compasses is the instrument specifically designed to draw circles and arcs."
      },
      {
          "text": "A protractor",
          "feedback": "Incorrect. A protractor is used for measuring and drawing angles."
      }
  ],
  "correctAnswer": "A pair of compasses"
},
{
  "id": 237,
  "question": "Wood is a material obtained from...",
  "subject": "Basic Technology",
  "generalFeedback": "Materials used in technology come from various sources. Understanding these sources is a fundamental concept.",
  "answers": [
      {
          "text": "The ground",
          "feedback": "Incorrect. While trees grow in the ground, materials like stone or metal are more directly obtained from the ground."
      },
      {
          "text": "Animals",
          "feedback": "Incorrect. Materials like leather and wool are obtained from animals."
      },
      {
          "text": "Trees",
          "feedback": "Correct. Wood is the primary material that makes up the trunk and branches of trees."
      },
      {
          "text": "Factories",
          "feedback": "Incorrect. Factories process raw materials like wood, but they don't create it."
      }
  ],
  "correctAnswer": "Trees"
},
{
  "id": 238,
  "question": "Which of these tools is used for cutting metal?",
  "subject": "Basic Technology",
  "generalFeedback": "Different tools are designed for specific materials and tasks. Using the right tool for the job is crucial for safety and effectiveness.",
  "answers": [
      {
          "text": "A handsaw",
          "feedback": "Incorrect. A handsaw is primarily used for cutting wood."
      },
      {
          "text": "A file",
          "feedback": "Incorrect. A file is used for smoothing or shaping metal and wood, not for cutting through it."
      },
      {
          "text": "A hacksaw",
          "feedback": "Correct. A hacksaw, with its fine-toothed blade, is specifically designed for cutting metal."
      },
      {
          "text": "A chisel",
          "feedback": "Incorrect. A chisel is used for carving or shaping wood or stone."
      }
  ],
  "correctAnswer": "A hacksaw"
},
{
  "id": 239,
  "question": "The energy we get from the sun is called...",
  "subject": "Basic Technology",
  "generalFeedback": "Energy can be classified based on its source. The sun is the primary source of energy for the Earth.",
  "answers": [
      {
          "text": "Wind energy",
          "feedback": "Incorrect. Wind energy is derived from the movement of air."
      },
      {
          "text": "Solar energy",
          "feedback": "Correct. 'Solar' relates to the sun. Solar energy is the light and heat that comes from the sun."
      },
      {
          "text": "Geothermal energy",
          "feedback": "Incorrect. Geothermal energy is heat from within the Earth."
      },
      {
          "text": "Electrical energy",
          "feedback": "Incorrect. Electrical energy is the flow of electric charge. Solar energy can be converted into electrical energy."
      }
  ],
  "correctAnswer": "Solar energy"
},
{
  "id": 240,
  "question": "Which of these is an example of a first-class lever?",
  "subject": "Basic Technology",
  "generalFeedback": "Levers are classified into three types based on the relative positions of the fulcrum, effort, and load. In a first-class lever, the fulcrum is in the middle.",
  "answers": [
      {
          "text": "A wheelbarrow",
          "feedback": "Incorrect. A wheelbarrow is a second-class lever, where the load is between the fulcrum and the effort."
      },
      {
          "text": "A pair of scissors",
          "feedback": "Correct. In a pair of scissors, the pivot (fulcrum) is between the handles (effort) and the blades (load)."
      },
      {
          "text": "A fishing rod",
          "feedback": "Incorrect. A fishing rod is a third-class lever, where the effort is between the fulcrum and the load."
      },
      {
          "text": "A bottle opener",
          "feedback": "Incorrect. A bottle opener is typically a second-class lever."
      }
  ],
  "correctAnswer": "A pair of scissors"
},
{
  "id": 241,
  "question": "In technical drawing, a line drawn with short dashes (----) usually represents a...",
  "subject": "Basic Technology",
  "generalFeedback": "Different types of lines are used in technical drawing to convey specific information about an object.",
  "answers": [
      {
          "text": "Visible outline",
          "feedback": "Incorrect. Visible outlines are drawn with thick, continuous lines."
      },
      {
          "text": "Center line",
          "feedback": "Incorrect. Center lines are drawn with long and short alternating dashes."
      },
      {
          "text": "Hidden detail",
          "feedback": "Correct. Short dashed lines are used to show edges or details that are not visible from the current view."
      },
      {
          "text": "Dimension line",
          "feedback": "Incorrect. Dimension lines are thin, continuous lines with arrowheads at the ends."
      }
  ],
  "correctAnswer": "Hidden detail"
},
{
  "id": 242,
  "question": "The process of joining two pieces of metal together using heat is called...",
  "subject": "Basic Technology",
  "generalFeedback": "Fabrication involves various techniques for joining and shaping materials. Welding is a common method for metals.",
  "answers": [
      {
          "text": "Gluing",
          "feedback": "Incorrect. Gluing is a joining method typically used for wood, paper, or plastics."
      },
      {
          "text": "Nailing",
          "feedback": "Incorrect. Nailing is a joining method used for wood."
      },
      {
          "text": "Welding",
          "feedback": "Correct. Welding is a process that uses high heat to melt and fuse metal parts together."
      },
      {
          "text": "Screwing",
          "feedback": "Incorrect. Screwing is a method of fastening materials together using screws."
      }
  ],
  "correctAnswer": "Welding"
},
{
  "id": 243,
  "question": "What is history?",
  "subject": "History",
  "generalFeedback": "History is the study of past events, particularly in human affairs. It helps us understand how the present came to be.",
  "answers": [
      {
          "text": "The study of the future",
          "feedback": "Incorrect. The study of the future is not history's primary focus, although history can help us make predictions."
      },
      {
          "text": "The study of rocks and minerals",
          "feedback": "Incorrect. This is geology."
      },
      {
          "text": "The study of past events",
          "feedback": "Correct. History is the systematic study and documentation of the past."
      },
      {
          "text": "The study of plants and animals",
          "feedback": "Incorrect. This is biology."
      }
  ],
  "correctAnswer": "The study of past events"
},
{
  "id": 244,
  "question": "An eyewitness account of an event is an example of what type of historical source?",
  "subject": "History",
  "generalFeedback": "Historians use sources to learn about the past. These sources are categorized as primary (first-hand accounts) or secondary (accounts created after the event).",
  "answers": [
      {
          "text": "A primary source",
          "feedback": "Correct. A primary source is a first-hand account or evidence from the time period, such as a diary, a letter, or an eyewitness report."
      },
      {
          "text": "A secondary source",
          "feedback": "Incorrect. A secondary source, like a textbook or an encyclopedia, interprets and analyzes primary sources."
      },
      {
          "text": "An oral source",
          "feedback": "This can be correct as it is oral, but 'primary source' is the more accurate classification for an eyewitness account."
      },
      {
          "text": "A written source",
          "feedback": "Incorrect. While it could be written down, its nature as an eyewitness account makes it primarily a 'primary' source."
      }
  ],
  "correctAnswer": "A primary source"
},
{
  "id": 245,
  "question": "The ancient civilization in Nigeria known for its terracotta sculptures was the...",
  "subject": "History",
  "generalFeedback": "Ancient Nigerian history features several influential cultures and civilizations, each known for unique contributions.",
  "answers": [
      {
          "text": "Oyo Empire",
          "feedback": "Incorrect. The Oyo Empire was known for its political structure and cavalry, not primarily terracotta sculptures."
      },
      {
          "text": "Benin Kingdom",
          "feedback": "Incorrect. The Benin Kingdom was famous for its intricate bronze and brass sculptures."
      },
      {
          "text": "Nok Culture",
          "feedback": "Correct. The Nok Culture, located in modern-day central Nigeria, is the earliest known producer of life-sized terracotta sculptures in sub-Saharan Africa."
      },
      {
          "text": "Kanem-Bornu Empire",
          "feedback": "Incorrect. The Kanem-Bornu Empire was a major power in the Lake Chad region, known for its long history and trade."
      }
  ],
  "correctAnswer": "Nok Culture"
},
{
  "id": 246,
  "question": "The amalgamation of the Northern and Southern Protectorates of Nigeria happened in what year?",
  "subject": "History",
  "generalFeedback": "The creation of modern Nigeria was a significant event in its colonial history, orchestrated by the British administration.",
  "answers": [
      {
          "text": "1960",
          "feedback": "Incorrect. 1960 was the year Nigeria gained independence from Britain."
      },
      {
          "text": "1914",
          "feedback": "Correct. Lord Frederick Lugard amalgamated the two protectorates on January 1, 1914, to form the single colony of Nigeria."
      },
      {
          "text": "1900",
          "feedback": "Incorrect. This was the year the British government took over administration from the Royal Niger Company, creating the protectorates."
      },
      {
          "text": "1954",
          "feedback": "Incorrect. 1954 was the year the Lyttelton Constitution established a federal system of government in Nigeria."
      }
  ],
  "correctAnswer": "1914"
},
{
  "id": 247,
  "question": "Which ancient Nigerian kingdom was famous for its bronze casting?",
  "subject": "History",
  "generalFeedback": "The artistic traditions of ancient Nigeria are a significant part of its history. Different kingdoms specialized in different art forms.",
  "answers": [
      {
          "text": "Nok",
          "feedback": "Incorrect. The Nok culture was famous for terracotta (baked clay) sculptures."
      },
      {
          "text": "Benin",
          "feedback": "Correct. The Kingdom of Benin was world-renowned for its highly sophisticated bronze and brass sculptures, particularly the Benin Bronzes."
      },
      {
          "text": "Ife",
          "feedback": "Incorrect. While Ife was also known for its masterful sculptures, including some in brass and copper, Benin is most famously associated with bronze casting."
      },
      {
          "text": "Oyo",
          "feedback": "Incorrect. The Oyo Empire was known more for its military and political organization."
      }
  ],
  "correctAnswer": "Benin"
},
{
  "id": 248,
  "question": "The major trade route that connected West Africa with North Africa across the desert was called the...",
  "subject": "History",
  "generalFeedback": "Trade has always been a major driver of interaction between different civilizations. This particular route was crucial for the economies of ancient West African empires.",
  "answers": [
      {
          "text": "Silk Road",
          "feedback": "Incorrect. The Silk Road connected China with the Middle East and Europe."
      },
      {
          "text": "Spice Route",
          "feedback": "Incorrect. This was a maritime route connecting Asia with Europe for the spice trade."
      },
      {
          "text": "Trans-Saharan Trade Route",
          "feedback": "Correct. This network of routes crossed the Sahara Desert and was vital for the exchange of goods like gold, salt, and slaves between West and North Africa."
      },
      {
          "text": "Atlantic Trade Route",
          "feedback": "Incorrect. This refers to the later trade across the Atlantic Ocean, including the transatlantic slave trade."
      }
  ],
  "correctAnswer": "Trans-Saharan Trade Route"
},
{
  "id": 249,
  "question": "Who was the first Governor-General of amalgamated Nigeria?",
  "subject": "History",
  "generalFeedback": "The individual who oversaw the amalgamation of the Northern and Southern protectorates also became the first leader of the newly formed colony.",
  "answers": [
      {
          "text": "Nnamdi Azikiwe",
          "feedback": "Incorrect. Nnamdi Azikiwe was the first President of Nigeria after independence."
      },
      {
          "text": "Lord Lugard",
          "feedback": "Correct. Sir Frederick Lugard, who engineered the 1914 amalgamation, served as the first Governor-General."
      },
      {
          "text": "Queen Elizabeth",
          "feedback": "Incorrect. Queen Elizabeth was the monarch of the United Kingdom but not the direct administrator of the colony."
      },
      {
          "text": "Herbert Macaulay",
          "feedback": "Incorrect. Herbert Macaulay is considered the father of Nigerian nationalism and was a key figure in the independence movement."
      }
  ],
  "correctAnswer": "Lord Lugard"
},
{
  "id": 250,
  "question": "A person who studies and writes about the past is called a...",
  "subject": "History",
  "generalFeedback": "Different academic fields have specific names for their practitioners.",
  "answers": [
      {
          "text": "Geologist",
          "feedback": "Incorrect. A geologist studies the Earth's physical structure and substance."
      },
      {
          "text": "Archaeologist",
          "feedback": "Incorrect. An archaeologist studies human history through the excavation of sites and the analysis of artifacts."
      },
      {
          "text": "Biologist",
          "feedback": "Incorrect. A biologist studies living organisms."
      },
      {
          "text": "Historian",
          "feedback": "Correct. A historian is an expert in or student of history."
      }
  ],
  "correctAnswer": "Historian"
},
{
  "id": 251,
  "question": "Which of these is NOT a farm tool?",
  "subject": "Agricultural Science",
  "generalFeedback": "Farm tools are implements used in agriculture to reduce human labour and increase efficiency. It is important to be able to identify them.",
  "answers": [
      {
          "text": "Cutlass",
          "feedback": "Incorrect. A cutlass is a basic farm tool used for clearing bush and weeding."
      },
      {
          "text": "Hoe",
          "feedback": "Incorrect. A hoe is used for tilling the soil and making ridges or heaps."
      },
      {
          "text": "Hammer",
          "feedback": "Correct. A hammer is primarily a workshop or construction tool, not a basic farm tool for cultivation."
      },
      {
          "text": "Shovel",
          "feedback": "Incorrect. A shovel is used for lifting and moving loose materials like soil or sand."
      }
  ],
  "correctAnswer": "Hammer"
},
{
  "id": 252,
  "question": "The best type of soil for growing most crops is...",
  "subject": "Agricultural Science",
  "generalFeedback": "Soils are classified based on their particle size and composition. Different soil types have different properties regarding water retention and aeration, which affect crop growth.",
  "answers": [
      {
          "text": "Sandy soil",
          "feedback": "Incorrect. Sandy soil has large particles and does not hold water well, making it poor for many crops."
      },
      {
          "text": "Clay soil",
          "feedback": "Incorrect. Clay soil has very fine particles and can become waterlogged, which is bad for plant roots."
      },
      {
          "text": "Loamy soil",
          "feedback": "Correct. Loamy soil is a mixture of sand, silt, and clay, and is considered ideal for agriculture because it has good drainage and water retention."
      },
      {
          "text": "Rocky soil",
          "feedback": "Incorrect. This soil has too many rocks and is not suitable for cultivation."
      }
  ],
  "correctAnswer": "Loamy soil"
},
{
  "id": 253,
  "question": "A place where young plants are raised before being transplanted to the main farm is called a...",
  "subject": "Agricultural Science",
  "generalFeedback": "Certain farming practices involve growing seedlings in a controlled environment before moving them to the permanent field.",
  "answers": [
      {
          "text": "Warehouse",
          "feedback": "Incorrect. A warehouse is used for storing harvested crops or farm equipment."
      },
      {
          "text": "Nursery",
          "feedback": "Correct. A nursery is a special bed or place where seedlings are raised with care until they are strong enough for transplanting."
      },
      {
          "text": "Pasture",
          "feedback": "Incorrect. A pasture is a field covered with grass where animals like cows and sheep graze."
      },
      {
          "text": "Orchard",
          "feedback": "Incorrect. An orchard is a piece of land planted with fruit trees."
      }
  ],
  "correctAnswer": "Nursery"
},
{
  "id": 254,
  "question": "Which of the following is a poultry bird?",
  "subject": "Agricultural Science",
  "generalFeedback": "Farm animals are classified based on their type. Poultry refers to domesticated birds kept by humans for their eggs, meat, or feathers.",
  "answers": [
      {
          "text": "Goat",
          "feedback": "Incorrect. A goat is a ruminant animal, not a bird."
      },
      {
          "text": "Pig",
          "feedback": "Incorrect. A pig is a mammal, not a bird."
      },
      {
          "text": "Cow",
          "feedback": "Incorrect. A cow is a bovine animal, not a bird."
      },
      {
          "text": "Chicken",
          "feedback": "Correct. Chickens, turkeys, ducks, and geese are all common examples of poultry."
      }
  ],
  "correctAnswer": "Chicken"
},
{
  "id": 255,
  "question": "The process of adding nutrients to the soil to improve its fertility is called...",
  "subject": "Agricultural Science",
  "generalFeedback": "Crops take nutrients from the soil as they grow. To maintain soil health and productivity, these nutrients must be replenished.",
  "answers": [
      {
          "text": "Irrigation",
          "feedback": "Incorrect. Irrigation is the artificial application of water to the land."
      },
      {
          "text": "Weeding",
          "feedback": "Incorrect. Weeding is the removal of unwanted plants (weeds) from the farm."
      },
      {
          "text": "Manuring/Fertilizing",
          "feedback": "Correct. This involves applying manure (organic) or fertilizer (inorganic) to provide essential nutrients for plant growth."
      },
      {
          "text": "Harvesting",
          "feedback": "Incorrect. Harvesting is the gathering of mature crops from the fields."
      }
  ],
  "correctAnswer": "Manuring/Fertilizing"
},
{
  "id": 256,
  "question": "Which of these is a root crop?",
  "subject": "Agricultural Science",
  "generalFeedback": "Crops can be classified based on the part of the plant that is harvested and eaten. Root crops store their edible food reserves in their roots.",
  "answers": [
      {
          "text": "Maize",
          "feedback": "Incorrect. Maize is a cereal crop; its seeds (grain) are eaten."
      },
      {
          "text": "Orange",
          "feedback": "Incorrect. Orange is a fruit crop."
      },
      {
          "text": "Cassava",
          "feedback": "Correct. Cassava is a tuberous root crop, where the starchy root is the main edible part."
      },
      {
          "text": "Cabbage",
          "feedback": "Incorrect. Cabbage is a leafy vegetable."
      }
  ],
  "correctAnswer": "Cassava"
},
{
  "id": 257,
  "question": "Unwanted plants growing on a farm are called...",
  "subject": "Agricultural Science",
  "generalFeedback": "Not all plants on a farm are desirable. Some compete with the main crops for resources and need to be removed.",
  "answers": [
      {
          "text": "Crops",
          "feedback": "Incorrect. Crops are the plants that the farmer intentionally cultivates."
      },
      {
          "text": "Weeds",
          "feedback": "Correct. Weeds are plants considered undesirable in a particular situation, i.e., 'a plant in the wrong place'."
      },
      {
          "text": "Flowers",
          "feedback": "Incorrect. While some flowers can be weeds, the general term is 'weeds'."
      },
      {
          "text": "Shrubs",
          "feedback": "Incorrect. Shrubs are a type of woody plant, but the term for unwanted plants is 'weeds'."
      }
  ],
  "correctAnswer": "Weeds"
},
{
  "id": 258,
  "question": "What is agriculture primarily concerned with?",
  "subject": "Agricultural Science",
  "generalFeedback": "Agriculture is a broad field that encompasses the production of essential resources for human life.",
  "answers": [
      {
          "text": "Building houses and roads",
          "feedback": "Incorrect. This is civil engineering or construction."
      },
      {
          "text": "Manufacturing cars and computers",
          "feedback": "Incorrect. This is industrial manufacturing."
      },
      {
          "text": "The cultivation of crops and rearing of animals",
          "feedback": "Correct. This is the core definition of agriculture \u2013 producing food, fiber, and other products."
      },
      {
          "text": "Mining for gold and oil",
          "feedback": "Incorrect. This is the mining or extractive industry."
      }
  ],
  "correctAnswer": "The cultivation of crops and rearing of animals"
},
{
  "id": 259,
  "question": "The basic unit of society is the...",
  "subject": "Social Studies",
  "generalFeedback": "Society is made up of different groups and institutions. The smallest and most fundamental of these is the family.",
  "answers": [
      {
          "text": "School",
          "feedback": "Incorrect. A school is an important institution for education, but it is not the basic unit of society."
      },
      {
          "text": "Community",
          "feedback": "Incorrect. A community is a group of families living together, so it is larger than the basic unit."
      },
      {
          "text": "Family",
          "feedback": "Correct. The family is universally regarded as the primary and most fundamental social unit."
      },
      {
          "text": "Government",
          "feedback": "Incorrect. The government is the system that governs a state or community."
      }
  ],
  "correctAnswer": "Family"
},
{
  "id": 260,
  "question": "Which of these is a national symbol of Nigeria?",
  "subject": "Social Studies",
  "generalFeedback": "National symbols are objects or emblems that represent a country and evoke feelings of patriotism and national pride.",
  "answers": [
      {
          "text": "An elephant",
          "feedback": "Incorrect. While the elephant is a significant animal, it is not an official national symbol on the Coat of Arms."
      },
      {
          "text": "The Coat of Arms",
          "feedback": "Correct. The Nigerian Coat of Arms, with the black shield, two white horses, and an eagle, is a major national symbol."
      },
      {
          "text": "A lion",
          "feedback": "Incorrect. The lion is not a national symbol of Nigeria."
      },
      {
          "text": "The River Niger",
          "feedback": "Incorrect. While the River Niger is a major geographical feature that gave the country its name, the Coat of Arms is the official symbol."
      }
  ],
  "correctAnswer": "The Coat of Arms"
},
{
  "id": 261,
  "question": "The way of life of a group of people is known as their...",
  "subject": "Social Studies",
  "generalFeedback": "This term encompasses the beliefs, customs, arts, and social institutions of a particular nation, people, or group.",
  "answers": [
      {
          "text": "Religion",
          "feedback": "Incorrect. Religion is an important part of culture, but culture is a broader concept."
      },
      {
          "text": "Culture",
          "feedback": "Correct. Culture is the all-encompassing term for the shared patterns of behaviors and interactions of a group of people."
      },
      {
          "text": "Government",
          "feedback": "Incorrect. Government refers to the political system of a group of people."
      },
      {
          "text": "History",
          "feedback": "Incorrect. History is the study of a people's past, which is a component of their culture."
      }
  ],
  "correctAnswer": "Culture"
},
{
  "id": 262,
  "question": "The three levels of government in Nigeria are...",
  "subject": "Social Studies",
  "generalFeedback": "Nigeria operates a federal system of government where power is shared among different tiers or levels to ensure governance reaches all citizens.",
  "answers": [
      {
          "text": "President, Governor, and King",
          "feedback": "Incorrect. These are titles of leaders, not the levels of government."
      },
      {
          "text": "Executive, Legislative, and Judiciary",
          "feedback": "Incorrect. These are the three arms of government, not the levels."
      },
      {
          "text": "Federal, State, and Local",
          "feedback": "Correct. These are the three tiers of government in Nigeria, from the national level down to the grassroots level."
      },
      {
          "text": "Village, Town, and City",
          "feedback": "Incorrect. These are types of settlements, not formal levels of government."
      }
  ],
  "correctAnswer": "Federal, State, and Local"
},
{
  "id": 263,
  "question": "Which of these is a social problem?",
  "subject": "Social Studies",
  "generalFeedback": "A social problem is an issue that affects a significant number of people within a society and is often seen as undesirable.",
  "answers": [
      {
          "text": "Celebrating a festival",
          "feedback": "Incorrect. This is a positive cultural activity, not a problem."
      },
      {
          "text": "Going to school",
          "feedback": "Incorrect. Education is a solution to many problems, not a problem itself."
      },
      {
          "text": "Corruption",
          "feedback": "Correct. Corruption is a major social problem that negatively impacts a country's development and the well-being of its citizens."
      },
      {
          "text": "Playing football",
          "feedback": "Incorrect. This is a recreational activity."
      }
  ],
  "correctAnswer": "Corruption"
},
{
  "id": 264,
  "question": "A family that consists of a father, mother, and their children is called a...",
  "subject": "Social Studies",
  "generalFeedback": "Families can be structured in different ways. The two main types are the nuclear family and the extended family.",
  "answers": [
      {
          "text": "Extended family",
          "feedback": "Incorrect. An extended family includes other relatives like grandparents, uncles, aunts, and cousins living together."
      },
      {
          "text": "Nuclear family",
          "feedback": "Correct. A nuclear family, also known as an immediate family, consists only of parents and their children."
      },
      {
          "text": "Royal family",
          "feedback": "Incorrect. A royal family is the family of a monarch."
      },
      {
          "text": "Community family",
          "feedback": "Incorrect. This is not a standard term for a family type."
      }
  ],
  "correctAnswer": "Nuclear family"
},
{
  "id": 265,
  "question": "Honesty, respect, and tolerance are examples of...",
  "subject": "Social Studies",
  "generalFeedback": "Values are the principles or standards of behavior that a society or individual holds in high regard.",
  "answers": [
      {
          "text": "Social problems",
          "feedback": "Incorrect. These are positive traits that help solve social problems."
      },
      {
          "text": "Positive values",
          "feedback": "Correct. These are desirable qualities that promote peace, harmony, and progress in society."
      },
      {
          "text": "National symbols",
          "feedback": "Incorrect. National symbols are objects like the flag or anthem, not personal qualities."
      },
      {
          "text": "Religious festivals",
          "feedback": "Incorrect. These are celebrations, not character traits."
      }
  ],
  "correctAnswer": "Positive values"
},
{
  "id": 266,
  "question": "Dumping refuse into gutters and rivers is a form of...",
  "subject": "Social Studies",
  "generalFeedback": "Our environment is the physical world around us. Certain human activities can harm the environment.",
  "answers": [
      {
          "text": "Environmental sanitation",
          "feedback": "Incorrect. Sanitation is the act of keeping the environment clean. This action does the opposite."
      },
      {
          "text": "Pollution",
          "feedback": "Correct. This is a form of water and land pollution, which contaminates the environment and can cause diseases."
      },
      {
          "text": "Recycling",
          "feedback": "Incorrect. Recycling is the process of converting waste into reusable material."
      },
      {
          "text": "Urbanization",
          "feedback": "Incorrect. Urbanization is the growth of cities, but this specific act is pollution."
      }
  ],
  "correctAnswer": "Pollution"
},
{
  "id": 267,
  "question": "What is the primary function of an office?",
  "subject": "Business Studies",
  "generalFeedback": "An office serves as the administrative center of a business or organization, handling information and communication.",
  "answers": [
      {
          "text": "To sell goods to customers",
          "feedback": "Incorrect. This is the function of a shop or sales department, which may be supported by an office."
      },
      {
          "text": "To manufacture products",
          "feedback": "Incorrect. This is the function of a factory."
      },
      {
          "text": "To receive, process, and store information",
          "feedback": "Correct. The core function of any office is to manage the flow of information necessary for the organization to operate."
      },
      {
          "text": "To store raw materials",
          "feedback": "Incorrect. This is the function of a warehouse or storeroom."
      }
  ],
  "correctAnswer": "To receive, process, and store information"
},
{
  "id": 268,
  "question": "The buying and selling of goods and services is known as...",
  "subject": "Business Studies",
  "generalFeedback": "Commerce is a major branch of business studies that deals with the exchange of goods and all activities that facilitate this exchange.",
  "answers": [
      {
          "text": "Production",
          "feedback": "Incorrect. Production is the process of making goods."
      },
      {
          "text": "Trade",
          "feedback": "Correct. Trade is the specific term for the act of buying and selling."
      },
      {
          "text": "Advertising",
          "feedback": "Incorrect. Advertising is an activity that promotes trade by informing customers about goods."
      },
      {
          "text": "Banking",
          "feedback": "Incorrect. Banking is an 'aid to trade' that provides financial services."
      }
  ],
  "correctAnswer": "Trade"
},
{
  "id": 269,
  "question": "Which of these is an 'aid to trade'?",
  "subject": "Business Studies",
  "generalFeedback": "Aids to trade are services that help overcome the hindrances in the process of buying and selling, such as distance, risk, and finance.",
  "answers": [
      {
          "text": "Farming",
          "feedback": "Incorrect. Farming is a productive activity, not a service that aids trade."
      },
      {
          "text": "Manufacturing",
          "feedback": "Incorrect. This is a form of production."
      },
      {
          "text": "Insurance",
          "feedback": "Correct. Insurance is an aid to trade that helps businesses manage risks like fire, theft, or accidents."
      },
      {
          "text": "Construction",
          "feedback": "Incorrect. This is an industry focused on building structures."
      }
  ],
  "correctAnswer": "Insurance"
},
{
  "id": 270,
  "question": "A document given to a buyer as proof of payment is called a...",
  "subject": "Business Studies",
  "generalFeedback": "In bookkeeping and commerce, various source documents are used to record transactions. Each document has a specific purpose.",
  "answers": [
      {
          "text": "Invoice",
          "feedback": "Incorrect. An invoice is a bill sent to a buyer requesting payment for goods or services supplied on credit."
      },
      {
          "text": "Receipt",
          "feedback": "Correct. A receipt is an official document that confirms that a payment has been received."
      },
      {
          "text": "Quotation",
          "feedback": "Incorrect. A quotation is a document stating the price for goods or services before a sale is made."
      },
      {
          "text": "Cheque",
          "feedback": "Incorrect. A cheque is an instruction to a bank to pay a specific amount of money from a person's account."
      }
  ],
  "correctAnswer": "Receipt"
},
{
  "id": 271,
  "question": "Trade that occurs within the borders of a country is called...",
  "subject": "Business Studies",
  "generalFeedback": "Trade can be classified based on the geographical area it covers.",
  "answers": [
      {
          "text": "Foreign trade",
          "feedback": "Incorrect. Foreign or international trade is trade between different countries."
      },
      {
          "text": "Home trade",
          "feedback": "Correct. Home trade, also known as domestic trade, is the buying and selling of goods within a single country."
      },
      {
          "text": "Wholesale trade",
          "feedback": "Incorrect. Wholesale trade is buying in bulk from producers, which can be part of either home or foreign trade."
      },
      {
          "text": "Retail trade",
          "feedback": "Incorrect. Retail trade is selling in small quantities to consumers, which can be part of either home or foreign trade."
      }
  ],
  "correctAnswer": "Home trade"
},
{
  "id": 272,
  "question": "Which office staff is typically responsible for typing letters and managing appointments?",
  "subject": "Business Studies",
  "generalFeedback": "An office is run by different staff members, each with specific duties and responsibilities.",
  "answers": [
      {
          "text": "The Manager",
          "feedback": "Incorrect. The manager is responsible for overseeing the entire office or department."
      },
      {
          "text": "The Accountant",
          "feedback": "Incorrect. The accountant deals with the financial records of the business."
      },
      {
          "text": "The Secretary/Typist",
          "feedback": "Correct. The secretary or typist is responsible for clerical and administrative duties like typing, filing, and scheduling."
      },
      {
          "text": "The Cleaner",
          "feedback": "Incorrect. The cleaner is responsible for maintaining the cleanliness of the office."
      }
  ],
  "correctAnswer": "The Secretary/Typist"
},
{
  "id": 273,
  "question": "On a computer keyboard, the longest key is the...",
  "subject": "Business Studies",
  "generalFeedback": "Keyboarding skills are a fundamental part of business studies. This involves knowing the layout and function of the keys.",
  "answers": [
      {
          "text": "Enter key",
          "feedback": "Incorrect. The Enter key is large, but not the longest."
      },
      {
          "text": "Shift key",
          "feedback": "Incorrect. There are two Shift keys, but they are not the longest key."
      },
      {
          "text": "Space bar",
          "feedback": "Correct. The space bar is the long, horizontal key at the bottom of the keyboard used to insert a space."
      },
      {
          "text": "Backspace key",
          "feedback": "Incorrect. The backspace key is smaller than the space bar."
      }
  ],
  "correctAnswer": "Space bar"
},
{
  "id": 274,
  "question": "Business Studies is a combination of Office Practice, Commerce and...",
  "subject": "Business Studies",
  "generalFeedback": "At the JSS level, Business Studies is an integrated subject that introduces students to three main areas of business.",
  "answers": [
      {
          "text": "Agriculture",
          "feedback": "Incorrect. Agriculture is a separate subject."
      },
      {
          "text": "Technology",
          "feedback": "Incorrect. Basic Technology is a separate subject."
      },
      {
          "text": "Bookkeeping",
          "feedback": "Correct. The third component is Bookkeeping, which introduces the principles of recording financial transactions."
      },
      {
          "text": "History",
          "feedback": "Incorrect. History is a separate subject."
      }
  ],
  "correctAnswer": "Bookkeeping"
},
{
  "id": 275,
  "question": "Which of these is an element of art?",
  "subject": "Cultural and Creative Arts",
  "generalFeedback": "The elements of art are the basic building blocks that artists use to create a work of art. These include line, shape, colour, texture, form, space, and value.",
  "answers": [
      {
          "text": "A brush",
          "feedback": "Incorrect. A brush is a tool used to apply paint, not an element of art itself."
      },
      {
          "text": "Colour",
          "feedback": "Correct. Colour is a fundamental element of art that has three properties: hue, value, and intensity."
      },
      {
          "text": "A canvas",
          "feedback": "Incorrect. A canvas is a surface on which an artist paints."
      },
      {
          "text": "A sculpture",
          "feedback": "Incorrect. A sculpture is a type of artwork, not an element of art."
      }
  ],
  "correctAnswer": "Colour"
},
{
  "id": 276,
  "question": "The three primary colours are...",
  "subject": "Cultural and Creative Arts",
  "generalFeedback": "In colour theory, primary colours are the base colours from which all other colours can be mixed. They cannot be created by mixing other colours.",
  "answers": [
      {
          "text": "Red, Green, and Blue",
          "feedback": "Incorrect. This is the RGB model used for light (like on screens), not for paint pigment."
      },
      {
          "text": "Red, Yellow, and Blue",
          "feedback": "Correct. These are the three traditional primary colours in art for mixing pigments."
      },
      {
          "text": "Orange, Green, and Purple",
          "feedback": "Incorrect. These are secondary colours, created by mixing two primary colours."
      },
      {
          "text": "Black, White, and Grey",
          "feedback": "Incorrect. These are considered neutral colours or values, not primary colours."
      }
  ],
  "correctAnswer": "Red, Yellow, and Blue"
},
{
  "id": 277,
  "question": "In music, the speed at which a piece is played is called the...",
  "subject": "Cultural and Creative Arts",
  "generalFeedback": "Music has several key elements that define its character. Tempo refers to the pace or speed of the music.",
  "answers": [
      {
          "text": "Rhythm",
          "feedback": "Incorrect. Rhythm refers to the pattern of sounds and silences in music."
      },
      {
          "text": "Pitch",
          "feedback": "Incorrect. Pitch refers to how high or low a note is."
      },
      {
          "text": "Dynamics",
          "feedback": "Incorrect. Dynamics refers to the loudness or softness of the music."
      },
      {
          "text": "Tempo",
          "feedback": "Correct. Tempo determines how fast or slow the music feels."
      }
  ],
  "correctAnswer": "Tempo"
},
{
  "id": 278,
  "question": "The art of making beautiful fabrics by decorating them with colourful patterns is known as...",
  "subject": "Cultural and Creative Arts",
  "generalFeedback": "Nigeria has a rich tradition of textile arts, which are a key part of its cultural heritage.",
  "answers": [
      {
          "text": "Sculpture",
          "feedback": "Incorrect. Sculpture is the art of making three-dimensional forms."
      },
      {
          "text": "Pottery",
          "feedback": "Incorrect. Pottery is the art of making objects from clay."
      },
      {
          "text": "Textile Design",
          "feedback": "Correct. Textile design includes crafts like tie-dye (Adire), weaving (Aso-Oke), and batik."
      },
      {
          "text": "Drawing",
          "feedback": "Incorrect. Drawing is the art of representing objects with lines on a surface."
      }
  ],
  "correctAnswer": "Textile Design"
},
{
  "id": 279,
  "question": "Who is a person that acts on a stage?",
  "subject": "Cultural and Creative Arts",
  "generalFeedback": "Drama and theatre involve various roles to bring a story to life for an audience.",
  "answers": [
      {
          "text": "Director",
          "feedback": "Incorrect. The director guides the actors and oversees the artistic vision of the play."
      },
      {
          "text": "Playwright",
          "feedback": "Incorrect. The playwright is the person who writes the script for the play."
      },
      {
          "text": "Actor",
          "feedback": "Correct. An actor is a person who portrays a character in a performance."
      },
      {
          "text": "Audience",
          "feedback": "Incorrect. The audience is the group of people who watch the performance."
      }
  ],
  "correctAnswer": "Actor"
},
{
  "id": 280,
  "question": "A talking drum is a traditional musical instrument from which part of the world?",
  "subject": "Cultural and Creative Arts",
  "generalFeedback": "Different cultures have unique musical instruments that are central to their traditions.",
  "answers": [
      {
          "text": "Asia",
          "feedback": "Incorrect. Asian music features instruments like the sitar and koto."
      },
      {
          "text": "Europe",
          "feedback": "Incorrect. European classical music features instruments like the violin and piano."
      },
      {
          "text": "West Africa",
          "feedback": "Correct. The talking drum is a famous hourglass-shaped drum from West Africa, particularly among the Yoruba people of Nigeria."
      },
      {
          "text": "South America",
          "feedback": "Incorrect. South American music features instruments like the panpipe and charango."
      }
  ],
  "correctAnswer": "West Africa"
},
{
  "id": 281,
  "question": "Creating a pot from clay is an example of...",
  "subject": "Cultural and Creative Arts",
  "generalFeedback": "Crafts are activities involving skill in making things by hand. Pottery is one of the oldest human crafts.",
  "answers": [
      {
          "text": "Painting",
          "feedback": "Incorrect. Painting involves applying paint to a surface."
      },
      {
          "text": "Weaving",
          "feedback": "Incorrect. Weaving involves interlacing threads to create fabric."
      },
      {
          "text": "Pottery",
          "feedback": "Correct. Pottery is the craft of making ceramic ware out of clay."
      },
      {
          "text": "Carving",
          "feedback": "Incorrect. Carving involves shaping a material like wood or stone by cutting away parts of it."
      }
  ],
  "correctAnswer": "Pottery"
},
{
  "id": 282,
  "question": "What do the lines and spaces on a musical staff represent?",
  "subject": "Cultural and Creative Arts",
  "generalFeedback": "The musical staff (or stave) is the foundation of written music, providing a framework for placing notes.",
  "answers": [
      {
          "text": "The loudness of the music",
          "feedback": "Incorrect. Loudness (dynamics) is indicated by symbols like 'p' (piano) and 'f' (forte)."
      },
      {
          "text": "The speed of the music",
          "feedback": "Incorrect. Speed (tempo) is indicated by terms like 'Adagio' or 'Allegro'."
      },
      {
          "text": "The pitch of the notes",
          "feedback": "Correct. Each line and space on the staff represents a different musical pitch. The higher the note on the staff, the higher its pitch."
      },
      {
          "text": "The instruments to be played",
          "feedback": "Incorrect. Instruments are usually written at the beginning of the staff."
      }
  ],
  "correctAnswer": "The pitch of the notes"
},
{
  "id": 283,
  "question": "According to the Bible, on which day did God create human beings?",
  "subject": "Christian Religious Studies",
  "generalFeedback": "The book of Genesis, chapter 1, gives a day-by-day account of creation.",
  "answers": [
      {
          "text": "The first day",
          "feedback": "Incorrect. On the first day, God created light."
      },
      {
          "text": "The third day",
          "feedback": "Incorrect. On the third day, God created land, sea, and vegetation."
      },
      {
          "text": "The sixth day",
          "feedback": "Correct. Genesis 1:26-31 states that God created mankind in His own image on the sixth day."
      },
      {
          "text": "The seventh day",
          "feedback": "Incorrect. On the seventh day, God rested from His work of creation."
      }
  ],
  "correctAnswer": "The sixth day"
},
{
  "id": 284,
  "question": "Who was the first man created by God?",
  "subject": "Christian Religious Studies",
  "generalFeedback": "The creation story in Genesis introduces the first human beings.",
  "answers": [
      {
          "text": "Abraham",
          "feedback": "Incorrect. Abraham was a patriarch called by God much later in the biblical narrative."
      },
      {
          "text": "Moses",
          "feedback": "Incorrect. Moses led the Israelites out of Egypt."
      },
      {
          "text": "Adam",
          "feedback": "Correct. Genesis 2 describes the creation of Adam from the dust of the ground."
      },
      {
          "text": "Noah",
          "feedback": "Incorrect. Noah was chosen by God to build an ark to survive the great flood."
      }
  ],
  "correctAnswer": "Adam"
},
{
  "id": 285,
  "question": "What was the consequence of Adam and Eve's disobedience in the Garden of Eden?",
  "subject": "Christian Religious Studies",
  "generalFeedback": "The story of the 'Fall of Man' in Genesis 3 explains how sin and its consequences entered the world.",
  "answers": [
      {
          "text": "They were given a reward",
          "feedback": "Incorrect. Their action was an act of disobedience, which led to punishment, not a reward."
      },
      {
          "text": "They were sent out of the Garden",
          "feedback": "Correct. As a consequence of their sin, they were banished from the Garden of Eden and from direct fellowship with God."
      },
      {
          "text": "They were given more fruit to eat",
          "feedback": "Incorrect. They were specifically forbidden from eating from the tree of life after their disobedience."
      },
      {
          "text": "Nothing happened to them",
          "feedback": "Incorrect. Their disobedience had profound and lasting consequences for them and all of humanity."
      }
  ],
  "correctAnswer": "They were sent out of the Garden"
},
{
  "id": 286,
  "question": "God made a covenant with Abraham, promising him that he would be...",
  "subject": "Christian Religious Studies",
  "generalFeedback": "The Abrahamic Covenant, found in Genesis, is a foundational promise in the Old Testament.",
  "answers": [
      {
          "text": "the king of Egypt.",
          "feedback": "Incorrect. This was not part of the promise to Abraham."
      },
      {
          "text": "the builder of the ark.",
          "feedback": "Incorrect. That was Noah."
      },
      {
          "text": "the father of many nations.",
          "feedback": "Correct. God promised Abraham that his descendants would be as numerous as the stars and that he would be the father of a great nation."
      },
      {
          "text": "the richest man in the world.",
          "feedback": "Incorrect. While Abraham was blessed with wealth, the core promise was about his descendants and the land."
      }
  ],
  "correctAnswer": "the father of many nations."
},
{
  "id": 287,
  "question": "Who led the Israelites out of slavery in Egypt?",
  "subject": "Christian Religious Studies",
  "generalFeedback": "The story of the Exodus is a central event in the Old Testament, detailing God's deliverance of His people.",
  "answers": [
      {
          "text": "Joseph",
          "feedback": "Incorrect. Joseph's story explains how the Israelites came to be in Egypt, but he did not lead them out."
      },
      {
          "text": "David",
          "feedback": "Incorrect. David was a king of Israel many years after the Exodus."
      },
      {
          "text": "Moses",
          "feedback": "Correct. God called Moses at the burning bush to confront Pharaoh and lead the Israelites to the Promised Land."
      },
      {
          "text": "Joshua",
          "feedback": "Incorrect. Joshua was Moses' successor and led the Israelites into the Promised Land after Moses died."
      }
  ],
  "correctAnswer": "Moses"
},
{
  "id": 288,
  "question": "The Ten Commandments were given to Moses on which mountain?",
  "subject": "Christian Religious Studies",
  "generalFeedback": "This event, described in the book of Exodus, marks the giving of God's moral law to the people of Israel.",
  "answers": [
      {
          "text": "Mount Ararat",
          "feedback": "Incorrect. Mount Ararat is where Noah's ark is said to have rested."
      },
      {
          "text": "Mount of Olives",
          "feedback": "Incorrect. The Mount of Olives is a location in Jerusalem frequently mentioned in the New Testament."
      },
      {
          "text": "Mount Sinai",
          "feedback": "Correct. Exodus 19-20 describes God descending upon Mount Sinai to give the Ten Commandments to Moses."
      },
      {
          "text": "Mount Carmel",
          "feedback": "Incorrect. Mount Carmel is where the prophet Elijah had his confrontation with the prophets of Baal."
      }
  ],
  "correctAnswer": "Mount Sinai"
},
{
  "id": 289,
  "question": "In which town was Jesus Christ born?",
  "subject": "Christian Religious Studies",
  "generalFeedback": "The New Testament Gospels of Matthew and Luke provide the narrative of Jesus' birth.",
  "answers": [
      {
          "text": "Jerusalem",
          "feedback": "Incorrect. Jerusalem was the capital city where Jesus was crucified, but not where he was born."
      },
      {
          "text": "Nazareth",
          "feedback": "Incorrect. Jesus grew up in Nazareth, which is why he was called 'Jesus of Nazareth'."
      },
      {
          "text": "Bethlehem",
          "feedback": "Correct. As prophesied, Jesus was born in Bethlehem, the city of David, because his parents went there for a census."
      },
      {
          "text": "Galilee",
          "feedback": "Incorrect. Galilee was the region where Jesus conducted much of his ministry."
      }
  ],
  "correctAnswer": "Bethlehem"
},
{
  "id": 290,
  "question": "A short story told by Jesus to teach a moral or spiritual lesson is called a...",
  "subject": "Christian Religious Studies",
  "generalFeedback": "Jesus often used storytelling as his primary method of teaching complex spiritual truths to the people.",
  "answers": [
      {
          "text": "Commandment",
          "feedback": "Incorrect. A commandment is a divine rule or order."
      },
      {
          "text": "Prophecy",
          "feedback": "Incorrect. A prophecy is a message inspired by God, often foretelling future events."
      },
      {
          "text": "Parable",
          "feedback": "Correct. Jesus told many parables, such as the Parable of the Good Samaritan and the Parable of the Prodigal Son."
      },
      {
          "text": "Psalm",
          "feedback": "Incorrect. A psalm is a sacred song or hymn, found in the book of Psalms."
      }
  ],
  "correctAnswer": "Parable"
},
{
  "id": 291,
  "question": "The 'C' in CPU stands for...",
  "subject": "ICT",
  "generalFeedback": "The CPU (Central Processing Unit) is the primary component of a computer that performs most of the processing. It is often referred to as the 'brain' of the computer.",
  "answers": [
      {
          "text": "Computer",
          "feedback": "Incorrect. While it is part of a computer, the 'C' in this specific acronym stands for 'Central'."
      },
      {
          "text": "Central",
          "feedback": "Correct. CPU stands for Central Processing Unit."
      },
      {
          "text": "Control",
          "feedback": "Incorrect. The Control Unit is a part of the CPU, but the 'C' in CPU itself stands for Central."
      },
      {
          "text": "Core",
          "feedback": "Incorrect. A 'core' is a processing unit within the CPU, but it is not what the 'C' stands for."
      }
  ],
  "correctAnswer": "Central"
},
{
  "id": 292,
  "question": "Which of these is an input device?",
  "subject": "ICT",
  "generalFeedback": "Computer hardware is categorized by its function. Input devices are used to send data and instructions into the computer.",
  "answers": [
      {
          "text": "Monitor",
          "feedback": "Incorrect. A monitor is an output device that displays information from the computer."
      },
      {
          "text": "Printer",
          "feedback": "Incorrect. A printer is an output device that produces a hard copy of documents."
      },
      {
          "text": "Mouse",
          "feedback": "Correct. A mouse is an input device used to point, click, and interact with items on the screen."
      },
      {
          "text": "Speakers",
          "feedback": "Incorrect. Speakers are output devices that produce sound."
      }
  ],
  "correctAnswer": "Mouse"
},
{
  "id": 293,
  "question": "The physical parts of a computer that you can touch and see are called...",
  "subject": "ICT",
  "generalFeedback": "A computer system is made of two main components: hardware (the physical parts) and software (the programs and instructions).",
  "answers": [
      {
          "text": "Software",
          "feedback": "Incorrect. Software is the set of instructions that tells the hardware what to do. You cannot physically touch it."
      },
      {
          "text": "Hardware",
          "feedback": "Correct. Hardware includes all the tangible components like the keyboard, monitor, mouse, and system unit."
      },
      {
          "text": "Firmware",
          "feedback": "Incorrect. Firmware is a specific type of software that is embedded in a piece of hardware."
      },
      {
          "text": "Peopleware",
          "feedback": "Incorrect. Peopleware refers to the users of the computer."
      }
  ],
  "correctAnswer": "Hardware"
},
{
  "id": 294,
  "question": "Microsoft Windows is an example of...",
  "subject": "ICT",
  "generalFeedback": "Software is broadly divided into two categories: system software, which manages the computer itself, and application software, which performs specific tasks for the user.",
  "answers": [
      {
          "text": "Application Software",
          "feedback": "Incorrect. Application software includes programs like MS Word or a web browser. Windows is the platform they run on."
      },
      {
          "text": "An Input Device",
          "feedback": "Incorrect. Windows is software, not a physical device."
      },
      {
          "text": "System Software (Operating System)",
          "feedback": "Correct. Microsoft Windows is an operating system, which is the main type of system software that manages all other programs and hardware."
      },
      {
          "text": "A Web Browser",
          "feedback": "Incorrect. A web browser (like Chrome or Edge) is an application used to access the internet."
      }
  ],
  "correctAnswer": "System Software (Operating System)"
},
{
  "id": 295,
  "question": "What is the global network of connected computers called?",
  "subject": "ICT",
  "generalFeedback": "This vast network allows users to share information and communicate with each other from anywhere in the world.",
  "answers": [
      {
          "text": "The CPU",
          "feedback": "Incorrect. The CPU is the processor inside a single computer."
      },
      {
          "text": "The Internet",
          "feedback": "Correct. The Internet is the worldwide network that connects millions of computers, enabling communication and data exchange."
      },
      {
          "text": "The World Wide Web (WWW)",
          "feedback": "Incorrect. The WWW is a system of interlinked documents and web pages that is accessed *via* the Internet. The Internet is the network itself."
      },
      {
          "text": "A Local Area Network (LAN)",
          "feedback": "Incorrect. A LAN is a small, localized network, for example, within a school or an office."
      }
  ],
  "correctAnswer": "The Internet"
},
{
  "id": 296,
  "question": "Which of these is a good practice for online safety?",
  "subject": "ICT",
  "generalFeedback": "Using the internet comes with risks. It is crucial to follow safety rules to protect your personal information and well-being.",
  "answers": [
      {
          "text": "Sharing your password with your friends",
          "feedback": "Incorrect. Passwords should be kept secret to prevent others from accessing your accounts."
      },
      {
          "text": "Meeting with strangers you meet online",
          "feedback": "Incorrect. This is extremely dangerous and should never be done without a trusted adult's permission and supervision."
      },
      {
          "text": "Keeping your personal information private",
          "feedback": "Correct. You should not share private details like your full name, address, phone number, or school name with people you don't know online."
      },
      {
          "text": "Clicking on all links and pop-ups",
          "feedback": "Incorrect. Many links and pop-ups can lead to viruses or scams."
      }
  ],
  "correctAnswer": "Keeping your personal information private"
},
{
  "id": 297,
  "question": "Which software is primarily used for typing documents like letters and essays?",
  "subject": "ICT",
  "generalFeedback": "Different types of application software are designed for specific tasks.",
  "answers": [
      {
          "text": "Spreadsheet software (e.g., MS Excel)",
          "feedback": "Incorrect. Spreadsheet software is used for calculations and organizing data in tables."
      },
      {
          "text": "Presentation software (e.g., MS PowerPoint)",
          "feedback": "Incorrect. Presentation software is used to create slides for a presentation."
      },
      {
          "text": "Word processing software (e.g., MS Word)",
          "feedback": "Correct. Word processors are designed for creating, editing, and formatting text-based documents."
      },
      {
          "text": "A web browser (e.g., Google Chrome)",
          "feedback": "Incorrect. A web browser is used to access websites on the internet."
      }
  ],
  "correctAnswer": "Word processing software (e.g., MS Word)"
},
{
  "id": 298,
  "question": "To correctly shut down a Windows computer, you should...",
  "subject": "ICT",
  "generalFeedback": "Properly shutting down a computer ensures that all your files are saved and the system closes down correctly, which prevents data loss or corruption.",
  "answers": [
      {
          "text": "Turn off the power button on the wall socket",
          "feedback": "Incorrect. This is an improper shutdown and can damage your files or the computer's operating system."
      },
      {
          "text": "Press and hold the power button on the system unit",
          "feedback": "Incorrect. This is a forced shutdown and should only be used if the computer is frozen."
      },
      {
          "text": "Click the Start Menu, then select Power, and then Shut Down",
          "feedback": "Correct. This is the standard, safe procedure for shutting down a Windows computer."
      },
      {
          "text": "Just close the monitor",
          "feedback": "Incorrect. This only turns off the screen; the computer itself is still running."
      }
  ],
  "correctAnswer": "Click the Start Menu, then select Power, and then Shut Down"
},
{
  "id": 299,
  "question": "Kedu maka \u1ee5t\u1ee5t\u1ee5 a? is an Igbo greeting that means...",
  "subject": "Igbo",
  "generalFeedback": "Greetings are a fundamental part of communication in any language. Different greetings are used for different times of the day.",
  "answers": [
      {
          "text": "Good evening?",
          "feedback": "Incorrect. The greeting for evening is 'Mgbede \u1ecdma' or 'Daal\u1ee5 maka mgbede a'."
      },
      {
          "text": "How are you this morning?",
          "feedback": "Correct. 'Kedu maka \u1ee5t\u1ee5t\u1ee5 a?' is a way of asking how someone is doing in the morning."
      },
      {
          "text": "Welcome",
          "feedback": "Incorrect. The word for welcome is 'Nn\u1ecd\u1ecd'."
      },
      {
          "text": "Goodbye",
          "feedback": "Incorrect. Goodbye can be 'Ka \u1ecdmes\u1ecba' or 'Gaa nke \u1ecdma'."
      }
  ],
  "correctAnswer": "How are you this morning?"
},
{
  "id": 300,
  "question": "How many letters are in the standard Igbo alphabet (Mkp\u1ee5r\u1ee5 Edemede Igbo)?",
  "subject": "Igbo",
  "generalFeedback": "The Igbo alphabet has a specific number of letters, including some that are not in the English alphabet and excluding some that are.",
  "answers": [
      {
          "text": "26",
          "feedback": "Incorrect. This is the number of letters in the English alphabet."
      },
      {
          "text": "36",
          "feedback": "Correct. The modern Igbo alphabet has 36 letters."
      },
      {
          "text": "30",
          "feedback": "Incorrect. This is a common guess but not the correct number."
      },
      {
          "text": "28",
          "feedback": "Incorrect. This is not the correct number of letters."
      }
  ],
  "correctAnswer": "36"
},
{
  "id": 301,
  "question": "What is the Igbo word for 'father'?",
  "subject": "Igbo",
  "generalFeedback": "Knowing the terms for family members is a basic part of learning any language.",
  "answers": [
      {
          "text": "Nne",
          "feedback": "Incorrect. 'Nne' means mother."
      },
      {
          "text": "Nna",
          "feedback": "Correct. 'Nna' is the Igbo word for father."
      },
      {
          "text": "Nwanne",
          "feedback": "Incorrect. 'Nwanne' means sibling (brother or sister)."
      },
      {
          "text": "Nwa",
          "feedback": "Incorrect. 'Nwa' means child."
      }
  ],
  "correctAnswer": "Nna"
},
{
  "id": 302,
  "question": "The number 5 in Igbo is...",
  "subject": "Igbo",
  "generalFeedback": "Counting is a foundational skill when learning a new language.",
  "answers": [
      {
          "text": "At\u1ecd",
          "feedback": "Incorrect. 'At\u1ecd' is three."
      },
      {
          "text": "An\u1ecd",
          "feedback": "Incorrect. 'An\u1ecd' is four."
      },
      {
          "text": "Ise",
          "feedback": "Correct. The number five in Igbo is 'Ise'."
      },
      {
          "text": "Isii",
          "feedback": "Incorrect. 'Isii' is six."
      }
  ],
  "correctAnswer": "Ise"
},
{
  "id": 303,
  "question": "The care of the body, including bathing, brushing teeth, and wearing clean clothes is called...",
  "subject": "Home Economics",
  "generalFeedback": "Home Economics teaches essential life skills, and maintaining good hygiene is crucial for health and well-being.",
  "answers": [
      {
          "text": "Nutrition",
          "feedback": "Incorrect. Nutrition is about the food we eat."
      },
      {
          "text": "Personal Hygiene",
          "feedback": "Correct. This is the term for all the practices performed to care for one's bodily health and well-being through cleanliness."
      },
      {
          "text": "Home Management",
          "feedback": "Incorrect. Home management is a broader term that includes cleaning the house, budgeting, etc."
      },
      {
          "text": "Cooking",
          "feedback": "Incorrect. Cooking is the art of preparing food."
      }
  ],
  "correctAnswer": "Personal Hygiene"
},
{
  "id": 304,
  "question": "Which of these foods is a major source of protein?",
  "subject": "Home Economics",
  "generalFeedback": "Foods are grouped into different classes based on the primary nutrients they provide. Protein is essential for building and repairing body tissues.",
  "answers": [
      {
          "text": "Rice",
          "feedback": "Incorrect. Rice is a major source of carbohydrates, which provide energy."
      },
      {
          "text": "Orange",
          "feedback": "Incorrect. Oranges are a source of vitamins, particularly Vitamin C."
      },
      {
          "text": "Beans",
          "feedback": "Correct. Beans, meat, fish, and eggs are all excellent sources of protein."
      },
      {
          "text": "Palm oil",
          "feedback": "Incorrect. Palm oil is a source of fats and oils."
      }
  ],
  "correctAnswer": "Beans"
},
{
  "id": 305,
  "question": "Why is it important to wash your hands before eating?",
  "subject": "Home Economics",
  "generalFeedback": "Kitchen and food hygiene practices are vital to prevent the spread of diseases.",
  "answers": [
      {
          "text": "To make the food taste better",
          "feedback": "Incorrect. Washing hands does not affect the taste of food."
      },
      {
          "text": "To cool your hands down",
          "feedback": "Incorrect. While water may cool your hands, this is not the primary reason for washing them."
      },
      {
          "text": "To remove germs and prevent illness",
          "feedback": "Correct. Our hands pick up germs from various surfaces, and washing them removes these germs so they don't enter our bodies with the food."
      },
      {
          "text": "Because it is a family tradition",
          "feedback": "Incorrect. While it might be a tradition, the underlying reason is health and hygiene."
      }
  ],
  "correctAnswer": "To remove germs and prevent illness"
},
{
  "id": 306,
  "question": "A simple stitch used for temporarily joining fabric together before final sewing is called...",
  "subject": "Home Economics",
  "generalFeedback": "Basic sewing involves learning different types of stitches, each with a specific purpose.",
  "answers": [
      {
          "text": "Running stitch",
          "feedback": "Incorrect. A running stitch is a basic permanent stitch."
      },
      {
          "text": "Back stitch",
          "feedback": "Incorrect. A back stitch is a strong, permanent stitch."
      },
      {
          "text": "Tacking stitch",
          "feedback": "Correct. Tacking stitches (or basting stitches) are large, temporary stitches that are removed after the final sewing is complete."
      },
      {
          "text": "Hemming stitch",
          "feedback": "Incorrect. A hemming stitch is used to finish the edge of a garment."
      }
  ],
  "correctAnswer": "Tacking stitch"
},
{
  "id": 307,
  "question": "The French word for 'hello' or 'good morning' is...",
  "subject": "French",
  "generalFeedback": "Learning basic greetings is the first step in communicating in any new language.",
  "answers": [
      {
          "text": "Au revoir",
          "feedback": "Incorrect. 'Au revoir' means goodbye."
      },
      {
          "text": "Merci",
          "feedback": "Incorrect. 'Merci' means thank you."
      },
      {
          "text": "Bonjour",
          "feedback": "Correct. 'Bonjour' is the standard greeting used during the day in French."
      },
      {
          "text": "Oui",
          "feedback": "Incorrect. 'Oui' means yes."
      }
  ],
  "correctAnswer": "Bonjour"
},
{
  "id": 308,
  "question": "How do you say 'My name is...' in French?",
  "subject": "French",
  "generalFeedback": "Introducing yourself is a key conversational skill.",
  "answers": [
      {
          "text": "Comment t'appelles-tu?",
          "feedback": "Incorrect. This means 'What is your name?'."
      },
      {
          "text": "Je suis...",
          "feedback": "Incorrect. This means 'I am...' and can be used, but 'Je m'appelle' is more specific for introducing your name."
      },
      {
          "text": "Je m'appelle...",
          "feedback": "Correct. This literally means 'I call myself...' and is the standard way to state your name."
      },
      {
          "text": "J'ai un nom...",
          "feedback": "Incorrect. This means 'I have a name...' which is not the correct phrasing."
      }
  ],
  "correctAnswer": "Je m'appelle..."
},
{
  "id": 309,
  "question": "The number 3 in French is...",
  "subject": "French",
  "generalFeedback": "Learning to count is a basic building block for learning French.",
  "answers": [
      {
          "text": "Un",
          "feedback": "Incorrect. 'Un' is one."
      },
      {
          "text": "Deux",
          "feedback": "Incorrect. 'Deux' is two."
      },
      {
          "text": "Trois",
          "feedback": "Correct. The numbers one, two, three are 'un, deux, trois'."
      },
      {
          "text": "Quatre",
          "feedback": "Incorrect. 'Quatre' is four."
      }
  ],
  "correctAnswer": "Trois"
},
{
  "id": 310,
  "question": "What is the French word for 'Monday'?",
  "subject": "French",
  "generalFeedback": "Knowing the days of the week is essential for talking about schedules and daily activities.",
  "answers": [
      {
          "text": "Mardi",
          "feedback": "Incorrect. 'Mardi' is Tuesday."
      },
      {
          "text": "Dimanche",
          "feedback": "Incorrect. 'Dimanche' is Sunday."
      },
      {
          "text": "Mercredi",
          "feedback": "Incorrect. 'Mercredi' is Wednesday."
      },
      {
          "text": "Lundi",
          "feedback": "Correct. 'Lundi' is the French word for Monday."
      }
  ],
  "correctAnswer": "Lundi"
},
{
  "id": 311,
  "question": "The two main parts of a plant are the root system and the...",
  "subject": "Basic Science",
  "generalFeedback": "Plants have a distinct structure that can be divided into the part below the ground and the part above the ground.",
  "answers": [
      {
          "text": "flower system.",
          "feedback": "Incorrect. Flowers are part of the shoot system, but not the whole system itself."
      },
      {
          "text": "leaf system.",
          "feedback": "Incorrect. Leaves are a crucial part of the shoot system, responsible for photosynthesis."
      },
      {
          "text": "shoot system.",
          "feedback": "Correct. The shoot system is the part of the plant above the ground, which includes the stem, leaves, and flowers."
      },
      {
          "text": "stem system.",
          "feedback": "Incorrect. The stem is the main axis of the shoot system."
      }
  ],
  "correctAnswer": "shoot system."
},
{
  "id": 312,
  "question": "A ruler is used in technical drawing primarily for...",
  "subject": "Basic Technology",
  "generalFeedback": "Each technical drawing instrument has a specific function to ensure accuracy and precision in drawings.",
  "answers": [
      {
          "text": "Drawing circles and arcs",
          "feedback": "Incorrect. This is the function of a pair of compasses."
      },
      {
          "text": "Measuring angles",
          "feedback": "Incorrect. This is the function of a protractor."
      },
      {
          "text": "Measuring lengths and drawing straight lines",
          "feedback": "Correct. A ruler is a fundamental tool for creating straight lines and measuring their dimensions accurately."
      },
      {
          "text": "Drawing horizontal lines on a board",
          "feedback": "Incorrect. This is the main function of a T-Square."
      }
  ],
  "correctAnswer": "Measuring lengths and drawing straight lines"
},
{
  "id": 313,
  "question": "The main colours on the Nigerian flag are...",
  "subject": "Social Studies",
  "generalFeedback": "The national flag is a primary symbol of a country's identity and values. Each color has a specific meaning.",
  "answers": [
      {
          "text": "Green, White, and Green",
          "feedback": "Correct. The Nigerian flag has two green stripes on the sides and a white stripe in the middle."
      },
      {
          "text": "Red, White, and Blue",
          "feedback": "Incorrect. These are the colors of flags for countries like the USA, UK, and France."
      },
      {
          "text": "Green, Yellow, and Red",
          "feedback": "Incorrect. These are common pan-African colors found on flags like Ghana's and Ethiopia's."
      },
      {
          "text": "Black, Green, and White",
          "feedback": "Incorrect. The flag does not contain black."
      }
  ],
  "correctAnswer": "Green, White, and Green"
},
{
  "id": 314,
  "question": "In the sentence 'The big dog barked loudly,' the word 'big' is a/an...",
  "subject": "English Language",
  "generalFeedback": "An adjective is a word that describes or modifies a noun or pronoun, providing more information about it.",
  "answers": [
      {
          "text": "Noun",
          "feedback": "Incorrect. The noun in this sentence is 'dog'."
      },
      {
          "text": "Verb",
          "feedback": "Incorrect. The verb is 'barked,' which shows the action."
      },
      {
          "text": "Adjective",
          "feedback": "Correct. 'Big' describes the noun 'dog'."
      },
      {
          "text": "Adverb",
          "feedback": "Incorrect. The adverb is 'loudly,' which describes the verb 'barked'."
      }
  ],
  "correctAnswer": "Adjective"
},
{
  "id": 315,
  "question": "Convert the number 1101\u2082 to base 10.",
  "subject": "Mathematics",
  "generalFeedback": "To convert a number from base 2 (binary) to base 10 (decimal), you multiply each digit by 2 raised to the power of its position, starting from 0 on the right. For 1101\u2082, it is (1 * 2\u00b3) + (1 * 2\u00b2) + (0 * 2\u00b9) + (1 * 2\u2070).",
  "answers": [
      {
          "text": "13",
          "feedback": "Correct. (1 * 8) + (1 * 4) + (0 * 2) + (1 * 1) = 8 + 4 + 0 + 1 = 13."
      },
      {
          "text": "11",
          "feedback": "Incorrect. This might be from incorrectly calculating the powers of 2, for example, (1*8) + (1*2) + (0*1) + (1*0)."
      },
      {
          "text": "27",
          "feedback": "Incorrect. You might have read the number from right to left or used the wrong base for conversion."
      },
      {
          "text": "6",
          "feedback": "Incorrect. This is the sum of the digits (1+1+0+1), not the value in base 10."
      }
  ],
  "correctAnswer": "13"
},
{
  "id": 316,
  "subject": "Mathematics",
  "question": "What is the value of 15 + 5 \u00d7 3?",
  "generalFeedback": "This question tests the order of operations, often remembered by the acronym BODMAS or PEMDAS. Multiplication and Division are performed before Addition and Subtraction.",
  "answers": [
      {
          "text": "30",
          "feedback": "Correct. You correctly performed multiplication (5 \u00d7 3 = 15) before addition (15 + 15 = 30)."
      },
      {
          "text": "60",
          "feedback": "Incorrect. This result comes from adding 15 and 5 first (15 + 5 = 20) and then multiplying by 3. Remember to multiply before you add."
      },
      {
          "text": "45",
          "feedback": "Incorrect. This might be from multiplying 15 by 3. The multiplication applies only to the number immediately next to it."
      },
      {
          "text": "23",
          "feedback": "Incorrect. Please re-check your calculations for both multiplication and addition."
      }
  ],
  "correctAnswer": "30"
},
{
  "id": 317,
  "subject": "Mathematics",
  "question": "If a triangle has two equal sides, what is it called?",
  "generalFeedback": "Triangles are classified based on the lengths of their sides. A triangle with three equal sides is equilateral, two equal sides is isosceles, and no equal sides is scalene.",
  "answers": [
      {
          "text": "Isosceles triangle",
          "feedback": "Correct. An isosceles triangle is defined as having at least two sides of equal length."
      },
      {
          "text": "Equilateral triangle",
          "feedback": "Incorrect. An equilateral triangle has all three sides equal."
      },
      {
          "text": "Scalene triangle",
          "feedback": "Incorrect. A scalene triangle has no sides of equal length."
      },
      {
          "text": "Right-angled triangle",
          "feedback": "Incorrect. A right-angled triangle is defined by its angles (one is 90\u00b0), not the length of its sides."
      }
  ],
  "correctAnswer": "Isosceles triangle"
},
{
  "id": 318,
  "subject": "Mathematics",
  "question": "Convert the number 1101\u2082 to base 10.",
  "generalFeedback": "To convert a number from base 2 (binary) to base 10 (decimal), you multiply each digit by 2 raised to the power of its position, starting from 0 on the right. For 1101\u2082, it is (1 * 2\u00b3) + (1 * 2\u00b2) + (0 * 2\u00b9) + (1 * 2\u2070).",
  "answers": [
      {
          "text": "13",
          "feedback": "Correct. (1 * 8) + (1 * 4) + (0 * 2) + (1 * 1) = 8 + 4 + 0 + 1 = 13."
      },
      {
          "text": "11",
          "feedback": "Incorrect. This might be from incorrectly calculating the powers of 2, for example, (1*8) + (1*2) + (0*1) + (1*0)."
      },
      {
          "text": "27",
          "feedback": "Incorrect. You might have read the number from right to left or used the wrong base for conversion."
      },
      {
          "text": "6",
          "feedback": "Incorrect. This is the sum of the digits (1+1+0+1), not the value in base 10."
      }
  ],
  "correctAnswer": "13"
},
{
  "id": 319,
  "subject": "Mathematics",
  "question": "What is the perimeter of a rectangle with length 10cm and width 5cm?",
  "generalFeedback": "The perimeter of a shape is the total distance around its edge. For a rectangle, the formula is P = 2 \u00d7 (length + width).",
  "answers": [
      {
          "text": "30cm",
          "feedback": "Correct. P = 2 \u00d7 (10cm + 5cm) = 2 \u00d7 15cm = 30cm."
      },
      {
          "text": "15cm",
          "feedback": "Incorrect. This is the sum of only one length and one width. A rectangle has four sides."
      },
      {
          "text": "50cm\u00b2",
          "feedback": "Incorrect. This is the area of the rectangle (length \u00d7 width), not the perimeter. Note the units are also cm\u00b2, not cm."
      },
      {
          "text": "25cm",
          "feedback": "Incorrect. This might be from adding the length twice (10+10+5) but forgetting the second width."
      }
  ],
  "correctAnswer": "30cm"
},
{
  "id": 320,
  "subject": "Mathematics",
  "question": "Find the average (mean) of the numbers: 4, 6, 8.",
  "generalFeedback": "To find the mean or average of a set of numbers, you add all the numbers together and then divide by the count of the numbers.",
  "answers": [
      {
          "text": "6",
          "feedback": "Correct. The sum is 4 + 6 + 8 = 18. There are 3 numbers. 18 \u00f7 3 = 6."
      },
      {
          "text": "18",
          "feedback": "Incorrect. This is the sum of the numbers, but you forgot to divide by the count of numbers (3)."
      },
      {
          "text": "8",
          "feedback": "Incorrect. This is the highest number in the set, not the average."
      },
      {
          "text": "5",
          "feedback": "Incorrect. Please re-check your addition and division."
      }
  ],
  "correctAnswer": "6"
},
{
  "id": 321,
  "subject": "Mathematics",
  "question": "If x + 7 = 15, what is the value of x?",
  "generalFeedback": "This is a simple algebraic equation. To find the value of x, you need to isolate it on one side of the equation. You can do this by subtracting 7 from both sides.",
  "answers": [
      {
          "text": "8",
          "feedback": "Correct. 15 - 7 = 8. So, x = 8."
      },
      {
          "text": "22",
          "feedback": "Incorrect. It seems you added 7 to 15 instead of subtracting. To move a positive number to the other side of the equation, you subtract it."
      },
      {
          "text": "15",
          "feedback": "Incorrect. x cannot be 15, because 15 + 7 is not 15."
      },
      {
          "text": "7",
          "feedback": "Incorrect. You need to find the number that, when added to 7, gives 15."
      }
  ],
  "correctAnswer": "8"
},
{
  "id": 322,
  "subject": "Mathematics",
  "question": "Which of these fractions is the largest: 1/2, 1/3, 1/4?",
  "generalFeedback": "When comparing fractions with the same numerator (the top number), the fraction with the smallest denominator (the bottom number) is the largest. Think of a pizza: cutting it into 2 pieces gives you larger slices than cutting it into 4 pieces.",
  "answers": [
      {
          "text": "1/2",
          "feedback": "Correct. Dividing something into 2 parts results in larger parts than dividing it into 3 or 4 parts."
      },
      {
          "text": "1/3",
          "feedback": "Incorrect. 1/3 is smaller than 1/2 but larger than 1/4."
      },
      {
          "text": "1/4",
          "feedback": "Incorrect. This is the smallest fraction among the options because the whole is divided into the most parts."
      },
      {
          "text": "They are all equal",
          "feedback": "Incorrect. The fractions represent different portions of a whole."
      }
  ],
  "correctAnswer": "1/2"
},
{
  "id": 323,
  "subject": "English Language",
  "question": "In the sentence 'The cat sat on the mat', which word is a noun?",
  "generalFeedback": "A noun is a word that represents a person, place, thing, or idea. Sentences can have more than one noun.",
  "answers": [
      {
          "text": "Cat",
          "feedback": "Correct. 'Cat' is a noun because it is a thing (an animal). 'Mat' is also a noun in this sentence."
      },
      {
          "text": "Sat",
          "feedback": "Incorrect. 'Sat' is a verb, which is an action word."
      },
      {
          "text": "The",
          "feedback": "Incorrect. 'The' is an article, which specifies a noun."
      },
      {
          "text": "On",
          "feedback": "Incorrect. 'On' is a preposition, which shows the relationship between nouns."
      }
  ],
  "correctAnswer": "Cat"
},
{
  "id": 324,
  "subject": "English Language",
  "question": "Choose the correct spelling.",
  "generalFeedback": "Spelling is a key part of written English. Look closely at the arrangement of letters, especially vowels, in each option.",
  "answers": [
      {
          "text": "Necessary",
          "feedback": "Correct. This is the correct spelling. Remember: one 'c', double 's'."
      },
      {
          "text": "Neccessary",
          "feedback": "Incorrect. This spelling has a double 'c', which is wrong."
      },
      {
          "text": "Necesary",
          "feedback": "Incorrect. This spelling is missing the second 's'."
      },
      {
          "text": "Neccesary",
          "feedback": "Incorrect. This spelling has both a double 'c' and only one 's'."
      }
  ],
  "correctAnswer": "Necessary"
},
{
  "id": 325,
  "subject": "English Language",
  "question": "Which of the following is an example of a simile?",
  "generalFeedback": "A simile is a figure of speech that directly compares two different things, usually using the words 'like' or 'as'.",
  "answers": [
      {
          "text": "He is as brave as a lion.",
          "feedback": "Correct. This sentence uses 'as' to compare the man's bravery to that of a lion."
      },
      {
          "text": "He is a lion.",
          "feedback": "Incorrect. This is a metaphor. It makes a direct comparison without using 'like' or 'as'."
      },
      {
          "text": "The lion roared.",
          "feedback": "Incorrect. This is a simple statement of fact, not a figure of speech."
      },
      {
          "text": "The wind whispered through the trees.",
          "feedback": "Incorrect. This is personification, giving a human quality (whispering) to an inanimate thing (the wind)."
      }
  ],
  "correctAnswer": "He is as brave as a lion."
},
{
  "id": 326,
  "subject": "English Language",
  "question": "What is the past tense of the verb 'go'?",
  "generalFeedback": "The past tense of a verb indicates an action that happened in the past. 'Go' is an irregular verb, meaning its past tense form doesn't follow the typical '-ed' rule.",
  "answers": [
      {
          "text": "Went",
          "feedback": "Correct. 'Went' is the simple past tense of 'go'."
      },
      {
          "text": "Gone",
          "feedback": "Incorrect. 'Gone' is the past participle, used with auxiliary verbs like 'has', 'have', or 'had' (e.g., 'He has gone')."
      },
      {
          "text": "Goed",
          "feedback": "Incorrect. 'Go' is an irregular verb and does not form its past tense by adding '-ed'."
      },
      {
          "text": "Going",
          "feedback": "Incorrect. 'Going' is the present participle, used to show continuous action (e.g., 'He is going')."
      }
  ],
  "correctAnswer": "Went"
},
{
  "id": 327,
  "subject": "English Language",
  "question": "A person who writes books is called an _______.",
  "generalFeedback": "This question tests your vocabulary for professions. The word needed is someone who is the originator or creator of a written work.",
  "answers": [
      {
          "text": "Author",
          "feedback": "Correct. An author is a writer of a book, article, or report."
      },
      {
          "text": "Editor",
          "feedback": "Incorrect. An editor prepares written material for publication by correcting, condensing, or otherwise modifying it."
      },
      {
          "text": "Publisher",
          "feedback": "Incorrect. A publisher is a person or company that prepares and issues books, journals, or music for sale."
      },
      {
          "text": "Librarian",
          "feedback": "Incorrect. A librarian is a person who works professionally in a library."
      }
  ],
  "correctAnswer": "Author"
},
{
  "id": 328,
  "subject": "English Language",
  "question": "Which punctuation mark is used to end a question?",
  "generalFeedback": "Punctuation marks are symbols that help readers understand the structure and meaning of a sentence. Different marks have different functions.",
  "answers": [
      {
          "text": "Question Mark (?)",
          "feedback": "Correct. A question mark is placed at the end of an interrogative sentence (a sentence that asks a question)."
      },
      {
          "text": "Full Stop (.)",
          "feedback": "Incorrect. A full stop is used to end a declarative or imperative sentence (a statement or command)."
      },
      {
          "text": "Comma (,)",
          "feedback": "Incorrect. A comma is used to indicate a pause in a sentence or to separate items in a list."
      },
      {
          "text": "Exclamation Mark (!)",
          "feedback": "Incorrect. An exclamation mark is used to indicate strong feelings or a high volume (shouting)."
      }
  ],
  "correctAnswer": "Question Mark (?)"
},
{
  "id": 329,
  "subject": "Basic Science",
  "question": "Which of the following is NOT a characteristic of living things?",
  "generalFeedback": "Living things share several key characteristics, often remembered by the acronym MR NIGER D: Movement, Respiration, Nutrition, Irritability (Sensitivity), Growth, Excretion, Reproduction, and Death.",
  "answers": [
      {
          "text": "Melting",
          "feedback": "Correct. Melting is a physical change in the state of matter (from solid to liquid), not a characteristic of life."
      },
      {
          "text": "Growth",
          "feedback": "Incorrect. Growth, an increase in size and complexity, is a fundamental characteristic of all living things."
      },
      {
          "text": "Respiration",
          "feedback": "Incorrect. Respiration is the process of releasing energy from food, which is essential for all living organisms."
      },
      {
          "text": "Excretion",
          "feedback": "Incorrect. Excretion is the removal of waste products from the body, a vital process for life."
      }
  ],
  "correctAnswer": "Melting"
},
{
  "id": 330,
  "subject": "Basic Science",
  "question": "What is the process by which plants make their own food using sunlight?",
  "generalFeedback": "This is a fundamental biological process. Plants are producers, meaning they create their own food. The name of the process comes from Greek words: 'photo' (light) and 'synthesis' (to make).",
  "answers": [
      {
          "text": "Photosynthesis",
          "feedback": "Correct. Photosynthesis is the process where green plants use sunlight, water, and carbon dioxide to create their food (glucose) and release oxygen."
      },
      {
          "text": "Respiration",
          "feedback": "Incorrect. Respiration is the process of breaking down food to release energy, which happens in both plants and animals."
      },
      {
          "text": "Transpiration",
          "feedback": "Incorrect. Transpiration is the process where plants absorb water through the roots and then give off water vapor through pores in their leaves."
      },
      {
          "text": "Germination",
          "feedback": "Incorrect. Germination is the process by which a seed sprouts and begins to grow into a plant."
      }
  ],
  "correctAnswer": "Photosynthesis"
},
{
  "id": 331,
  "subject": "Basic Science",
  "question": "Which of these is a liquid at room temperature?",
  "generalFeedback": "Matter exists in three main states: solid, liquid, and gas. The state of a substance depends on its temperature and pressure. Room temperature is typically around 20-25\u00b0C.",
  "answers": [
      {
          "text": "Water",
          "feedback": "Correct. Water's freezing point is 0\u00b0C and boiling point is 100\u00b0C, so it is a liquid at room temperature."
      },
      {
          "text": "Ice",
          "feedback": "Incorrect. Ice is the solid form of water, existing at or below 0\u00b0C."
      },
      {
          "text": "Wood",
          "feedback": "Incorrect. Wood is a solid at room temperature."
      },
      {
          "text": "Oxygen",
          "feedback": "Incorrect. Oxygen is a gas at room temperature."
      }
  ],
  "correctAnswer": "Water"
},
{
  "id": 332,
  "subject": "Basic Science",
  "question": "The force that pulls objects towards the center of the Earth is called ______.",
  "generalFeedback": "This is a fundamental force of nature that affects everything with mass. It's the reason why things fall down when you drop them.",
  "answers": [
      {
          "text": "Gravity",
          "feedback": "Correct. Gravity is the force of attraction between all masses in the universe."
      },
      {
          "text": "Friction",
          "feedback": "Incorrect. Friction is a force that opposes motion between two surfaces that are in contact."
      },
      {
          "text": "Magnetism",
          "feedback": "Incorrect. Magnetism is a force exerted by magnets on other magnets or magnetic materials."
      },
      {
          "text": "Tension",
          "feedback": "Incorrect. Tension is the pulling force transmitted axially by means of a string, cable, or chain."
      }
  ],
  "correctAnswer": "Gravity"
},
{
  "id": 333,
  "subject": "Basic Science",
  "question": "Which part of a plant cell is not found in an animal cell?",
  "generalFeedback": "Plant and animal cells have many common organelles, but plant cells have a few unique structures that are related to their functions, such as support and photosynthesis.",
  "answers": [
      {
          "text": "Cell wall",
          "feedback": "Correct. The cell wall is a rigid outer layer that provides structural support to the plant cell. Animal cells do not have this."
      },
      {
          "text": "Nucleus",
          "feedback": "Incorrect. Both plant and animal cells have a nucleus, which contains the cell's genetic material."
      },
      {
          "text": "Cytoplasm",
          "feedback": "Incorrect. Cytoplasm is the jelly-like substance that fills both plant and animal cells."
      },
      {
          "text": "Cell membrane",
          "feedback": "Incorrect. Both plant and animal cells have a cell membrane that controls what enters and leaves the cell."
      }
  ],
  "correctAnswer": "Cell wall"
},
{
  "id": 334,
  "subject": "Basic Science",
  "question": "Rusting of iron is an example of a _______.",
  "generalFeedback": "Changes in matter can be physical or chemical. A physical change alters the form of a substance, but not its chemical identity (e.g., melting ice). A chemical change results in the formation of a new substance with different properties.",
  "answers": [
      {
          "text": "Chemical change",
          "feedback": "Correct. Rust (iron oxide) is a new substance formed when iron reacts with oxygen and water. The change is not easily reversible."
      },
      {
          "text": "Physical change",
          "feedback": "Incorrect. A physical change would be something like bending the iron; it's still iron."
      },
      {
          "text": "Biological change",
          "feedback": "Incorrect. Biological changes involve living organisms, like decomposition."
      },
      {
          "text": "Nuclear change",
          "feedback": "Incorrect. Nuclear changes involve alterations in the nucleus of an atom and release massive amounts of energy."
      }
  ],
  "correctAnswer": "Chemical change"
},
{
  "id": 335,
  "subject": "Basic Technology",
  "question": "Which of the following is a primary reason for wearing safety goggles in a workshop?",
  "generalFeedback": "Safety is the most important rule in any workshop. Personal Protective Equipment (PPE) is designed to protect different parts of the body from specific hazards.",
  "answers": [
      {
          "text": "To protect the eyes from flying debris",
          "feedback": "Correct. Safety goggles are designed to prevent dust, wood chips, metal filings, and other particles from entering and damaging the eyes."
      },
      {
          "text": "To look more professional",
          "feedback": "Incorrect. While they are part of a professional's gear, their primary purpose is safety, not appearance."
      },
      {
          "text": "To keep sweat from your eyes",
          "feedback": "Incorrect. A headband would be more effective for this purpose. The main function is protection from impact."
      },
      {
          "text": "To improve your vision",
          "feedback": "Incorrect. Safety goggles are for protection. If you need vision correction, you should wear prescription safety glasses."
      }
  ],
  "correctAnswer": "To protect the eyes from flying debris"
},
{
  "id": 336,
  "subject": "Basic Technology",
  "question": "A saw is a tool primarily used for _______.",
  "generalFeedback": "Tools are designed for specific tasks. Workshop tools can be categorized by their function, such as measuring, marking, cutting, or joining.",
  "answers": [
      {
          "text": "Cutting materials",
          "feedback": "Correct. Saws have toothed blades designed to cut through materials like wood, metal, or plastic."
      },
      {
          "text": "Joining materials",
          "feedback": "Incorrect. Tools like hammers and nails, screws and screwdrivers, or glue are used for joining."
      },
      {
          "text": "Measuring materials",
          "feedback": "Incorrect. Tools like a measuring tape, ruler, or calipers are used for measuring."
      },
      {
          "text": "Smoothing materials",
          "feedback": "Incorrect. Tools like sandpaper, files, or a plane are used for smoothing surfaces."
      }
  ],
  "correctAnswer": "Cutting materials"
},
{
  "id": 337,
  "subject": "Basic Technology",
  "question": "In technical drawing, what does a short, thick, continuous line represent?",
  "generalFeedback": "Technical drawing uses different types of lines (linetypes) to convey specific information about an object. Each line has a standard meaning.",
  "answers": [
      {
          "text": "Visible outline",
          "feedback": "Correct. This line, also called an object line, is used to show the main, visible edges and outlines of an object."
      },
      {
          "text": "Hidden detail",
          "feedback": "Incorrect. Hidden details are shown with short dashed lines."
      },
      {
          "text": "Center line",
          "feedback": "Incorrect. Center lines are shown with a long-dash-short-dash pattern and indicate the center of a circle or an axis of symmetry."
      },
      {
          "text": "Dimension line",
          "feedback": "Incorrect. Dimension lines are thin continuous lines with arrowheads at the ends, used to show the size of an object."
      }
  ],
  "correctAnswer": "Visible outline"
},
{
  "id": 338,
  "subject": "Basic Technology",
  "question": "Wood is a material that comes from _______.",
  "generalFeedback": "Materials used in technology can be natural or man-made. Understanding their origin helps in knowing their properties and uses.",
  "answers": [
      {
          "text": "Trees",
          "feedback": "Correct. Wood is a natural, organic material that forms the main substance of the trunk or branches of a tree."
      },
      {
          "text": "Mines",
          "feedback": "Incorrect. Ores, from which metals are extracted, come from mines."
      },
      {
          "text": "Animals",
          "feedback": "Incorrect. Materials like leather and wool come from animals."
      },
      {
          "text": "Chemicals",
          "feedback": "Incorrect. Plastics are man-made materials derived from chemicals, often from crude oil."
      }
  ],
  "correctAnswer": "Trees"
},
{
  "id": 339,
  "subject": "History",
  "question": "What is the name given to the amalgamation of the Northern and Southern Protectorates of Nigeria in 1914?",
  "generalFeedback": "This event is a cornerstone of Nigerian history, marking the creation of the single colonial entity that would later become the nation of Nigeria.",
  "answers": [
      {
          "text": "The Amalgamation of 1914",
          "feedback": "Correct. This is the official historical name for the event where Lord Frederick Lugard joined the two protectorates."
      },
      {
          "text": "The Independence of Nigeria",
          "feedback": "Incorrect. Nigeria gained independence from Britain much later, in 1960."
      },
      {
          "text": "The Scramble for Africa",
          "feedback": "Incorrect. The Scramble for Africa was a broader period in the late 19th century when European powers colonized the continent."
      },
      {
          "text": "The Berlin Conference",
          "feedback": "Incorrect. The Berlin Conference of 1884-85 was where European powers met to divide Africa among themselves."
      }
  ],
  "correctAnswer": "The Amalgamation of 1914"
},
{
  "id": 340,
  "subject": "History",
  "question": "The ancient Nok culture is famous for its _______.",
  "generalFeedback": "The Nok culture is one of the earliest known civilizations in West Africa, and their unique artifacts provide important clues about their society.",
  "answers": [
      {
          "text": "Terracotta sculptures",
          "feedback": "Correct. The Nok people are renowned for their distinctive terracotta (baked clay) heads and figures, which are among the oldest examples of sculpture in sub-Saharan Africa."
      },
      {
          "text": "Pyramid building",
          "feedback": "Incorrect. Pyramid building is famously associated with the ancient Egyptians in North Africa."
      },
      {
          "text": "Bronze casting",
          "feedback": "Incorrect. Bronze casting is more famously associated with the later Benin and Ife civilizations."
      },
      {
          "text": "Writing system",
          "feedback": "Incorrect. While they had a complex culture, there is no evidence of a formal writing system from the Nok."
      }
  ],
  "correctAnswer": "Terracotta sculptures"
},
{
  "id": 341,
  "subject": "History",
  "question": "A primary source of history is _______.",
  "generalFeedback": "Historians use different types of sources to study the past. Primary sources are direct evidence from the time period, while secondary sources are interpretations created later.",
  "answers": [
      {
          "text": "An eyewitness account or an artifact from the period",
          "feedback": "Correct. Primary sources are original materials, such as diaries, letters, photographs, and artifacts like tools or pottery."
      },
      {
          "text": "A textbook written by a modern historian",
          "feedback": "Incorrect. A textbook is a secondary source because the author has studied primary sources and is presenting their interpretation of the events."
      },
      {
          "text": "A movie about a historical event",
          "feedback": "Incorrect. A movie is a secondary source and often includes fictional elements for dramatic effect."
      },
      {
          "text": "An encyclopedia article",
          "feedback": "Incorrect. An encyclopedia is a secondary or tertiary source, summarizing information from other sources."
      }
  ],
  "correctAnswer": "An eyewitness account or an artifact from the period"
},
{
  "id": 342,
  "subject": "Agricultural Science",
  "question": "Which of the following is a simple farm tool?",
  "generalFeedback": "Farm tools can be simple hand tools or complex machines. Simple tools are typically operated manually.",
  "answers": [
      {
          "text": "Cutlass",
          "feedback": "Correct. A cutlass is a basic hand tool used for clearing bush and light weeding."
      },
      {
          "text": "Tractor",
          "feedback": "Incorrect. A tractor is a complex farm machine, not a simple tool."
      },
      {
          "text": "Harvester",
          "feedback": "Incorrect. A harvester is a large, complex machine used for gathering crops."
      },
      {
          "text": "Irrigation system",
          "feedback": "Incorrect. An irrigation system is a network of pipes and sprinklers, which is a form of farm equipment, not a simple tool."
      }
  ],
  "correctAnswer": "Cutlass"
},
{
  "id": 343,
  "subject": "Agricultural Science",
  "question": "The process of raising animals for food and other products is called _______.",
  "generalFeedback": "Agriculture is broadly divided into two main areas: growing crops (arable farming) and raising animals.",
  "answers": [
      {
          "text": "Animal husbandry",
          "feedback": "Correct. Animal husbandry is the branch of agriculture concerned with the care and breeding of domestic animals."
      },
      {
          "text": "Horticulture",
          "feedback": "Incorrect. Horticulture is the practice of garden cultivation and management, focusing on plants."
      },
      {
          "text": "Agronomy",
          "feedback": "Incorrect. Agronomy is the science and technology of producing and using plants for food, fuel, fiber, and land reclamation."
      },
      {
          "text": "Forestry",
          "feedback": "Incorrect. Forestry is the science of planting, managing, and caring for forests."
      }
  ],
  "correctAnswer": "Animal husbandry"
},
{
  "id": 344,
  "subject": "Agricultural Science",
  "question": "Which of these is a root crop?",
  "generalFeedback": "Crops are often classified by the part of the plant that is harvested and used. Root crops are those where the edible part is the underground root.",
  "answers": [
      {
          "text": "Cassava",
          "feedback": "Correct. Cassava is a tuberous root that is a major staple food in many parts of the world."
      },
      {
          "text": "Maize",
          "feedback": "Incorrect. Maize (corn) is a cereal crop, and its edible part is the grain or seed."
      },
      {
          "text": "Tomato",
          "feedback": "Incorrect. Tomato is a fruit crop."
      },
      {
          "text": "Cabbage",
          "feedback": "Incorrect. Cabbage is a leafy vegetable."
      }
  ],
  "correctAnswer": "Cassava"
},
{
  "id": 345,
  "subject": "Agricultural Science",
  "question": "What is the primary function of soil for a plant?",
  "generalFeedback": "Soil plays several crucial roles in supporting plant life. Think about what a plant needs to get from its immediate environment to survive and grow.",
  "answers": [
      {
          "text": "To provide anchorage, water, and nutrients",
          "feedback": "Correct. Soil holds the plant's roots firmly (anchorage) and is the source of essential water and mineral nutrients."
      },
      {
          "text": "To provide sunlight",
          "feedback": "Incorrect. Plants get sunlight from the sun, which is captured by their leaves, not the soil."
      },
      {
          "text": "To provide carbon dioxide",
          "feedback": "Incorrect. Plants absorb carbon dioxide from the air through their leaves."
      },
      {
          "text": "To protect it from insects",
          "feedback": "Incorrect. While some soil organisms can deter pests, this is not a primary function of the soil itself."
      }
  ],
  "correctAnswer": "To provide anchorage, water, and nutrients"
},
{
  "id": 346,
  "subject": "Social Studies",
  "question": "The basic unit of society is the _______.",
  "generalFeedback": "Society is made up of many different groups and institutions, but it starts with the most fundamental and intimate group.",
  "answers": [
      {
          "text": "Family",
          "feedback": "Correct. The family is considered the first and most basic social unit where individuals are nurtured and socialized."
      },
      {
          "text": "School",
          "feedback": "Incorrect. A school is an important social institution for formal education, but the family is more fundamental."
      },
      {
          "text": "Community",
          "feedback": "Incorrect. A community is a group of families living in the same area."
      },
      {
          "text": "Government",
          "feedback": "Incorrect. The government is the system that governs a state or community, but it is built upon the foundation of families and communities."
      }
  ],
  "correctAnswer": "Family"
},
{
  "id": 347,
  "subject": "Social Studies",
  "question": "Which of the following is a national symbol of Nigeria?",
  "generalFeedback": "National symbols are objects, images, or emblems that represent a country and evoke feelings of patriotism.",
  "answers": [
      {
          "text": "The Coat of Arms",
          "feedback": "Correct. The Nigerian Coat of Arms, featuring a black shield with a wavy white pall, two white horses, and an eagle, is a major national symbol."
      },
      {
          "text": "The Elephant",
          "feedback": "Incorrect. While elephants are found in Nigeria, they are not an official national symbol."
      },
      {
          "text": "The River Niger",
          "feedback": "Incorrect. The River Niger is a major geographical feature and the source of the country's name, but it is not a formal national symbol like the flag or anthem."
      },
      {
          "text": "The Zuma Rock",
          "feedback": "Incorrect. Zuma Rock is a famous landmark, but not an official national symbol."
      }
  ],
  "correctAnswer": "The Coat of Arms"
},
{
  "id": 348,
  "subject": "Social Studies",
  "question": "The way of life of a group of people is known as their _______.",
  "generalFeedback": "This term encompasses the beliefs, customs, arts, laws, and habits of the members of a particular society.",
  "answers": [
      {
          "text": "Culture",
          "feedback": "Correct. Culture is the all-encompassing term for the shared attitudes, values, goals, and practices that characterize a group or organization."
      },
      {
          "text": "Religion",
          "feedback": "Incorrect. Religion is a specific system of faith and worship, which is an important part of culture, but not the entire thing."
      },
      {
          "text": "Government",
          "feedback": "Incorrect. Government is the system of rule, which is a product of a people's culture, but not the culture itself."
      },
      {
          "text": "Environment",
          "feedback": "Incorrect. The environment is the physical surroundings in which people live, which influences their culture."
      }
  ],
  "correctAnswer": "Culture"
},
{
  "id": 349,
  "subject": "Business Studies",
  "question": "What is the main function of commerce?",
  "generalFeedback": "Commerce is a major branch of business. It deals with all the activities that facilitate the exchange of goods and services from the producer to the final consumer.",
  "answers": [
      {
          "text": "To facilitate the exchange of goods and services",
          "feedback": "Correct. Commerce covers trade (buying and selling) and all the aids to trade (banking, transport, insurance, etc.) that make it possible."
      },
      {
          "text": "To manufacture products in a factory",
          "feedback": "Incorrect. This is production or industry, which happens before commerce begins."
      },
      {
          "text": "To extract raw materials from the earth",
          "feedback": "Incorrect. This is an extractive industry, like mining or farming."
      },
      {
          "text": "To manage the staff in an office",
          "feedback": "Incorrect. This is part of administration or office practice, which supports commerce but isn't its main function."
      }
  ],
  "correctAnswer": "To facilitate the exchange of goods and services"
},
{
  "id": 350,
  "subject": "Business Studies",
  "question": "An invoice is a document that _______.",
  "generalFeedback": "In business transactions, various documents are used to record information. An invoice is one of the most common source documents.",
  "answers": [
      {
          "text": "Requests payment for goods sold on credit",
          "feedback": "Correct. An invoice is sent by a seller to a buyer, listing the goods sold, quantities, and prices, and requesting payment."
      },
      {
          "text": "Acknowledges receipt of payment",
          "feedback": "Incorrect. A document that acknowledges payment is called a receipt."
      },
      {
          "text": "Is used to order goods",
          "feedback": "Incorrect. A document used to order goods is called a purchase order."
      },
      {
          "text": "Corrects an overcharge on a previous invoice",
          "feedback": "Incorrect. A document that corrects an overcharge is called a credit note."
      }
  ],
  "correctAnswer": "Requests payment for goods sold on credit"
},
{
  "id": 351,
  "subject": "Business Studies",
  "question": "Which of the following is an aid to trade?",
  "generalFeedback": "Aids to trade are services that help overcome the challenges in buying and selling, such as distance, risk, finance, and information.",
  "answers": [
      {
          "text": "Banking",
          "feedback": "Correct. Banking helps to overcome the problem of finance by providing payment services and loans."
      },
      {
          "text": "Farming",
          "feedback": "Incorrect. Farming is a productive industry, not an aid to trade."
      },
      {
          "text": "Manufacturing",
          "feedback": "Incorrect. Manufacturing is the process of making goods, which are then traded."
      },
      {
          "text": "Construction",
          "feedback": "Incorrect. Construction is an industry that builds infrastructure, which can help trade, but it is not a direct 'aid to trade' service like banking or transport."
      }
  ],
  "correctAnswer": "Banking"
},
{
  "id": 352,
  "subject": "Creative Arts",
  "question": "Red, yellow, and blue are known as _______ colors.",
  "generalFeedback": "Color theory is a fundamental part of visual arts. Colors are categorized based on how they are created.",
  "answers": [
      {
          "text": "Primary colors",
          "feedback": "Correct. Primary colors are the foundational colors from which all other colors can be mixed. You cannot create them by mixing other colors."
      },
      {
          "text": "Secondary colors",
          "feedback": "Incorrect. Secondary colors (orange, green, purple) are created by mixing two primary colors."
      },
      {
          "text": "Tertiary colors",
          "feedback": "Incorrect. Tertiary colors are created by mixing a primary color with a secondary color."
      },
      {
          "text": "Complementary colors",
          "feedback": "Incorrect. Complementary colors are pairs of colors that are opposite each other on the color wheel (e.g., red and green)."
      }
  ],
  "correctAnswer": "Primary colors"
},
{
  "id": 353,
  "subject": "Creative Arts",
  "question": "What is a 'motif' in art?",
  "generalFeedback": "In design and pattern making, certain elements are repeated to create a cohesive look. This repeated element has a specific name.",
  "answers": [
      {
          "text": "A repeated decorative design or pattern",
          "feedback": "Correct. A motif is a recurring element, image, or idea that is repeated in a pattern or design."
      },
      {
          "text": "The main subject of a painting",
          "feedback": "Incorrect. While a subject can be a motif if repeated, the term specifically refers to the repetition itself."
      },
      {
          "text": "A type of paintbrush",
          "feedback": "Incorrect. A paintbrush is a tool used to apply paint."
      },
      {
          "text": "A frame for a picture",
          "feedback": "Incorrect. A frame is used to display and protect a finished artwork."
      }
  ],
  "correctAnswer": "A repeated decorative design or pattern"
},
{
  "id": 354,
  "subject": "Creative Arts",
  "question": "The art of making objects from clay is called _______.",
  "generalFeedback": "This is a form of three-dimensional art that has been practiced for thousands of years, creating both functional and decorative items.",
  "answers": [
      {
          "text": "Pottery",
          "feedback": "Correct. Pottery involves shaping clay on a potter's wheel or by hand, and then firing it in a kiln to harden it."
      },
      {
          "text": "Weaving",
          "feedback": "Incorrect. Weaving is the art of interlacing threads to create fabric."
      },
      {
          "text": "Origami",
          "feedback": "Incorrect. Origami is the Japanese art of paper folding."
      },
      {
          "text": "Sculpture",
          "feedback": "Incorrect. Sculpture is a broader term for making three-dimensional art. Pottery is a specific type of sculpture."
      }
  ],
  "correctAnswer": "Pottery"
},
{
  "id": 355,
  "subject": "Music",
  "question": "How many lines are on a musical staff (or stave)?",
  "generalFeedback": "The staff is the fundamental framework on which musical notes are written. Counting its lines is a basic step in learning to read music.",
  "answers": [
      {
          "text": "5",
          "feedback": "Correct. A standard musical staff consists of 5 parallel lines and the 4 spaces between them."
      },
      {
          "text": "4",
          "feedback": "Incorrect. There are 4 spaces on the staff, but 5 lines."
      },
      {
          "text": "6",
          "feedback": "Incorrect. A standard staff has 5 lines. Some instruments, like the guitar (in tablature), might use 6 lines, but this is not the standard musical staff."
      },
      {
          "text": "7",
          "feedback": "Incorrect. This corresponds to the number of unique notes in a major scale (A, B, C, D, E, F, G), but not the number of lines on the staff."
      }
  ],
  "correctAnswer": "5"
},
{
  "id": 356,
  "subject": "Music",
  "question": "The speed of a piece of music is called its _______.",
  "generalFeedback": "This musical element determines how fast or slow the music should be played. It is often indicated by Italian terms like 'Adagio' (slow) or 'Allegro' (fast).",
  "answers": [
      {
          "text": "Tempo",
          "feedback": "Correct. Tempo is the term used to describe the speed or pace of a musical piece."
      },
      {
          "text": "Rhythm",
          "feedback": "Incorrect. Rhythm refers to the pattern of sounds and silences in music, the way music is organized in time."
      },
      {
          "text": "Pitch",
          "feedback": "Incorrect. Pitch refers to how high or low a note sounds."
      },
      {
          "text": "Dynamics",
          "feedback": "Incorrect. Dynamics refers to the volume of the music (how loud or soft it is)."
      }
  ],
  "correctAnswer": "Tempo"
},
{
  "id": 357,
  "subject": "Music",
  "question": "Which of these is a Nigerian musical instrument?",
  "generalFeedback": "Nigeria has a rich musical heritage with many unique traditional instruments. Identifying them is part of appreciating this culture.",
  "answers": [
      {
          "text": "Talking Drum (Gangan)",
          "feedback": "Correct. The Talking Drum is a famous hourglass-shaped drum from West Africa, particularly among the Yoruba people, whose pitch can be regulated to mimic human speech."
      },
      {
          "text": "Violin",
          "feedback": "Incorrect. The violin is a string instrument that originated in Europe."
      },
      {
          "text": "Piano",
          "feedback": "Incorrect. The piano is a keyboard instrument that originated in Europe."
      },
      {
          "text": "Bagpipes",
          "feedback": "Incorrect. Bagpipes are a wind instrument famously associated with Scotland."
      }
  ],
  "correctAnswer": "Talking Drum (Gangan)"
},
{
  "id": 358,
  "subject": "CRS",
  "question": "According to the book of Genesis, how many days did it take God to create the heavens and the earth?",
  "generalFeedback": "The creation story in Genesis chapter 1 provides a day-by-day account of creation, culminating in a day of rest.",
  "answers": [
      {
          "text": "Six days",
          "feedback": "Correct. The Bible states that God created the world in six days and rested on the seventh day."
      },
      {
          "text": "Seven days",
          "feedback": "Incorrect. God rested on the seventh day; the work of creation was completed in six days."
      },
      {
          "text": "One day",
          "feedback": "Incorrect. The creation was spread out over a period of six distinct days."
      },
      {
          "text": "Forty days",
          "feedback": "Incorrect. Forty days is a significant number elsewhere in the Bible (e.g., the flood, Jesus' temptation), but not for creation."
      }
  ],
  "correctAnswer": "Six days"
},
{
  "id": 359,
  "subject": "CRS",
  "question": "Who was the man that God called to leave his home and go to a land He would show him, promising to make him a great nation?",
  "generalFeedback": "This figure is known as the father of the Israelite nation and is a central character in Judaism, Christianity, and Islam.",
  "answers": [
      {
          "text": "Abraham",
          "feedback": "Correct. God called Abram (later renamed Abraham) in Genesis 12 and made a covenant with him."
      },
      {
          "text": "Moses",
          "feedback": "Incorrect. Moses was called by God much later to lead the Israelites out of slavery in Egypt."
      },
      {
          "text": "Noah",
          "feedback": "Incorrect. Noah was called by God to build an ark to save his family and the animals from a great flood."
      },
      {
          "text": "David",
          "feedback": "Incorrect. David was a shepherd who became the second king of Israel."
      }
  ],
  "correctAnswer": "Abraham"
},
{
  "id": 360,
  "subject": "CRS",
  "question": "Which of the Ten Commandments says to respect your parents?",
  "generalFeedback": "The Ten Commandments are a set of biblical principles relating to ethics and worship, given by God to Moses on Mount Sinai.",
  "answers": [
      {
          "text": "Honour your father and your mother",
          "feedback": "Correct. This is the fifth commandment and it comes with a promise of long life."
      },
      {
          "text": "You shall not steal",
          "feedback": "Incorrect. This is the eighth commandment."
      },
      {
          "text": "You shall not murder",
          "feedback": "Incorrect. This is the sixth commandment."
      },
      {
          "text": "Remember the Sabbath day, to keep it holy",
          "feedback": "Incorrect. This is the fourth commandment."
      }
  ],
  "correctAnswer": "Honour your father and your mother"
},
{
  "id": 361,
  "subject": "ICT",
  "question": "Which of these is an input device?",
  "generalFeedback": "Computer hardware is categorized by its function. Input devices are used to send data and commands INTO the computer.",
  "answers": [
      {
          "text": "Mouse",
          "feedback": "Correct. A mouse is used to input commands by pointing, clicking, and scrolling."
      },
      {
          "text": "Monitor",
          "feedback": "Incorrect. A monitor is an output device; it displays information FROM the computer."
      },
      {
          "text": "Printer",
          "feedback": "Incorrect. A printer is an output device; it produces a hard copy of information FROM the computer."
      },
      {
          "text": "Speaker",
          "feedback": "Incorrect. A speaker is an output device; it produces sound FROM the computer."
      }
  ],
  "correctAnswer": "Mouse"
},
{
  "id": 362,
  "subject": "ICT",
  "question": "What does 'CPU' stand for?",
  "generalFeedback": "The CPU is a critical component of a computer, often referred to as its 'brain'.",
  "answers": [
      {
          "text": "Central Processing Unit",
          "feedback": "Correct. The CPU is the electronic circuitry that executes instructions comprising a computer program."
      },
      {
          "text": "Central Power Unit",
          "feedback": "Incorrect. The power supply unit (PSU) handles power, not the CPU."
      },
      {
          "text": "Computer Personal Unit",
          "feedback": "Incorrect. This is not a standard acronym in computing."
      },
      {
          "text": "Control Panel Utility",
          "feedback": "Incorrect. The Control Panel is a part of the Windows operating system, not what CPU stands for."
      }
  ],
  "correctAnswer": "Central Processing Unit"
},
{
  "id": 363,
  "subject": "ICT",
  "question": "Microsoft Word is an example of _______.",
  "generalFeedback": "Computer software is divided into two main types: system software (which runs the computer, like Windows) and application software (which performs specific tasks for the user).",
  "answers": [
      {
          "text": "Application Software",
          "feedback": "Correct. Microsoft Word is an application designed for a specific task: word processing."
      },
      {
          "text": "System Software",
          "feedback": "Incorrect. An example of system software is an operating system like Windows or macOS."
      },
      {
          "text": "Hardware",
          "feedback": "Incorrect. Hardware refers to the physical components of a computer, like the keyboard or monitor. Software is a set of instructions."
      },
      {
          "text": "An operating system",
          "feedback": "Incorrect. While it runs on an operating system, it is not one itself. It is a program that a user chooses to run."
      }
  ],
  "correctAnswer": "Application Software"
},
{
  "id": 364,
  "subject": "ICT",
  "question": "To save a document for the first time, you should use which command?",
  "generalFeedback": "Saving your work is a crucial step to avoid losing it. There's a specific command for saving a new, untitled file.",
  "answers": [
      {
          "text": "Save As",
          "feedback": "Correct. 'Save As' allows you to choose the location and name for a new file."
      },
      {
          "text": "Save",
          "feedback": "Incorrect. While clicking 'Save' on a new document will often open the 'Save As' dialog box, 'Save As' is the more precise term for the action of naming and placing a new file."
      },
      {
          "text": "Open",
          "feedback": "Incorrect. 'Open' is used to load an existing, previously saved document."
      },
      {
          "text": "New",
          "feedback": "Incorrect. 'New' is used to create a blank document."
      }
  ],
  "correctAnswer": "Save As"
},
{
  "id": 365,
  "subject": "Igbo",
  "question": "Kedu ka e si as\u1ecb 'Good morning' n'Igbo?",
  "generalFeedback": "Greetings are a fundamental part of any language. The Igbo language has specific greetings for different times of the day.",
  "answers": [
      {
          "text": "\u1eca b\u1ecd\u1ecdla chi / \u1ee4t\u1ee5t\u1ee5 \u1ecdma",
          "feedback": "Correct. Both '\u1eca b\u1ecd\u1ecdla chi?' (Have you seen the new day?) and '\u1ee4t\u1ee5t\u1ee5 \u1ecdma' (Good morning) are correct ways to greet someone in the morning."
      },
      {
          "text": "Ka chi f\u1ecd\u1ecd",
          "feedback": "Incorrect. This means 'Good night' or literally 'Let the day break'."
      },
      {
          "text": "Nn\u1ecd\u1ecd",
          "feedback": "Incorrect. This means 'Welcome'."
      },
      {
          "text": "Daal\u1ee5",
          "feedback": "Incorrect. This means 'Thank you' or can be used as 'Goodbye'."
      }
  ],
  "correctAnswer": "\u1eca b\u1ecd\u1ecdla chi / \u1ee4t\u1ee5t\u1ee5 \u1ecdma"
},
{
  "id": 366,
  "subject": "Igbo",
  "question": "G\u1ecbn\u1ecb b\u1ee5 'akw\u1ee5kw\u1ecd' na Bekee?",
  "generalFeedback": "This question tests your Igbo vocabulary. 'Akw\u1ee5kw\u1ecd' is a very common word with multiple related meanings.",
  "answers": [
      {
          "text": "Book / School",
          "feedback": "Correct. 'Akw\u1ee5kw\u1ecd' can mean book, paper, or school, depending on the context."
      },
      {
          "text": "House",
          "feedback": "Incorrect. 'House' in Igbo is '\u1ee5l\u1ecd'."
      },
      {
          "text": "Water",
          "feedback": "Incorrect. 'Water' in Igbo is 'mmiri'."
      },
      {
          "text": "Food",
          "feedback": "Incorrect. 'Food' in Igbo is 'nri'."
      }
  ],
  "correctAnswer": "Book / School"
},
{
  "id": 367,
  "subject": "Igbo",
  "question": "N'ime mkp\u1ee5r\u1ee5 edemede Igbo, 'gb' b\u1ee5 _______.",
  "generalFeedback": "The Igbo alphabet contains some sounds and letter combinations that are not found in English. These are treated as single letters.",
  "answers": [
      {
          "text": "Otu mgbochiume (a consonant)",
          "feedback": "Correct. 'Gb' is a digraph that represents a single consonant sound in Igbo."
      },
      {
          "text": "Udaume ab\u1ee5\u1ecd (two vowels)",
          "feedback": "Incorrect. 'g' and 'b' are both consonants."
      },
      {
          "text": "Ab\u1ee5\u1ecd anagh\u1ecb ejik\u1ecd (two that don't connect)",
          "feedback": "Incorrect. In Igbo, 'gb' is a common and important letter representing a single sound."
      },
      {
          "text": "Aha mmad\u1ee5 (a person's name)",
          "feedback": "Incorrect. While it could be part of a name, its classification in the alphabet is as a consonant."
      }
  ],
  "correctAnswer": "Otu mgbochiume (a consonant)"
},
{
  "id": 368,
  "subject": "Home Economics",
  "question": "Which of these is a key reason for washing your hands before eating?",
  "generalFeedback": "Personal hygiene is a core topic in Home Economics. Simple habits like hand washing are crucial for maintaining good health.",
  "answers": [
      {
          "text": "To remove germs and prevent illness",
          "feedback": "Correct. Our hands pick up germs from surfaces we touch. Washing them removes these harmful microorganisms so we don't transfer them to our food and into our bodies."
      },
      {
          "text": "To make the food taste better",
          "feedback": "Incorrect. Hand washing does not affect the taste of food."
      },
      {
          "text": "To cool your hands down",
          "feedback": "Incorrect. While water might cool your hands, this is not the primary reason for washing them before a meal."
      },
      {
          "text": "Because it is a rule with no purpose",
          "feedback": "Incorrect. The rule has a very important scientific purpose related to health and safety."
      }
  ],
  "correctAnswer": "To remove germs and prevent illness"
},
{
  "id": 369,
  "subject": "Home Economics",
  "question": "Carbohydrates, found in foods like rice and yam, primarily provide the body with _______.",
  "generalFeedback": "The classes of food each have a primary function in the body. Understanding these functions is key to planning a balanced diet.",
  "answers": [
      {
          "text": "Energy",
          "feedback": "Correct. Carbohydrates are the body's main source of energy for daily activities."
      },
      {
          "text": "Body-building materials",
          "feedback": "Incorrect. This is the primary function of proteins (found in meat, beans, eggs)."
      },
      {
          "text": "Protection from diseases",
          "feedback": "Incorrect. This is a primary function of vitamins and minerals (found in fruits and vegetables)."
      },
      {
          "text": "Warmth and insulation",
          "feedback": "Incorrect. While providing energy does create warmth, the primary function of fats and oils is stored energy and insulation."
      }
  ],
  "correctAnswer": "Energy"
},
{
  "id": 370,
  "subject": "Home Economics",
  "question": "A needle and thread are basic tools used for _______.",
  "generalFeedback": "Home Economics covers basic life skills, including clothing care and repair. Identifying tools and their uses is a first step.",
  "answers": [
      {
          "text": "Sewing",
          "feedback": "Correct. Sewing is the craft of fastening or attaching objects using stitches made with a needle and thread."
      },
      {
          "text": "Cooking",
          "feedback": "Incorrect. Cooking tools include pots, pans, and spoons."
      },
      {
          "text": "Cleaning",
          "feedback": "Incorrect. Cleaning tools include brooms, mops, and dusters."
      },
      {
          "text": "Washing",
          "feedback": "Incorrect. Washing involves soap, water, and sometimes a washing machine or scrubbing brush."
      }
  ],
  "correctAnswer": "Sewing"
},
{
  "id": 371,
  "subject": "Home Economics",
  "question": "Which of these kitchen practices is unsafe?",
  "generalFeedback": "Kitchen safety is vital to prevent accidents like cuts, burns, and falls. It's important to know what not to do.",
  "answers": [
      {
          "text": "Using a wet cloth to handle a hot pot",
          "feedback": "Correct. This is very unsafe. Water is a good conductor of heat and will quickly transfer the heat from the pot to your hand, causing a severe burn. Always use a dry cloth or oven mitts."
      },
      {
          "text": "Wiping up spills immediately",
          "feedback": "Incorrect. This is a safe practice that prevents slips and falls."
      },
      {
          "text": "Turning pot handles away from the edge of the stove",
          "feedback": "Incorrect. This is a safe practice that prevents pots from being accidentally knocked over."
      },
      {
          "text": "Washing knives separately from other utensils",
          "feedback": "Incorrect. This is a safe practice that helps prevent accidental cuts."
      }
  ],
  "correctAnswer": "Using a wet cloth to handle a hot pot"
},
{
  "id": 372,
  "subject": "French",
  "question": "How do you say 'Hello' in French?",
  "generalFeedback": "Greetings are the first words you learn in a new language. 'Hello' is one of the most common and useful greetings.",
  "answers": [
      {
          "text": "Bonjour",
          "feedback": "Correct. 'Bonjour' is the standard way to say 'Hello' or 'Good day' in French."
      },
      {
          "text": "Au revoir",
          "feedback": "Incorrect. 'Au revoir' means 'Goodbye'."
      },
      {
          "text": "Merci",
          "feedback": "Incorrect. 'Merci' means 'Thank you'."
      },
      {
          "text": "Oui",
          "feedback": "Incorrect. 'Oui' means 'Yes'."
      }
  ],
  "correctAnswer": "Bonjour"
},
{
  "id": 373,
  "subject": "French",
  "question": "What does 'Je m'appelle...' mean in English?",
  "generalFeedback": "This is a key phrase for introducing yourself in French.",
  "answers": [
      {
          "text": "My name is...",
          "feedback": "Correct. This is the standard way to state your name. For example, 'Je m'appelle David.'"
      },
      {
          "text": "I have...",
          "feedback": "Incorrect. 'I have...' is 'J'ai...' in French."
      },
      {
          "text": "I am...",
          "feedback": "Incorrect. 'I am...' is 'Je suis...' in French."
      },
      {
          "text": "I like...",
          "feedback": "Incorrect. 'I like...' is 'J'aime...' in French."
      }
  ],
  "correctAnswer": "My name is..."
},
{
  "id": 374,
  "subject": "French",
  "question": "The number 'trois' in French is _______ in English.",
  "generalFeedback": "Learning numbers is a basic building block for communication.",
  "answers": [
      {
          "text": "Three",
          "feedback": "Correct. Un (1), deux (2), trois (3)."
      },
      {
          "text": "Two",
          "feedback": "Incorrect. 'Two' is 'deux' in French."
      },
      {
          "text": "Four",
          "feedback": "Incorrect. 'Four' is 'quatre' in French."
      },
      {
          "text": "Ten",
          "feedback": "Incorrect. 'Ten' is 'dix' in French."
      }
  ],
  "correctAnswer": "Three"
},
{
  "id": 375,
  "subject": "Mathematics",
  "question": "Express 0.5 as a fraction in its simplest form.",
  "generalFeedback": "To convert a decimal to a fraction, you write the decimal number as the numerator and its place value as the denominator. 0.5 is 'five tenths'. Then simplify.",
  "answers": [
      {
          "text": "1/2",
          "feedback": "Correct. 0.5 is equal to 5/10. Dividing both the numerator and the denominator by 5 simplifies it to 1/2."
      },
      {
          "text": "5/10",
          "feedback": "Incorrect. While this is a correct representation of 0.5, it is not in its simplest form. It can be simplified further."
      },
      {
          "text": "1/5",
          "feedback": "Incorrect. 1/5 is equal to 0.2, not 0.5."
      },
      {
          "text": "5/100",
          "feedback": "Incorrect. 5/100 is equal to 0.05. The 5 is in the tenths place, not the hundredths place."
      }
  ],
  "correctAnswer": "1/2"
},
{
  "id": 376,
  "subject": "Mathematics",
  "question": "What is 25% of 80?",
  "generalFeedback": "To find a percentage of a number, you can convert the percentage to a fraction or a decimal and then multiply. 25% is the same as 25/100 or 1/4 or 0.25.",
  "answers": [
      {
          "text": "20",
          "feedback": "Correct. 25% is 1/4. So, 1/4 of 80 is 80 \u00f7 4 = 20. Alternatively, 0.25 \u00d7 80 = 20."
      },
      {
          "text": "25",
          "feedback": "Incorrect. This is the percentage value, not the result of the calculation."
      },
      {
          "text": "40",
          "feedback": "Incorrect. This would be 50% of 80."
      },
      {
          "text": "16",
          "feedback": "Incorrect. This might be a result of a miscalculation. Re-check your multiplication or division."
      }
  ],
  "correctAnswer": "20"
},
{
  "id": 377,
  "subject": "English Language",
  "question": "Which word is the opposite of 'brave'?",
  "generalFeedback": "Words that are opposite in meaning are called antonyms. This question tests your vocabulary for antonyms.",
  "answers": [
      {
          "text": "Cowardly",
          "feedback": "Correct. Cowardly means lacking courage, which is the direct opposite of brave."
      },
      {
          "text": "Strong",
          "feedback": "Incorrect. Strong can be a quality of a brave person, but it is not its opposite. The opposite of strong is weak."
      },
      {
          "text": "Happy",
          "feedback": "Incorrect. Happy describes an emotion and is unrelated to bravery."
      },
      {
          "text": "Heroic",
          "feedback": "Incorrect. Heroic is a synonym for brave, meaning it has a similar meaning."
      }
  ],
  "correctAnswer": "Cowardly"
},
{
  "id": 378,
  "subject": "English Language",
  "question": "The plural form of 'child' is _______.",
  "generalFeedback": "Plurals indicate more than one of a noun. Many English plurals are irregular and do not simply add an '-s'.",
  "answers": [
      {
          "text": "Children",
          "feedback": "Correct. 'Child' is an irregular noun, and its plural form is 'children'."
      },
      {
          "text": "Childs",
          "feedback": "Incorrect. This follows the regular rule of adding '-s', but 'child' is an exception."
      },
      {
          "text": "Childes",
          "feedback": "Incorrect. This is not a correct plural form in English."
      },
      {
          "text": "Child",
          "feedback": "Incorrect. This is the singular form, meaning only one."
      }
  ],
  "correctAnswer": "Children"
},
{
  "id": 379,
  "subject": "Basic Science",
  "question": "A lever, a pulley, and an inclined plane are all examples of _______.",
  "generalFeedback": "These devices are used to make work easier, either by reducing the amount of force needed or changing the direction of the force.",
  "answers": [
      {
          "text": "Simple machines",
          "feedback": "Correct. These are all types of simple machines, which are elementary devices that have a specific movement (often rotational or linear)."
      },
      {
          "text": "Energy sources",
          "feedback": "Incorrect. Energy sources are things like the sun, wind, or fuel. Simple machines use energy but do not produce it."
      },
      {
          "text": "Chemical elements",
          "feedback": "Incorrect. Chemical elements are pure substances like oxygen, carbon, and iron."
      },
      {
          "text": "States of matter",
          "feedback": "Incorrect. The states of matter are solid, liquid, and gas."
      }
  ],
  "correctAnswer": "Simple machines"
},
{
  "id": 380,
  "subject": "Basic Science",
  "question": "What gas do humans breathe out during respiration?",
  "generalFeedback": "Respiration is the process of taking in oxygen and releasing waste gases. It's important to know which gases are involved.",
  "answers": [
      {
          "text": "Carbon dioxide",
          "feedback": "Correct. We breathe in air (which contains oxygen), our bodies use the oxygen, and we exhale carbon dioxide as a waste product."
      },
      {
          "text": "Oxygen",
          "feedback": "Incorrect. We breathe in oxygen; it is essential for our bodies to function."
      },
      {
          "text": "Nitrogen",
          "feedback": "Incorrect. While the air we breathe is mostly nitrogen, our bodies do not use it, and we breathe it out in roughly the same amount we breathe it in."
      },
      {
          "text": "Hydrogen",
          "feedback": "Incorrect. Hydrogen is not a significant gas in the process of human respiration."
      }
  ],
  "correctAnswer": "Carbon dioxide"
},
{
  "id": 381,
  "subject": "Basic Technology",
  "question": "A hammer is a tool designed for which of the following tasks?",
  "generalFeedback": "The design of a tool is directly related to its function. A hammer has a heavy head and a handle, designed to deliver a specific type of force.",
  "answers": [
      {
          "text": "Driving nails into wood",
          "feedback": "Correct. The primary use of a claw hammer is to strike nails to drive them into another object, or to pull them out with the claw."
      },
      {
          "text": "Cutting wood",
          "feedback": "Incorrect. A saw is used for cutting wood."
      },
      {
          "text": "Drilling holes",
          "feedback": "Incorrect. A drill is used for making holes."
      },
      {
          "text": "Measuring length",
          "feedback": "Incorrect. A ruler or measuring tape is used for measuring length."
      }
  ],
  "correctAnswer": "Driving nails into wood"
},
{
  "id": 382,
  "subject": "Basic Technology",
  "question": "Which of these materials is a good conductor of electricity?",
  "generalFeedback": "Materials can be classified as electrical conductors (which allow electricity to pass through easily) or insulators (which do not).",
  "answers": [
      {
          "text": "Copper",
          "feedback": "Correct. Copper is a metal that is an excellent electrical conductor, which is why it is used in electrical wiring."
      },
      {
          "text": "Wood",
          "feedback": "Incorrect. Dry wood is an electrical insulator."
      },
      {
          "text": "Plastic",
          "feedback": "Incorrect. Plastic is an excellent electrical insulator, which is why it is used to cover wires."
      },
      {
          "text": "Rubber",
          "feedback": "Incorrect. Rubber is an electrical insulator."
      }
  ],
  "correctAnswer": "Copper"
},
{
  "id": 383,
  "subject": "History",
  "question": "The Trans-Saharan trade was primarily based on the exchange of _______.",
  "generalFeedback": "This ancient trade route connected West Africa with North Africa and Europe, and the trade was driven by the availability of specific valuable resources in each region.",
  "answers": [
      {
          "text": "Gold and salt",
          "feedback": "Correct. West Africa was rich in gold, which it traded for salt from the Sahara desert. Salt was crucial for preserving food and for health."
      },
      {
          "text": "Slaves and guns",
          "feedback": "Incorrect. The slave and gun trade became dominant later with the Trans-Atlantic trade involving Europeans."
      },
      {
          "text": "Spices and silk",
          "feedback": "Incorrect. Spices and silk were major goods of the Asian trade routes, not the Trans-Saharan route."
      },
      {
          "text": "Cotton and cocoa",
          "feedback": "Incorrect. These became major cash crops much later, during and after the colonial period."
      }
  ],
  "correctAnswer": "Gold and salt"
},
{
  "id": 384,
  "subject": "History",
  "question": "Who was the first Prime Minister of Nigeria?",
  "generalFeedback": "This question tests your knowledge of key figures in Nigeria's journey to independence and the First Republic.",
  "answers": [
      {
          "text": "Sir Abubakar Tafawa Balewa",
          "feedback": "Correct. He was the only Prime Minister of an independent Nigeria, serving from 1960 to 1966."
      },
      {
          "text": "Nnamdi Azikiwe",
          "feedback": "Incorrect. Nnamdi Azikiwe was the first President of Nigeria, a largely ceremonial role at the time."
      },
      {
          "text": "Obafemi Awolowo",
          "feedback": "Incorrect. Obafemi Awolowo was the Premier of the Western Region and later the official Leader of the Opposition."
      },
      {
          "text": "Ahmadu Bello",
          "feedback": "Incorrect. Ahmadu Bello was the Sardauna of Sokoto and Premier of the Northern Region."
      }
  ],
  "correctAnswer": "Sir Abubakar Tafawa Balewa"
},
{
  "id": 385,
  "subject": "Agricultural Science",
  "question": "The removal of unwanted plants from a farm is called _______.",
  "generalFeedback": "Unwanted plants, or weeds, compete with crops for sunlight, water, and nutrients, so they must be removed to ensure a good harvest.",
  "answers": [
      {
          "text": "Weeding",
          "feedback": "Correct. Weeding is the agricultural practice of removing weeds."
      },
      {
          "text": "Planting",
          "feedback": "Incorrect. Planting is the act of putting seeds or seedlings into the ground."
      },
      {
          "text": "Harvesting",
          "feedback": "Incorrect. Harvesting is the process of gathering a ripe crop from the fields."
      },
      {
          "text": "Irrigation",
          "feedback": "Incorrect. Irrigation is the artificial application of water to land to assist in the production of crops."
      }
  ],
  "correctAnswer": "Weeding"
},
{
  "id": 386,
  "subject": "Agricultural Science",
  "question": "Which of these is a poultry bird?",
  "generalFeedback": "Poultry refers to domesticated birds kept by humans for their eggs, their meat or their feathers.",
  "answers": [
      {
          "text": "Chicken",
          "feedback": "Correct. Chickens are the most common type of poultry worldwide."
      },
      {
          "text": "Goat",
          "feedback": "Incorrect. A goat is a mammal, not a bird. It is considered livestock."
      },
      {
          "text": "Pig",
          "feedback": "Incorrect. A pig is a mammal and is considered livestock."
      },
      {
          "text": "Cow",
          "feedback": "Incorrect. A cow is a mammal and is considered livestock."
      }
  ],
  "correctAnswer": "Chicken"
},
{
  "id": 387,
  "subject": "Social Studies",
  "question": "A person who is loyal and dedicated to their country is described as _______.",
  "generalFeedback": "This term describes the quality of devotion and vigorous support for one's own nation.",
  "answers": [
      {
          "text": "Patriotic",
          "feedback": "Correct. Patriotism is the feeling of love, devotion, and sense of attachment to one's country."
      },
      {
          "text": "Selfish",
          "feedback": "Incorrect. Selfishness is being concerned chiefly with one's own personal profit or pleasure, which is the opposite of patriotism."
      },
      {
          "text": "Foreign",
          "feedback": "Incorrect. A foreigner is someone from another country."
      },
      {
          "text": "Lazy",
          "feedback": "Incorrect. Laziness has no direct connection to one's feelings about their country."
      }
  ],
  "correctAnswer": "Patriotic"
},
{
  "id": 388,
  "subject": "Social Studies",
  "question": "Which level of government is responsible for managing a whole country?",
  "generalFeedback": "In Nigeria, government is structured into three tiers or levels, each with its own set of responsibilities.",
  "answers": [
      {
          "text": "Federal Government",
          "feedback": "Correct. The Federal Government, headed by the President, is responsible for national issues like defense, foreign policy, and currency."
      },
      {
          "text": "State Government",
          "feedback": "Incorrect. A State Government, headed by a Governor, is responsible for matters within its specific state, like local education and healthcare."
      },
      {
          "text": "Local Government",
          "feedback": "Incorrect. A Local Government, headed by a Chairman, is responsible for matters in its local area, like markets and primary schools."
      },
      {
          "text": "Traditional Government",
          "feedback": "Incorrect. Traditional rulers play an advisory and cultural role but are not a formal level of constitutional government."
      }
  ],
  "correctAnswer": "Federal Government"
},
{
  "id": 389,
  "subject": "Business Studies",
  "question": "The person who buys goods from a shop is called a _______.",
  "generalFeedback": "In commerce, there are specific terms for the different parties involved in a transaction.",
  "answers": [
      {
          "text": "Customer",
          "feedback": "Correct. A customer (or consumer) is an individual or business that purchases goods or services from another business."
      },
      {
          "text": "Seller",
          "feedback": "Incorrect. The seller (or vendor) is the person who is selling the goods."
      },
      {
          "text": "Producer",
          "feedback": "Incorrect. The producer is the person or company that makes the goods."
      },
      {
          "text": "Wholesaler",
          "feedback": "Incorrect. A wholesaler buys in large quantities from the producer and sells in smaller quantities to the retailer (the shop)."
      }
  ],
  "correctAnswer": "Customer"
},
{
  "id": 390,
  "subject": "Business Studies",
  "question": "Which of these is a duty of a receptionist in an office?",
  "generalFeedback": "The receptionist is often the first point of contact for a business and has several key responsibilities related to communication and administration.",
  "answers": [
      {
          "text": "Answering phone calls and welcoming visitors",
          "feedback": "Correct. These are core duties of a receptionist, managing the flow of communication and people into the office."
      },
      {
          "text": "Repairing broken office equipment",
          "feedback": "Incorrect. This would be the job of a technician or maintenance staff."
      },
      {
          "text": "Managing the company's finances",
          "feedback": "Incorrect. This is the role of an accountant or finance manager."
      },
      {
          "text": "Cleaning the office",
          "feedback": "Incorrect. This is the duty of a cleaner or janitorial staff."
      }
  ],
  "correctAnswer": "Answering phone calls and welcoming visitors"
},
{
  "id": 391,
  "subject": "Creative Arts",
  "question": "The three-dimensional nature of an object (how it feels or looks like it feels) in a work of art is called _______.",
  "generalFeedback": "This is one of the key elements of art that artists use to create realistic or interesting surfaces in their work.",
  "answers": [
      {
          "text": "Texture",
          "feedback": "Correct. Texture refers to the surface quality of an object. It can be actual (how it really feels) or implied (how it looks like it would feel)."
      },
      {
          "text": "Line",
          "feedback": "Incorrect. A line is a mark made on a surface, a moving dot."
      },
      {
          "text": "Color",
          "feedback": "Incorrect. Color is what we see as a result of reflected light."
      },
      {
          "text": "Shape",
          "feedback": "Incorrect. A shape is a two-dimensional, enclosed area."
      }
  ],
  "correctAnswer": "Texture"
},
{
  "id": 392,
  "subject": "Music",
  "question": "What does the 'Treble Clef' primarily indicate?",
  "generalFeedback": "A clef is a musical symbol placed at the beginning of a staff to indicate the pitch of the written notes. The Treble Clef is one of the most common.",
  "answers": [
      {
          "text": "The pitch of the notes, generally for higher-pitched instruments and voices",
          "feedback": "Correct. The Treble Clef (or G-clef) curls around the second line from the bottom, indicating that this line is the note G above middle C. It's used for instruments like the flute, violin, and for women's voices."
      },
      {
          "text": "How loud the music should be played",
          "feedback": "Incorrect. Dynamics markings (like p for piano/soft or f for forte/loud) indicate volume."
      },
      {
          "text": "The speed of the music",
          "feedback": "Incorrect. The tempo marking indicates the speed."
      },
      {
          "text": "The end of the musical piece",
          "feedback": "Incorrect. A double bar line or the word 'Fine' indicates the end of a piece."
      }
  ],
  "correctAnswer": "The pitch of the notes, generally for higher-pitched instruments and voices"
},
{
  "id": 393,
  "subject": "CRS",
  "question": "In the New Testament, who baptized Jesus Christ?",
  "generalFeedback": "The baptism of Jesus marks the beginning of his public ministry and is a significant event recorded in the Gospels.",
  "answers": [
      {
          "text": "John the Baptist",
          "feedback": "Correct. Jesus was baptized by his cousin, John the Baptist, in the River Jordan."
      },
      {
          "text": "Peter",
          "feedback": "Incorrect. Peter was one of Jesus' disciples, whom he called after his baptism."
      },
      {
          "text": "Moses",
          "feedback": "Incorrect. Moses was a prophet from the Old Testament and lived long before Jesus."
      },
      {
          "text": "God",
          "feedback": "Incorrect. While the voice of God the Father was heard from heaven, John the Baptist was the person who physically performed the baptism."
      }
  ],
  "correctAnswer": "John the Baptist"
},
{
  "id": 394,
  "subject": "CRS",
  "question": "A short story told by Jesus to teach a moral or spiritual lesson is called a _______.",
  "generalFeedback": "Jesus frequently used this method of teaching to make complex spiritual truths understandable to ordinary people using everyday examples.",
  "answers": [
      {
          "text": "Parable",
          "feedback": "Correct. Examples include the Parable of the Good Samaritan and the Parable of the Prodigal Son."
      },
      {
          "text": "Miracle",
          "feedback": "Incorrect. A miracle is an extraordinary event that shows divine power, like healing the sick or walking on water."
      },
      {
          "text": "Commandment",
          "feedback": "Incorrect. A commandment is a divine rule or order, like the Ten Commandments."
      },
      {
          "text": "Prophecy",
          "feedback": "Incorrect. A prophecy is a message inspired by God, a prediction of what is to come."
      }
  ],
  "correctAnswer": "Parable"
},
{
  "id": 395,
  "subject": "ICT",
  "question": "What is the name for the main screen of the Windows operating system that appears after you log in?",
  "generalFeedback": "This screen serves as the primary workspace, containing icons, shortcuts, and the taskbar.",
  "answers": [
      {
          "text": "Desktop",
          "feedback": "Correct. The Desktop is the main graphical user interface of an operating system."
      },
      {
          "text": "Homepage",
          "feedback": "Incorrect. A homepage is the main page of a website."
      },
      {
          "text": "Start Menu",
          "feedback": "Incorrect. The Start Menu is a feature on the Desktop that provides access to programs and settings."
      },
      {
          "text": "Dashboard",
          "feedback": "Incorrect. A dashboard is a type of interface that presents key information at a glance, often used in web applications."
      }
  ],
  "correctAnswer": "Desktop"
},
{
  "id": 396,
  "subject": "ICT",
  "question": "A set of instructions that tells the computer hardware what to do is called _______.",
  "generalFeedback": "Computers are made of physical parts (hardware) and the programs that run on them. This question asks for the name of those programs and instructions.",
  "answers": [
      {
          "text": "Software",
          "feedback": "Correct. Software is the general term for the various kinds of programs used to operate computers and related devices."
      },
      {
          "text": "Hardware",
          "feedback": "Incorrect. Hardware refers to the physical components of the computer that you can touch."
      },
      {
          "text": "Data",
          "feedback": "Incorrect. Data is the raw information that software processes."
      },
      {
          "text": "Network",
          "feedback": "Incorrect. A network is a collection of connected computers that can share resources and data."
      }
  ],
  "correctAnswer": "Software"
},
{
  "id": 397,
  "subject": "Igbo",
  "question": "Kedu aha nne nne g\u1ecb na nna nne g\u1ecb?",
  "generalFeedback": "This question tests your knowledge of Igbo terms for extended family members.",
  "answers": [
      {
          "text": "Nne ochie na Nna ochie",
          "feedback": "Correct. 'Nne ochie' is grandmother and 'Nna ochie' is grandfather."
      },
      {
          "text": "Mama na Papa",
          "feedback": "Incorrect. These are informal terms for mother and father."
      },
      {
          "text": "Nwanne nwany\u1ecb na Nwanne nwoke",
          "feedback": "Incorrect. These mean 'sister' and 'brother' respectively."
      },
      {
          "text": "Ada na Okpara",
          "feedback": "Incorrect. These refer to the first daughter and first son."
      }
  ],
  "correctAnswer": "Nne ochie na Nna ochie"
},
{
  "id": 398,
  "subject": "Home Economics",
  "question": "A balanced diet is a meal that contains _______.",
  "generalFeedback": "Good nutrition is about eating a variety of foods to get all the nutrients your body needs to be healthy.",
  "answers": [
      {
          "text": "All classes of food in the right proportion",
          "feedback": "Correct. A balanced diet includes carbohydrates, proteins, fats, vitamins, minerals, and water in appropriate amounts."
      },
      {
          "text": "Only fruits and vegetables",
          "feedback": "Incorrect. While fruits and vegetables are very important for vitamins and minerals, a diet needs other food classes for energy and growth."
      },
      {
          "text": "A very large amount of food",
          "feedback": "Incorrect. A balanced diet is about the quality and proportion of nutrients, not just the quantity of food."
      },
      {
          "text": "Only your favourite food",
          "feedback": "Incorrect. Eating only your favourite food is unlikely to provide all the necessary nutrients."
      }
  ],
  "correctAnswer": "All classes of food in the right proportion"
},
{
  "id": 399,
  "subject": "Home Economics",
  "question": "Which of these is used for cleaning the floor?",
  "generalFeedback": "Proper home care requires using the right tool for each cleaning task.",
  "answers": [
      {
          "text": "Mop and bucket",
          "feedback": "Correct. A mop and bucket are used with water and detergent to wash hard floors."
      },
      {
          "text": "Sponge and soap",
          "feedback": "Incorrect. Sponges and soap are typically used for washing dishes or surfaces like countertops."
      },
      {
          "text": "Duster",
          "feedback": "Incorrect. A duster is used to remove dust from furniture and other surfaces."
      },
      {
          "text": "Towel",
          "feedback": "Incorrect. A towel is primarily used for drying things, such as hands, bodies, or dishes."
      }
  ],
  "correctAnswer": "Mop and bucket"
},
{
  "id": 400,
  "subject": "French",
  "question": "What is the French word for 'cat'?",
  "generalFeedback": "This question tests basic French vocabulary for common animals.",
  "answers": [
      {
          "text": "Le chat",
          "feedback": "Correct. 'Le chat' is the masculine form for 'the cat'."
      },
      {
          "text": "Le chien",
          "feedback": "Incorrect. 'Le chien' means 'the dog'."
      },
      {
          "text": "Le livre",
          "feedback": "Incorrect. 'Le livre' means 'the book'."
      },
      {
          "text": "La table",
          "feedback": "Incorrect. 'La table' means 'the table'."
      }
  ],
  "correctAnswer": "Le chat"
},
{
  "id": 401,
  "subject": "French",
  "question": "Which of these is a color in French?",
  "generalFeedback": "Learning the names of colors is a fundamental part of building vocabulary in a new language.",
  "answers": [
      {
          "text": "Rouge",
          "feedback": "Correct. 'Rouge' is the French word for 'red'."
      },
      {
          "text": "Maison",
          "feedback": "Incorrect. 'Maison' means 'house'."
      },
      {
          "text": "Manger",
          "feedback": "Incorrect. 'Manger' is a verb meaning 'to eat'."
      },
      {
          "text": "Lundi",
          "feedback": "Incorrect. 'Lundi' is the word for 'Monday'."
      }
  ],
  "correctAnswer": "Rouge"
},
{
  "id": 402,
  "subject": "Mathematics",
  "question": "A shape with 8 sides is called a/an _______.",
  "generalFeedback": "Polygons are named based on their number of sides. The prefixes often come from Greek numbers.",
  "answers": [
      {
          "text": "Octagon",
          "feedback": "Correct. 'Octo' is the Greek prefix for eight."
      },
      {
          "text": "Hexagon",
          "feedback": "Incorrect. A hexagon has 6 sides."
      },
      {
          "text": "Pentagon",
          "feedback": "Incorrect. A pentagon has 5 sides."
      },
      {
          "text": "Heptagon",
          "feedback": "Incorrect. A heptagon has 7 sides."
      }
  ],
  "correctAnswer": "Octagon"
},
{
  "id": 403,
  "subject": "English Language",
  "question": "Which sentence is grammatically correct?",
  "generalFeedback": "This question tests subject-verb agreement. The verb must agree with its subject in number (singular or plural).",
  "answers": [
      {
          "text": "The dogs are barking.",
          "feedback": "Correct. The plural subject 'dogs' agrees with the plural verb 'are'."
      },
      {
          "text": "The dogs is barking.",
          "feedback": "Incorrect. The plural subject 'dogs' does not agree with the singular verb 'is'."
      },
      {
          "text": "The dog are barking.",
          "feedback": "Incorrect. The singular subject 'dog' does not agree with the plural verb 'are'."
      },
      {
          "text": "The dogs barking.",
          "feedback": "Incorrect. This sentence is a fragment because it is missing the helping verb 'are'."
      }
  ],
  "correctAnswer": "The dogs are barking."
},
{
  "id": 404,
  "subject": "Basic Science",
  "question": "Water exists in which three states of matter?",
  "generalFeedback": "Water is a unique substance that can be commonly found in all three states of matter on Earth.",
  "answers": [
      {
          "text": "Solid, Liquid, Gas",
          "feedback": "Correct. Water as a solid is ice, as a liquid is water, and as a gas is steam or water vapor."
      },
      {
          "text": "Hard, Soft, Wet",
          "feedback": "Incorrect. These are properties or descriptions, not the fundamental states of matter."
      },
      {
          "text": "Hot, Cold, Warm",
          "feedback": "Incorrect. These are temperatures, which determine the state of matter, but are not the states themselves."
      },
      {
          "text": "Rock, Water, Air",
          "feedback": "Incorrect. These are examples of substances that are often in a solid, liquid, or gas state, but they are not the names of the states themselves."
      }
  ],
  "correctAnswer": "Solid, Liquid, Gas"
},
{
  "id": 405,
  "subject": "Basic Technology",
  "question": "What is the primary function of a screwdriver?",
  "generalFeedback": "Screwdrivers are designed to interact with a specific type of fastener. Their shape is key to their function.",
  "answers": [
      {
          "text": "To turn screws",
          "feedback": "Correct. A screwdriver has a tip shaped to fit into the head of a screw to either tighten (drive) or loosen it."
      },
      {
          "text": "To hit nails",
          "feedback": "Incorrect. A hammer is used to hit nails."
      },
      {
          "text": "To cut wires",
          "feedback": "Incorrect. Pliers or wire cutters are used to cut wires."
      },
      {
          "text": "To hold objects firmly",
          "feedback": "Incorrect. A vice or a clamp is used to hold objects firmly."
      }
  ],
  "correctAnswer": "To turn screws"
},
{
  "id": 406,
  "subject": "History",
  "question": "The system of ruling a country's colony from the home country is known as _______.",
  "generalFeedback": "This term describes the policy or practice of acquiring full or partial political control over another country, occupying it with settlers, and exploiting it economically.",
  "answers": [
      {
          "text": "Colonialism",
          "feedback": "Correct. Colonialism is the establishment, maintenance, and expansion of colonies in one territory by people from another territory."
      },
      {
          "text": "Democracy",
          "feedback": "Incorrect. Democracy is a system of government by the whole population, typically through elected representatives."
      },
      {
          "text": "Nationalism",
          "feedback": "Incorrect. Nationalism is identification with one's own nation and support for its interests, often leading to a desire for independence from colonial rule."
      },
      {
          "text": "Trade",
          "feedback": "Incorrect. Trade is the action of buying and selling goods and services, which was a major part of colonialism, but not the system of rule itself."
      }
  ],
  "correctAnswer": "Colonialism"
},
{
  "id": 407,
  "subject": "Agricultural Science",
  "question": "What is 'manure'?",
  "generalFeedback": "Improving soil fertility is key to successful farming. Manure is a natural way to add nutrients to the soil.",
  "answers": [
      {
          "text": "Animal dung used for fertilizing land",
          "feedback": "Correct. Manure is organic matter, mostly derived from animal feces, used as agricultural fertilizer."
      },
      {
          "text": "A type of farm tool",
          "feedback": "Incorrect. Manure is a substance, not a tool. A tool for spreading it would be a manure fork or spreader."
      },
      {
          "text": "A type of crop",
          "feedback": "Incorrect. Manure is not a plant; it is used to help plants grow."
      },
      {
          "text": "Water for crops",
          "feedback": "Incorrect. Water provided for crops is called irrigation."
      }
  ],
  "correctAnswer": "Animal dung used for fertilizing land"
},
{
  "id": 408,
  "subject": "Social Studies",
  "question": "Pollution is the introduction of _______ substances into the environment.",
  "generalFeedback": "Environmental protection is a key topic in Social Studies. Pollution is a major threat to our environment.",
  "answers": [
      {
          "text": "Harmful",
          "feedback": "Correct. Pollution introduces contaminants into the natural environment that cause adverse change."
      },
      {
          "text": "Helpful",
          "feedback": "Incorrect. Helpful substances would improve the environment, not pollute it."
      },
      {
          "text": "Natural",
          "feedback": "Incorrect. While some natural events like volcanic eruptions cause pollution, the term generally refers to harmful contaminants, many of which are man-made."
      },
      {
          "text": "Clean",
          "feedback": "Incorrect. Clean substances would not cause pollution."
      }
  ],
  "correctAnswer": "Harmful"
},
{
  "id": 409,
  "subject": "Business Studies",
  "question": "The money you earn by selling goods for more than you paid for them is called _______.",
  "generalFeedback": "This is the fundamental goal of most businesses: to achieve a financial gain from their transactions.",
  "answers": [
      {
          "text": "Profit",
          "feedback": "Correct. Profit is the financial gain, especially the difference between the amount earned and the amount spent in buying, operating, or producing something."
      },
      {
          "text": "Loss",
          "feedback": "Incorrect. A loss occurs when you sell goods for less than you paid for them."
      },
      {
          "text": "Capital",
          "feedback": "Incorrect. Capital is the money or assets you invest to start a business."
      },
      {
          "text": "Sales",
          "feedback": "Incorrect. Sales (or revenue) is the total amount of money received from selling goods, before subtracting the costs."
      }
  ],
  "correctAnswer": "Profit"
},
{
  "id": 410,
  "subject": "Creative Arts",
  "question": "In drama, the written text of a play is called a _______.",
  "generalFeedback": "This document contains the dialogue, stage directions, and characters that actors and directors use to produce a play.",
  "answers": [
      {
          "text": "Script",
          "feedback": "Correct. A script is the screenplay or written work that details the story, dialogue, and action."
      },
      {
          "text": "Novel",
          "feedback": "Incorrect. A novel is a long work of narrative fiction, usually written in prose and published as a book, but not formatted for performance."
      },
      {
          "text": "Poem",
          "feedback": "Incorrect. A poem is a piece of writing that uses imaginative language and is often arranged in lines with rhythm and rhyme."
      },
      {
          "text": "Stage",
          "feedback": "Incorrect. The stage is the physical platform where the performance takes place."
      }
  ],
  "correctAnswer": "Script"
},
{
  "id": 411,
  "subject": "Music",
  "question": "The person who writes music is called a _______.",
  "generalFeedback": "This question tests your vocabulary for professions within the field of music.",
  "answers": [
      {
          "text": "Composer",
          "feedback": "Correct. A composer is a person who writes music, especially as a professional occupation."
      },
      {
          "text": "Conductor",
          "feedback": "Incorrect. A conductor is a person who directs the performance of an orchestra or choir."
      },
      {
          "text": "Performer",
          "feedback": "Incorrect. A performer is a person who sings or plays a musical instrument in front of an audience."
      },
      {
          "text": "Lyricist",
          "feedback": "Incorrect. A lyricist is a person who writes the words (lyrics) to a song. The composer writes the music."
      }
  ],
  "correctAnswer": "Composer"
},
{
  "id": 412,
  "subject": "CRS",
  "question": "Who was swallowed by a great fish as a punishment for disobeying God?",
  "generalFeedback": "This Old Testament prophet's story is a famous tale of disobedience and God's mercy.",
  "answers": [
      {
          "text": "Jonah",
          "feedback": "Correct. God commanded Jonah to go to Nineveh, but he fled in the opposite direction. He was then swallowed by a great fish and later repented."
      },
      {
          "text": "Daniel",
          "feedback": "Incorrect. Daniel was thrown into a den of lions but was protected by God."
      },
      {
          "text": "Elijah",
          "feedback": "Incorrect. Elijah was a great prophet who challenged the prophets of Baal and was taken up to heaven in a chariot of fire."
      },
      {
          "text": "Job",
          "feedback": "Incorrect. Job was a righteous man who suffered greatly to test his faith but was not swallowed by a fish."
      }
  ],
  "correctAnswer": "Jonah"
},
{
  "id": 413,
  "subject": "ICT",
  "question": "Which of these is a popular web browser?",
  "generalFeedback": "A web browser is an application software used to access and view websites on the Internet.",
  "answers": [
      {
          "text": "Google Chrome",
          "feedback": "Correct. Google Chrome is a widely used web browser, along with others like Mozilla Firefox, Safari, and Microsoft Edge."
      },
      {
          "text": "Microsoft Word",
          "feedback": "Incorrect. Microsoft Word is a word processing application, not a web browser."
      },
      {
          "text": "Google Search",
          "feedback": "Incorrect. Google Search is a search engine, which is a website you access *using* a web browser."
      },
      {
          "text": "Windows 10",
          "feedback": "Incorrect. Windows 10 is an operating system, which is the software that runs the entire computer and allows you to run applications like web browsers."
      }
  ],
  "correctAnswer": "Google Chrome"
},
{
  "id": 414,
  "subject": "Home Economics",
  "question": "The process of using heat to cook food is generally called _______.",
  "generalFeedback": "This is the broad term for preparing food with heat for consumption.",
  "answers": [
      {
          "text": "Cooking",
          "feedback": "Correct. Cooking is the general term that includes methods like boiling, frying, baking, and roasting."
      },
      {
          "text": "Freezing",
          "feedback": "Incorrect. Freezing is the process of preserving food by lowering its temperature to below 0\u00b0C."
      },
      {
          "text": "Washing",
          "feedback": "Incorrect. Washing is the process of cleaning food with water before preparation."
      },
      {
          "text": "Mixing",
          "feedback": "Incorrect. Mixing is the process of combining ingredients."
      }
  ],
  "correctAnswer": "Cooking"
},
{
  "id": 415,
  "subject": "French",
  "question": "The opposite of 'oui' in French is _______.",
  "generalFeedback": "Knowing how to say 'yes' and 'no' is one of the most basic and essential skills in any language.",
  "answers": [
      {
          "text": "Non",
          "feedback": "Correct. 'Non' is the French word for 'no'."
      },
      {
          "text": "Bonjour",
          "feedback": "Incorrect. 'Bonjour' means 'hello'."
      },
      {
          "text": "Merci",
          "feedback": "Incorrect. 'Merci' means 'thank you'."
      },
      {
          "text": "Bon",
          "feedback": "Incorrect. 'Bon' means 'good'."
      }
  ],
  "correctAnswer": "Non"
},
{
  "id": 416,
  "subject": "Mathematics",
  "question": "How many minutes are in 2 hours?",
  "generalFeedback": "This question tests your knowledge of time conversion. You need to know how many minutes are in a single hour and then multiply.",
  "answers": [
      {
          "text": "120 minutes",
          "feedback": "Correct. There are 60 minutes in 1 hour. So, in 2 hours, there are 2 \u00d7 60 = 120 minutes."
      },
      {
          "text": "60 minutes",
          "feedback": "Incorrect. This is the number of minutes in 1 hour, not 2 hours."
      },
      {
          "text": "30 minutes",
          "feedback": "Incorrect. This is half an hour."
      },
      {
          "text": "200 minutes",
          "feedback": "Incorrect. This might be a result of a calculation error."
      }
  ],
  "correctAnswer": "120 minutes"
},
{
  "id": 417,
  "subject": "English Language",
  "question": "An _______ is a word used to describe a noun.",
  "generalFeedback": "This question asks for the name of a specific part of speech based on its function.",
  "answers": [
      {
          "text": "Adjective",
          "feedback": "Correct. Adjectives modify or describe nouns. For example, in 'the red car', 'red' is the adjective describing the noun 'car'."
      },
      {
          "text": "Adverb",
          "feedback": "Incorrect. An adverb describes a verb, an adjective, or another adverb (e.g., 'he ran quickly')."
      },
      {
          "text": "Verb",
          "feedback": "Incorrect. A verb is an action or state of being word (e.g., 'run', 'is')."
      },
      {
          "text": "Pronoun",
          "feedback": "Incorrect. A pronoun takes the place of a noun (e.g., 'he', 'she', 'it')."
      }
  ],
  "correctAnswer": "Adjective"
},
{
  "id": 418,
  "subject": "Basic Science",
  "question": "The central and most important part of a living cell, acting as its control center, is the _______.",
  "generalFeedback": "This organelle contains the cell's genetic material (DNA) and controls the cell's growth and reproduction.",
  "answers": [
      {
          "text": "Nucleus",
          "feedback": "Correct. The nucleus is the control center of the cell."
      },
      {
          "text": "Cytoplasm",
          "feedback": "Incorrect. The cytoplasm is the jelly-like substance that fills the cell and surrounds the organelles."
      },
      {
          "text": "Cell Membrane",
          "feedback": "Incorrect. The cell membrane is the outer boundary of an animal cell that controls what enters and exits."
      },
      {
          "text": "Mitochondrion",
          "feedback": "Incorrect. The mitochondrion is known as the 'powerhouse' of the cell, where respiration occurs to produce energy."
      }
  ],
  "correctAnswer": "Nucleus"
}
];
// Programmatically clean up the "Correct." prefix from feedback
defaultQuestions.forEach(question => {
  const correctAnswer = question.answers.find(ans => ans.text === question.correctAnswer);
  if (correctAnswer && correctAnswer.feedback.startsWith('Correct. ')) {
    correctAnswer.feedback = correctAnswer.feedback.substring('Correct. '.length);
  }
});

// Initialize extension on install
chrome.runtime.onInstalled.addListener(() => {
  // Set the default questions in storage if they don't exist
  chrome.storage.local.get('questions', (data) => {
    if (!data.questions) {
      chrome.storage.local.set({ questions: defaultQuestions });
    }
  });

  // Set initial state
  chrome.storage.local.get(['questions', 'answeredQuestions'], (result) => {
    const questions = result.questions || defaultQuestions;
    const answered = result.answeredQuestions || [];
    chrome.storage.local.set({
      isLocked: true,
      currentQuestion: getNextQuestion(questions, answered),
      answeredQuestions: [],
      lastUnlockTime: null
    });
  });

  setupAlarm();
});

// Re-lock on browser startup
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(['questions', 'answeredQuestions'], (result) => {
    const questions = result.questions || defaultQuestions;
    const answered = result.answeredQuestions || [];
    chrome.storage.local.set({
      isLocked: true,
      currentQuestion: getNextQuestion(questions, answered)
    });
  });
  setupAlarm();
});

function setupAlarm() {
  chrome.alarms.create('lockBrowser', { periodInMinutes: 20 });
}

// Listener for the 20-minute alarm
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'lockBrowser') {
    chrome.storage.local.get(['questions', 'answeredQuestions'], (result) => {
      const questions = result.questions || defaultQuestions;
      const answered = result.answeredQuestions || [];
      chrome.storage.local.set({
        isLocked: true,
        currentQuestion: getNextQuestion(questions, answered),
        lastUnlockTime: null
      }, () => {
        broadcastLockState(true); // Tell all tabs to show lock screen
      });
    });
  }
});

function getNextQuestion(questions, answeredIds) {
  const unanswered = questions.filter(q => !answeredIds.includes(q.id));
  if (unanswered.length === 0) {
    chrome.storage.local.set({ answeredQuestions: [] });
    return questions[Math.floor(Math.random() * questions.length)];
  }
  return unanswered[Math.floor(Math.random() * unanswered.length)];
}

// Function to send a message to all content scripts
function broadcastLockState(isLocked) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      if (tab.url && !tab.url.startsWith('chrome://')) {
        const message = isLocked ? { action: "showLock" } : { action: "clearLock" };
        chrome.tabs.sendMessage(tab.id, message).catch(() => {});
      }
    });
  });
}

// Listener for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "checkAnswer") {
    chrome.storage.local.get(['questions', 'currentQuestion', 'answeredQuestions'], (result) => {
      const questions = result.questions || defaultQuestions;
      const q = result.currentQuestion;
      const answered = result.answeredQuestions || [];
      const isCorrect = q.correctAnswer === request.answer;
      const selectedAnswerObj = q.answers.find(a => a.text === request.answer);

      if (isCorrect) {
        const newAnswered = [...answered, q.id];
        chrome.storage.local.set({
          isLocked: false,
          answeredQuestions: newAnswered,
          lastUnlockTime: Date.now()
        }, () => {
          broadcastLockState(false); // On correct answer, tell all tabs to unlock
        });
        sendResponse({
          correct: true,
          feedback: selectedAnswerObj.feedback,
          generalFeedback: q.generalFeedback
        });
      } else {
        const correctAnswerObj = q.answers.find(a => a.text === q.correctAnswer);
        const newQuestion = getNextQuestion(questions, answered);
        chrome.storage.local.set({ currentQuestion: newQuestion });
        sendResponse({
          correct: false,
          feedback: selectedAnswerObj.feedback,
          correctAnswerText: q.correctAnswer, // Send correct answer text for display
          correctAnswerFeedback: correctAnswerObj.feedback,
          generalFeedback: q.generalFeedback,
          newQuestion: newQuestion
        });
      }
    });
    return true; // Indicates async response
  }

  if (request.action === "getQuestion") {
    chrome.storage.local.get(['isLocked', 'currentQuestion'], (result) => {
      sendResponse({
        isLocked: result.isLocked,
        question: result.currentQuestion
      });
    });
    return true; // Indicates async response
  }
});